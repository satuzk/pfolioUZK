/*
 * This file is part of pfolioUZK.
 *
 * pfolioUZK is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * pfolioUZK is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You can find a copy of the GNU General Public License
 * at <http://www.gnu.org/licenses/>.
 *
 */

#include <iostream>
#include <vector>
#include <cstring>
#include <stdlib.h>
#include <sys/wait.h>
#include <sys/prctl.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/time.h>
#include <stdio.h>

using namespace std;

void checkAndSetInputParameters(int argc, char** argv) {
  if (argc < 2)
    throw "Invalid parameter";
}

void usage(const char *progname) {
  cerr << "Usage: " << progname << " <solver_uk_file> [<parameters...>] <input CNF>" << endl;
}

void splitCommandLine(vector<char*>& argv, const string& cmd) {
  string word;
  size_t i=0;

  argv.clear();

  do {
    while (i<cmd.length() && isspace(cmd[i]))
      ++i;

    word.clear();

    while (i<cmd.length() && !isspace(cmd[i]))
      word+=cmd[i++];

    if (!word.empty()) {
      // don't care about the memory leak
      argv.push_back(strdup(word.c_str()));
    } 
  } while (i<cmd.length());

  argv.push_back(NULL);
}

int main(int argc, char** argv) {
  try {
    checkAndSetInputParameters(argc,argv);

    string myDir = "./bin";
    string tmpDir = "/tmp";

    char buffer[100];
    timeval timeID;	
    gettimeofday(&timeID, 0);
    sprintf(buffer,"%d_%d",getpid(),timeID.tv_sec);
    string temp = tmpDir + "/solver_uk_" + buffer;
   
    string satelite = myDir + "/SatELite_release ";
    string solver_uk = myDir + "/";
    for (int i=1 ;i<argc-1;i++)
       solver_uk += (string)argv[i] + " ";
    string input = argv[argc-1];
    string tMap = temp + ".vmap";
    string tCNF = temp + ".cnf";
    string tElim = temp + ".elim";
    string tResult = temp + ".result";
    string command;

    
    pid_t pid;
    int rv,crv;
    vector<char *> argv;

    if ((pid = fork()) == -1) {
      cerr << "Fork error. Exiting.\n";  // something went wrong
      exit(1);        
    }
    
    if (pid) {
      //wait for SatELite to end
      wait(&rv);	
      if (WIFEXITED(rv) && WEXITSTATUS(rv)==0) {
	//fork for solver_uk
	if ((pid = fork()) == -1) {
	  cerr << "Fork error. Exiting.\n";  // something went wrong 
	  exit(1);        
	}
    
	if (pid) {
	  //wait for solver_uk to end
	  wait(&rv);
	  if (WIFEXITED(rv) && WEXITSTATUS(rv)==20) {
	    // result: UNSAT
	    cout << "s UNSATISFIABLE" << endl;
	  } else if (WIFEXITED(rv) && WEXITSTATUS(rv)==10) {
	    // result SAT, call SatELite for model extraction
	    if ((pid = fork()) == -1) {
	      cerr << "Fork error. Exiting.\n";  // something went wrong
	      exit(1);        
	    }
	    if (pid) {
	      // wait for model extracion from SatELite
	      wait(&rv);	
	    } else {
	      //child: SatELite model extracion
	      prctl(PR_SET_PDEATHSIG, SIGKILL);
	      command = satelite + "+ext " + input + " " + tResult + " " + tMap + " " + tElim;
	      splitCommandLine(argv,command);
	      crv = execv(argv[0],&argv[0]);
	      exit(crv);
	    }
	  } 
	  // clean up
	  command = "/bin/rm -f " + tCNF + " " + tMap + " " + tElim + " " + tResult;
	  system(command.c_str());
  
	  exit(WEXITSTATUS(rv));
	  
	} else {
	  //second child: solver_uk processing
	  prctl(PR_SET_PDEATHSIG, SIGKILL);
	  cout << endl << "c" << endl << "c Starting solver_uk" << endl;
	  cout <<  "c" << endl;
	  command = solver_uk + " -save-model " + tResult + " " + tCNF;
	  splitCommandLine(argv,command);	  
	  crv = execv(argv[0],&argv[0]);
	  exit(crv);
	}

      } else if (WIFEXITED(rv) && WEXITSTATUS(rv) == 11) {
	// SatELite dies, solver_uk must take care of the rest
	// fork for solver_uk
	if ((pid = fork()) == -1) {
	  cerr << "Fork error. Exiting.\n";  // something went wrong
	  exit(1);        
	}
	if (pid) {	
	  //wait for solver_uk to end
	  wait(&rv);
          command = "/bin/rm -f " + tCNF + " " + tMap + " " + tElim + " " + tResult;
	  system(command.c_str());
	  exit(WEXITSTATUS(rv));
	} else {
	  // solver_uk processing
	  prctl(PR_SET_PDEATHSIG, SIGKILL);
	  cout << endl << "c" << endl << "c Starting solver_uk" << endl;
	  cout <<  "c" << endl;
	  command = solver_uk + " -show-model " + input;
	  splitCommandLine(argv,command);	  
	  crv = execv(argv[0],&argv[0]);
	  exit(crv);
	}
      } else if (WIFEXITED(rv) && WEXITSTATUS(rv) == 12) {
	// SatELite prints usage message
        command = "/bin/rm -f " + tCNF + " " + tMap + " " + tElim + " " + tResult;
	system(command.c_str());
	exit(0);
      } else {
        command = "/bin/rm -f " + tCNF + " " + tMap + " " + tElim + " " + tResult;        
        system(command.c_str());
	exit(1);
      }
     
    } else {
      //first child: SatELite processing
      prctl(PR_SET_PDEATHSIG, SIGKILL);
      cout << endl << "c" << endl << "c Starting SatElite Preprocessing" << endl;
      cout <<  "c" << endl;
      command = satelite + input + " " + tCNF + " " + tMap + " " + tElim;
      splitCommandLine(argv,command);
      crv = execv(argv[0],&argv[0]);
      exit(crv);
    }

  } catch (const char *e) {
    cerr << "Error: " << e << endl;
    usage(argv[0]);
  } catch (string str) {
    cout << str;
  } catch (...) {
    cout << "Unhandled exception";
  }  
}

