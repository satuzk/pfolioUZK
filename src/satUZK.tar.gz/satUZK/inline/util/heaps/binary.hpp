
/* Concept: heap_hooks
	Required types:
		index_type
		heap_item
		storage_type
	
	Required functions:
		void on_init(heap_item item, index_type index);
		void on_update(heap_item item, index_type index);
		void on_remove(heap_item item);

		bool is_less(heap_item item1, heap_item item2);
		
		void idx_write(index_type index, heap_item item);
		heap_item idx_read(index_type index);

	Required fields:
		index_type heap_size
*/

namespace util {
namespace heaps {
namespace binary {

/* get index of parent node */
template<typename heap_hooks>
typename heap_hooks::index_type p_parent
		(typename heap_hooks::index_type index) {
	SYS_ASSERT(SYS_ASRT_GENERAL, index != 0);
	return (index - 1) / 2;
}

/* get index of left child */
template<typename heap_hooks>
typename heap_hooks::index_type p_left
		(typename heap_hooks::index_type index) {
	return index * 2 + 1;
}

/* get index of right child */
template<typename heap_hooks>
typename heap_hooks::index_type p_right
		(typename heap_hooks::index_type index) {
	return index * 2 + 2;
}

/* fixes the heap property when the GIVEN NODE
		might be LESS THAN ITS PARENT */
template<typename heap_hooks>
void p_fix_up(heap_hooks &hooks, typename heap_hooks::index_type index) {
	SYS_ASSERT(SYS_ASRT_GENERAL, index < hooks.get_heap_size());
	if(index == 0)
		return;
	
	/* swap node with parent; then fix parent */
	typename heap_hooks::index_type p_index = p_parent<heap_hooks>(index);
	typename heap_hooks::heap_item item = hooks.read(index);
	typename heap_hooks::heap_item parent = hooks.read(p_index);

	if(hooks.is_less(parent, item))
		return;
		
	hooks.write(p_index, item);
	hooks.write(index, parent);
	hooks.on_update(item, p_index);
	hooks.on_update(parent, index);
	p_fix_up(hooks, p_index);
}

/* fixes the heap property when CHILDREN
		of the given node might be LESS THAN THE NODE */
template<typename heap_hooks>
void p_fix_down(heap_hooks &hooks, typename heap_hooks::index_type index) {
	SYS_ASSERT(SYS_ASRT_GENERAL, index < hooks.get_heap_size());

	/* swap node with minimal child; then fix child */
	typename heap_hooks::index_type l_index = p_left<heap_hooks>(index);
	typename heap_hooks::index_type r_index = p_right<heap_hooks>(index);

	/* case 1: the item has no children */
	if(!(l_index < hooks.get_heap_size()))
		return;
	
	/* case 2: the item has only a left child */
	typename heap_hooks::heap_item item = hooks.read(index);
	typename heap_hooks::heap_item left = hooks.read(l_index);
	if(!(r_index < hooks.get_heap_size())) {
		if(hooks.is_less(item, left))
			return;

		hooks.write(l_index, item);
		hooks.write(index, left);
		hooks.on_update(item, l_index);
		hooks.on_update(left, index);
		return;
	}

	/* case 3: the item has two children */
	typename heap_hooks::heap_item right = hooks.read(r_index);

	bool left_less = hooks.is_less(left, right);
	typename heap_hooks::index_type m_index = left_less ? l_index : r_index;
	typename heap_hooks::heap_item &minimal = left_less ? left : right;
	if(hooks.is_less(item, minimal))
		return;

	hooks.write(m_index, item);
	hooks.write(index, minimal);
	hooks.on_update(item, m_index);
	hooks.on_update(minimal, index);
	p_fix_down(hooks, m_index);
}

template<typename heap_hooks>
void idx_remove(heap_hooks &hooks, typename heap_hooks::index_type index) {
	/* if we are removing the last node no fixes are necessary */
	hooks.dec_heap_size();
	typename heap_hooks::heap_item item = hooks.read(index);
	typename heap_hooks::index_type last_index = hooks.get_heap_size();
	if(index == last_index) {
		hooks.on_remove(item);
		return;
	}

	/* swap last node to the given node; then fix heap */
	typename heap_hooks::heap_item last = hooks.read(last_index);
	hooks.write(index, last);
	hooks.on_update(last, index);
	hooks.on_remove(item);
	
	p_fix_down(hooks, index);
}

template<typename heap_hooks>
void idx_became_less(heap_hooks &hooks,
		typename heap_hooks::index_type index) {
	p_fix_up(hooks, index);
}

template<typename heap_hooks>
void idx_became_greater(heap_hooks &hooks,
		typename heap_hooks::index_type index) {
	p_fix_down(hooks, index);
}

template<typename heap_hooks>
void insert(heap_hooks &hooks, typename heap_hooks::heap_item item) {
//	printf("Inserting %d\n", item);
	/* insert as last node; then fix heap */
	typename heap_hooks::index_type index = hooks.get_heap_size();
	hooks.inc_heap_size();
	hooks.write(index, item);
	hooks.on_init(item, index);
		
	p_fix_up(hooks, index);
}

template<typename heap_hooks>
typename heap_hooks::heap_item get_minimum(heap_hooks &hooks) {
	SYS_ASSERT(SYS_ASRT_GENERAL, hooks.get_heap_size() > 0);
	return hooks.read(0);
}

template<typename heap_hooks>
typename heap_hooks::heap_item remove_minimum(heap_hooks &hooks) {
	typename heap_hooks::heap_item minimum = get_minimum(hooks);
	idx_remove(hooks, 0);
	return minimum;
}

template<typename heap_hooks>
void became_less(heap_hooks &hooks, typename heap_hooks::heap_item item) {
	typename heap_hooks::index_type index = hooks.get_index(item);
	idx_became_less(hooks, index);
}

}}}; /* namespace util::heaps::binary */

