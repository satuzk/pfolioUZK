

namespace util {
namespace performance {

typedef uint64_t counter;

//#define UTIL_PERFORMANCE_GETTIMEOFDAY
#ifdef UTIL_PERFORMANCE_GETTIMEOFDAY
#include <sys/time.h>
counter current() {
	struct timeval time_struct;
	if(gettimeofday(&time_struct, NULL) != 0)
		SYS_CRITICAL("gettimeofday() failed\n");
	return time_struct.tv_sec * 1000LL * 1000LL * 1000LL + time_struct.tv_usec * 1000LL;
}
#else
#include <time.h>
counter current() {
	timespec time_struct;
	if(clock_gettime(CLOCK_THREAD_CPUTIME_ID, &time_struct) != 0)
		SYS_CRITICAL("clock_gettime() failed\n");
	return time_struct.tv_sec * 1000LL * 1000LL * 1000LL + time_struct.tv_nsec;
}
#endif

counter elapsed(counter since) {
	return current() - since;
}

}};

