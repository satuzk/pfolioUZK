
/* applies HLE to the given clause */
template<typename Hooks>
void hle_elim_clause(Hooks &hooks, typename Hooks::literal_type literal,
		typename Hooks::clause_type clause) {
	std::vector<typename Hooks::literal_type> new_literals;
	for(auto i = hooks.clause_begin(clause);
			i != hooks.clause_end(clause); ++i) {
		auto inverse = hooks.lit_inverse(*i);
		/* we have to pay special attention when checking
			binary clauses. for now do not check them */
		if(hooks.clause_length(clause) > 2
				&& hooks.lit_getflag_hla(inverse)
				&& !hooks.lit_getflag_hla(*i)) {
			/* we found a hidden tautology */
			hooks.stat.simp.hte_clauses++;
			hooks.delete_queue_push(clause);
			return;
		}else if(*i != literal && hooks.lit_getflag_hla(*i)) {
			/* we found a hidden literal */
			hooks.stat.simp.hle_literals++;
			continue;
		}
		new_literals.push_back(*i);
	}

	if(new_literals.size() == 1) {
		hooks.fact_queue_push(new_literals.front());
	}else{
		auto new_clause = hooks.clause_alloc(new_literals.size(),
				new_literals.begin(), new_literals.end());
		if(hooks.clause_head(clause)->get_essential())
			hooks.clause_head(new_clause)->set_essential(true);

		hooks.delete_queue_push(clause);
		hooks.install_queue_push(new_clause);
	}
}

static uint64_t hle_count = 0;

/* applies HLE to all clauses containing the literal */
template<typename Hooks>
void hle_elim_literal(Hooks &hooks, typename Hooks::literal_type literal,
		std::vector<typename Hooks::literal_type> &hla_array) {
	hla_build(hooks, literal, hla_array);
	hle_count++;

	/* check whether the literal is a failed literal */
	auto inverse = hooks.lit_inverse(literal);
	if(hooks.lit_getflag_hla(inverse)) {
		hooks.fact_queue_push(literal);
		hooks.stat.simp.fle2_literals++;
	}else{
		for(auto i = hooks.occur_begin(literal); i != hooks.occur_end(literal); ++i) {
			if(hooks.delete_queue_contains(*i))
				continue;
			hle_elim_clause(hooks, literal, *i);
		}
	}
	hla_cleanup(hooks, hla_array);
	hla_array.clear();
}

/* applies HLE to all variables */
template<typename Hooks>
void hle_eliminate_all(Hooks &hooks) {
	std::vector<typename Hooks::literal_type> hla_array;
	for(typename Hooks::variable_type var = 0;
			var < hooks.p_var_config.count(); ++var) {
		if(hooks.p_var_config.get_varflag_deleted(var))
			continue;
		hle_elim_literal(hooks, hooks.zero_literal(var), hla_array);
		hle_elim_literal(hooks, hooks.one_literal(var), hla_array);
	}
	hooks.install_queue_process();
	hooks.fact_queue_process();
	hooks.eliminate_facts();
	hooks.install_queue_process();
	hooks.delete_queue_process();
	hooks.check_garbage();
}

