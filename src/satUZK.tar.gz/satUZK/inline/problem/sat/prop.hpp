
namespace problem {
namespace sat {
namespace prop {

template<typename Literal>
struct decision_struct {
	/* index of the first assignment belonging to this decision level */
	Literal first_index;
};

template<typename Literal, typename Order,
		typename DecLevel>
class config_struct {
public:
	typedef Literal literal_type;
	typedef DecLevel declevel_type;
	typedef Order order_type;

	typedef std::vector<Literal> assign_vector;

	typedef decision_struct<Literal> decision_info;
	typedef std::vector<decision_info> decision_vector;

	config_struct() : p_prop_pointer(0) { }

	DecLevel decision_level() {
		return p_decisions.size();
	}
	
	Order current_order() {
		return p_assigns.size();
	}
	Order prop_pointer() {
		return p_prop_pointer;
	}

	void new_decision() {
		/* PRE-CONDITION: no assignments have been
				pushed but not propagated yet */
		SYS_ASSERT(SYS_ASRT_GENERAL, props_left() == false);

		decision_info decision;
		decision.first_index = p_assigns.size();
		p_decisions.push_back(decision);
	}
	decision_info &peek_decision() {
		return p_decisions.back();
	}
	decision_info pop_decision() {
		/* PRE-CONDITION: the assign stack contains no assigns
				that were pushed AFTER the current decision level. */
		decision_info info = p_decisions.back();
		SYS_ASSERT(SYS_ASRT_GENERAL, info.first_index == p_assigns.size());
		SYS_ASSERT(SYS_ASRT_GENERAL, info.first_index == p_prop_pointer);
		
		p_decisions.pop_back();
		return info;
	}

	Literal assign_index() {
		return p_assigns.size();
	}
	void push_assign(Literal literal) {
		p_assigns.push_back(literal);
	}
	Literal get_assign(Order order) {
		return p_assigns[order];
	}
	Literal peek_assign() {
		return p_assigns.back();
	}
	Literal pop_assign() {
		/* PRE-CONDITION: the top-most literal on the assign stack
				is from the current decision level */
		decision_info info = p_decisions.back();
		SYS_ASSERT(SYS_ASRT_GENERAL, p_assigns.size() > p_prop_pointer);
		SYS_ASSERT(SYS_ASRT_GENERAL, p_assigns.size() > info.first_index);
		
		Literal literal = p_assigns.back();
		p_assigns.pop_back();
		return literal;
	}
	unsigned int assigns_at(declevel_type declevel) {
		SYS_ASSERT(SYS_ASRT_GENERAL, declevel > 0);
		if(declevel == decision_level())
			return p_assigns.size()
				- p_decisions[declevel - 1].first_index;
		return p_decisions[declevel].first_index
				- p_decisions[declevel - 1].first_index;
	}
	unsigned int assign_first(declevel_type declevel) {
		return p_decisions[declevel - 1].first_index;
	}
	unsigned int assign_last(declevel_type declevel) {
		if(declevel == decision_level())
			return p_assigns.size();
		return p_decisions[declevel].first_index;
	}

	void props_reset() {
		decision_info info = p_decisions.back();
		p_prop_pointer = info.first_index;
	}
	bool props_left() {
		return p_prop_pointer != p_assigns.size();
	}
	literal_type next_prop() {
		literal_type literal = p_assigns[p_prop_pointer];
		p_prop_pointer++;
		return literal;
	}

private:
	assign_vector p_assigns;
	decision_vector p_decisions;
	order_type p_prop_pointer;
};

}}}; /* namespace problem::sat::prop */

