
template<typename Hooks, typename Callback>
bool propagate_big(Hooks &hooks, Callback &callback,
		typename Hooks::literal_type literal) {
	for(auto i = hooks.big_begin(literal); i != hooks.big_end(literal); ++i) {
		/* if the literal is already true there is nothing to do */
		typename Hooks::literal_type implied = (*i).literal;
		if(hooks.lit_true(implied))
			continue;

		/* otherwise there might be a conflict */
		if(hooks.lit_false(implied)) {
			auto var = hooks.lit_getvar(implied);
			auto declevel = hooks.var_declevel(var);
			SYS_ASSERT(SYS_ASRT_GENERAL, declevel == hooks.cur_declevel());
			hooks.on_conflict(Hooks::conflict_type::make_binary(literal,
					hooks.lit_inverse(implied)));
			return true;
		}else{
			hooks.push_assign(implied,
					Hooks::antecedent_type::make_binary(literal));
			callback.on_unit(implied);
		}
	}
	return false;
}

template<typename Hooks, typename Callback>
bool propagate_watch(Hooks &hooks, Callback &callback,
		typename Hooks::literal_type literal) {
	auto begin = hooks.p_var_config.watch_begin(literal);
	auto end = hooks.p_var_config.watch_end(literal);
	auto wp = begin;
	for(auto rp = begin; rp != end; ++rp) {
		/* try to avoid inspecting the clause */
		auto blocking = (*rp).blocking; 
		auto clause = (*rp).clause;
		if(hooks.lit_true(blocking)) {
			(*wp).clause = clause;
			(*wp).blocking = blocking;
			++wp;
			continue;
		}

		auto trigger = hooks.lit_inverse(literal);
		auto current1 = hooks.clause_get_first(clause);
		auto current2 = hooks.clause_get_second(clause);
		SYS_ASSERT(SYS_ASRT_GENERAL, trigger == current1 || trigger == current2);

		/* reorder the current literals so that the
			eventually unassigned one comes first.
			write that literal to index #1 */
		if(current1 == trigger) {
			current1 = current2;
			current2 = trigger;
		}
		hooks.clause_set_first(clause, current1);
		
		/* case 1: a watched literal is true */
		if(hooks.lit_true(current1)) {
			hooks.clause_set_second(clause, current2);
			(*wp).clause = clause;
			(*wp).blocking = current1;
			++wp;
			continue;
		}
		auto var = hooks.lit_getvar(current1);	
		
		/* try to find an unassigned literal.
			write that literal to index #2 */
		for(auto it = hooks.clause_begin3(clause);
				it != hooks.clause_end(clause); ++it) {
			typename Hooks::literal_type lit = *it;
			if(!hooks.lit_false(lit)) {
				/* case 4: the are is a unassigned literal */
				hooks.clause_set_second(clause, lit);
				*it = current2;
			
				/* the propagated literal is no longer watched */
				typename Hooks::watch_entry_type entry;
				entry.clause = clause;
				entry.blocking = current1;
				hooks.watchlist_insert(hooks.lit_inverse(lit), entry);
				goto next_clause;
			}
		} 
			
		/* the propagated literal is still watched */
		hooks.clause_set_second(clause, current2);
		(*wp).clause = clause;
		(*wp).blocking = current1;
		++wp;
	
		if(hooks.var_assigned(var)) {
			/* case 4: the clause is unsat */
			/* both current1 and current2 are false but current2
				(with is trigger) can be a decision literal. */
			hooks.on_conflict(Hooks::conflict_type::make_clause(clause));
			
			/* copy the remaining watch list, including the current entry */
			++rp;
			while(rp != end) {
				*wp = *rp;
				++rp; ++wp;
			}
			hooks.p_var_config.watch_cutoff(literal, wp);
			return true;
		}else{
			/* case 5: the clause is unit */
			hooks.push_assign(current1, Hooks::antecedent_type::make_clause(clause));
			callback.on_unit(current1);

			/* update the literal-block-distance */
			unsigned int cur_lbd = hooks.clause_get_lbd(clause);
			unsigned int new_lbd = problem::sat::lbd::of_clause
						<Hooks, 15>(hooks, clause);
			if(new_lbd + 1 < cur_lbd) {
				hooks.clause_head(clause)->set_improved();
				hooks.clause_set_lbd(clause, new_lbd);
			}
		}
		next_clause:;
	}
	hooks.p_var_config.watch_cutoff(literal, wp);
	return false;
}

template<typename Hooks, typename Callback>
bool contra_propagate_watch(Hooks &hooks, Callback &callback,
		typename Hooks::literal_type literal) {
	auto begin = hooks.p_var_config.watch_begin(literal);
	auto end = hooks.p_var_config.watch_end(literal);
	auto wp = begin;
	for(auto rp = begin; rp != end; ++rp) {
		/* try to avoid inspecting the clause */
		auto blocking = (*rp).blocking; 
		auto clause = (*rp).clause;
		if(hooks.lit_true(blocking)) {
			(*wp).clause = clause;
			(*wp).blocking = blocking;
			++wp;
			continue;
		}

		auto trigger = hooks.lit_inverse(literal);
		auto current1 = hooks.clause_get_first(clause);
		auto current2 = hooks.clause_get_second(clause);
		SYS_ASSERT(SYS_ASRT_GENERAL, trigger == current1 || trigger == current2);

		/* reorder the current literals so that the
			eventually unassigned one comes first.
			write that literal to index #1 */
		if(current1 == trigger) {
			current1 = current2;
			current2 = trigger;
		}
		hooks.clause_set_first(clause, current1);
		
		/* case 1: a watched literal is true */
		if(hooks.lit_true(current1)) {
			hooks.clause_set_second(clause, current2);
			(*wp).clause = clause;
			(*wp).blocking = current1;
			++wp;
			continue;
		}
		auto var = hooks.lit_getvar(current1);	
		
		/* try to find an unassigned literal.
			write that literal to index #2 */
		for(auto it = hooks.clause_begin3(clause);
				it != hooks.clause_end(clause); ++it) {
			typename Hooks::literal_type lit = *it;
			if(!hooks.lit_false(lit)) {
				/* case 4: the are is a unassigned literal */
				*it = hooks.clause_get_third(clause);
				hooks.clause_set_third(clause, current2);
				hooks.clause_set_second(clause, lit);
			
				/* the propagated literal is no longer watched */
				typename Hooks::watch_entry_type entry;
				entry.clause = clause;
				entry.blocking = current1;
				hooks.watchlist_insert(hooks.lit_inverse(lit), entry);
				goto next_clause;
			}
		} 
			
		/* the propagated literal is still watched */
		hooks.clause_set_second(clause, current2);
		(*wp).clause = clause;
		(*wp).blocking = current1;
		++wp;
	
		if(hooks.var_assigned(var)) {
			/* case 4: the clause is unsat */
			/* both current1 and current2 are false but current2
				(with is trigger) can be a decision literal. */
			hooks.on_conflict(Hooks::conflict_type::make_clause(clause));
			
			/* copy the remaining watch list, including the current entry */
			++rp;
			while(rp != end) {
				*wp = *rp;
				++rp; ++wp;
			}
			hooks.p_var_config.watch_cutoff(literal, wp);
			return true;
		}else{
			unsigned int cur_lbd = hooks.clause_get_lbd(clause);

			auto current3 = hooks.clause_get_third(clause);
			auto level3 = hooks.var_declevel(hooks.lit_getvar(current3));

			/* case 5: the clause is unit */
			typename Hooks::contra_entry entry;
			entry.literal = current1;
			entry.antecedent = Hooks::antecedent_type::make_clause(clause);
			entry.glue = level3;
			hooks.contra_queue.push(entry);

			/* update the literal-block-distance */
			hooks.lbd_init();
			hooks.lbd_insert(hooks.cur_declevel());
			for(auto i = hooks.clause_begin2(clause);
					i != hooks.clause_end(clause); ++i) {
				auto v = hooks.lit_getvar(*i);
				hooks.lbd_insert(hooks.var_declevel(v));
			}
			for(auto i = hooks.clause_begin2(clause);
					i != hooks.clause_end(clause); ++i) {
				auto v = hooks.lit_getvar(*i);
				hooks.lbd_cleanup(hooks.var_declevel(v));
			}
			unsigned int new_lbd = hooks.lbd_result();
			if(new_lbd + 1 < cur_lbd) {
				hooks.clause_head(clause)->set_improved();
				hooks.clause_set_lbd(clause, new_lbd);
			}
		}
		next_clause:;
	}
	hooks.p_var_config.watch_cutoff(literal, wp);
	return false;
}

