
template<typename BaseTypes>
struct antecedent_struct {
	static const uint32_t TYPE_NONE = 0;
	static const uint32_t TYPE_DECISION = 1;
	static const uint32_t TYPE_CLAUSE = 2;
	static const uint32_t TYPE_BINARY = 3;
	uint32_t type;
	union {
		uint32_t padding;
		typename BaseTypes::clause_type clause_ident;
		typename BaseTypes::literal_type binary_ident;
	} identifier;

	static antecedent_struct<BaseTypes> make_none() {
		antecedent_struct<BaseTypes> antecedent;
		antecedent.type = TYPE_NONE;
		antecedent.identifier.padding = 0;
		return antecedent;
	}
	static antecedent_struct<BaseTypes> make_decision() {
		antecedent_struct<BaseTypes> antecedent;
		antecedent.type = TYPE_DECISION;
		antecedent.identifier.padding = 0;
		return antecedent;
	}
	static antecedent_struct<BaseTypes> make_clause
			(typename BaseTypes::clause_type clause) {
		antecedent_struct<BaseTypes> antecedent;
		antecedent.type = TYPE_CLAUSE;
		antecedent.identifier.clause_ident = clause;
		return antecedent;
	}
	static antecedent_struct<BaseTypes> make_binary
			(typename BaseTypes::literal_type literal) {
		antecedent_struct<BaseTypes> antecedent;
		antecedent.type = TYPE_BINARY;
		antecedent.identifier.binary_ident = literal;
		return antecedent;
	}

	bool operator== (antecedent_struct<BaseTypes> other) {
		if(type != other.type)
			return false;
		if(identifier.padding != other.identifier.padding)
			return false;
		return true;
	}
	bool operator!= (antecedent_struct<BaseTypes> other) {
		return !(*this == other);
	}

	bool is_decision() {
		return type == TYPE_DECISION;
	}
	bool is_clause() {
		return type == TYPE_CLAUSE;
	}
	bool is_binary() {
		return type == TYPE_BINARY;
	}

	typename BaseTypes::clause_type get_clause() {
		return identifier.clause_ident;
	}
	typename BaseTypes::literal_type get_binary() {
		return identifier.binary_ident;
	}
};

template<typename BaseTypes>
struct conflict_struct {
	static const uint32_t TYPE_NONE = 0;
	static const uint32_t TYPE_CLAUSE = 1;
	static const uint32_t TYPE_BINARY = 2;
	static const uint32_t TYPE_FACT = 3;
	uint32_t type;
	union {
		struct {
			uint32_t p1;
			uint32_t p2;
		} padding;
		typename BaseTypes::clause_type clause;
		struct {
			typename BaseTypes::literal_type l1;
			typename BaseTypes::literal_type l2;
		} literals;
	};

	static conflict_struct<BaseTypes> make_none() {
		conflict_struct<BaseTypes> result;
		result.type = TYPE_NONE;
		result.padding.p1 = 0;
		result.padding.p2 = 0;
		return result;
	}
	static conflict_struct<BaseTypes> make_clause
			(typename BaseTypes::clause_type clause) {
		conflict_struct<BaseTypes> result;
		result.padding.p1 = 0;
		result.padding.p2 = 0;
		result.type = TYPE_CLAUSE;
		result.clause = clause;
		return result;
	}
	static conflict_struct<BaseTypes> make_binary
			(typename BaseTypes::literal_type literal1,
			typename BaseTypes::literal_type literal2) {
		conflict_struct<BaseTypes> result;
		result.padding.p1 = 0;
		result.padding.p2 = 0;
		result.type = TYPE_BINARY;
		result.literals.l1 = literal1;
		result.literals.l2 = literal2;
		return result;
	}
	static conflict_struct<BaseTypes> make_fact
			(typename BaseTypes::literal_type literal) {
		conflict_struct<BaseTypes> result;
		result.padding.p1 = 0;
		result.padding.p2 = 0;
		result.type = TYPE_FACT;
		result.literals.l1 = literal;
		return result;
	}
	template<typename Hooks>
	static conflict_struct<BaseTypes> from_antecedent(Hooks &hooks,
			typename BaseTypes::literal_type literal,
			typename BaseTypes::antecedent_type antecedent) {
		if(antecedent.is_binary()) {
			auto implied = antecedent.get_binary();
			return make_binary(literal, hooks.lit_inverse(implied));
		}else if(antecedent.is_clause()) {
			auto clause = antecedent.get_clause();
			return make_clause(clause);
		}else SYS_CRITICAL("Cannot convert antecedent to conflict\n");
	}

	bool operator== (antecedent_struct<BaseTypes> other) {
		if(type != other.type)
			return false;
		if(padding != other.padding)
			return false;
		return true;
	}
	bool operator!= (antecedent_struct<BaseTypes> other) {
		return !(*this == other);
	}

	bool is_none() {
		return type == TYPE_NONE;
	}
	bool is_clause() {
		return type == TYPE_CLAUSE;
	}
	bool is_binary() {
		return type == TYPE_BINARY;
	}
	bool is_fact() {
		return type == TYPE_FACT;
	}

	typename BaseTypes::clause_type get_clause() {
		return clause;
	}
	typename BaseTypes::literal_type get_literal1() {
		return literals.l1;
	}
	typename BaseTypes::literal_type get_literal2() {
		return literals.l2;
	}
};

template<typename Config>
class cause_iterator_struct {
public:
	cause_iterator_struct(Config &config,
			typename Config::antecedent_type antecedent,
			typename Config::litindex_type index)
			: p_config(config), p_antecedent(antecedent), p_index(index) { }

	static cause_iterator_struct begin(Config &config,
			typename Config::antecedent_type antecedent) {
		return cause_iterator_struct(config, antecedent, 0);
	}
	static cause_iterator_struct end(Config &config,
			typename Config::antecedent_type antecedent) {
		if(antecedent.is_binary()) {
			return cause_iterator_struct(config, antecedent, 1);
		}else if(antecedent.is_clause()) {
			typename Config::clause_type clause = antecedent.get_clause();
			return cause_iterator_struct(config, antecedent,
					config.clause_length(clause) - 1);
		}else if(antecedent.is_decision()) {
			SYS_CRITICAL("Decision antecedent\n");
		}else SYS_CRITICAL("Illegal antecedent\n");
	}

	void operator++ () {
		++p_index;
	}
	bool operator== (const cause_iterator_struct<Config> &other) const {
		return p_index == other.p_index;
	}
	bool operator!= (const cause_iterator_struct<Config> &other) const {
		return p_index != other.p_index;
	}
	typename Config::literal_type operator* () {
		if(p_antecedent.is_binary()) {
			SYS_ASSERT(SYS_ASRT_GENERAL, p_index == 0);
			return p_antecedent.get_binary();
		}else if(p_antecedent.is_clause()) {
			typename Config::clause_type clause = p_antecedent.get_clause();
			return p_config.lit_inverse(p_config.clause_get(clause, p_index + 1));
		}else SYS_CRITICAL("Illegal antecedent\n");
	}
	
private:
	Config &p_config;
	typename Config::antecedent_type p_antecedent;
	typename Config::litindex_type p_index;
};

template<typename Config>
class conflict_iterator_struct {
public:
	conflict_iterator_struct(Config &config,
			typename Config::conflict_type conflict,
			typename Config::litindex_type index)
			: p_config(config), p_conflict(conflict), p_index(index) { }

	static conflict_iterator_struct begin(Config &config,
			typename Config::conflict_type conflict) {
		return conflict_iterator_struct(config, conflict, 0);
	}
	static conflict_iterator_struct end(Config &config,
			typename Config::conflict_type conflict) {
		if(conflict.is_fact()) {
			return conflict_iterator_struct(config, conflict, 1);
		}else if(conflict.is_binary()) {
			return conflict_iterator_struct(config, conflict, 2);
		}else if(conflict.is_clause()) {
			typename Config::clause_type clause = conflict.get_clause();
			return conflict_iterator_struct(config, conflict,
					config.clause_length(clause));
		}else SYS_CRITICAL("Illegal conflict\n");
	}

	void operator++ () {
		++p_index;
	}
	bool operator== (const conflict_iterator_struct<Config> &other) const {
		return p_index == other.p_index;
	}
	bool operator!= (const conflict_iterator_struct<Config> &other) const {
		return p_index != other.p_index;
	}
	typename Config::literal_type operator* () {
		if(p_conflict.is_fact()) {
			SYS_ASSERT(SYS_ASRT_GENERAL, p_index == 0);
			return p_conflict.get_literal1();
		}else if(p_conflict.is_binary() && p_index == 0) {
			return p_conflict.get_literal1();
		}else if(p_conflict.is_binary() && p_index == 1) {
			return p_conflict.get_literal2();
		}else if(p_conflict.is_clause()) {
			typename Config::clause_type clause = p_conflict.get_clause();
			return p_config.lit_inverse(p_config.clause_get(clause, p_index));
		}else SYS_CRITICAL("Illegal conflict\n");
	}
	
private:
	Config &p_config;
	typename Config::conflict_type p_conflict;
	typename Config::litindex_type p_index;
};

