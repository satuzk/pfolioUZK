
template<typename Hooks>
class dist_literals_lt_struct {
public:
	dist_literals_lt_struct(Hooks &hooks) : p_hooks(hooks) { }

	bool operator() (typename Hooks::literal_type literal1,
			typename Hooks::literal_type literal2) {
		auto var1 = p_hooks.lit_getvar(literal1);
		auto var2 = p_hooks.lit_getvar(literal2);
		if(p_hooks.var_activity(var1) > p_hooks.var_activity(var2))
			return true;
		return false;
	}

private:
	Hooks &p_hooks;
};

template<typename Hooks>
class dist_clause_activity_order {
public:
	dist_clause_activity_order(Hooks &hooks) : p_hooks(hooks) { }
	
	bool operator() (typename Hooks::clause_type clause1,
			typename Hooks::clause_type clause2) {
		return p_hooks.clause_activity(clause1)
				> p_hooks.clause_activity(clause2);
	}

private:
	Hooks &p_hooks;
};

template<typename Hooks>
class dist_clauses_lt_struct {
public:
	dist_clauses_lt_struct(Hooks &hooks) : p_hooks(hooks) { }

	float weight(typename Hooks::clause_type clause) {
		float w = 0;
		for(auto i = p_hooks.clause_begin(clause); i != p_hooks.clause_end(clause); ++i)
			w += p_hooks.var_activity(p_hooks.lit_getvar(*i));
		w /= p_hooks.clause_length(clause);
		return w;
	}

	bool operator() (typename Hooks::clause_type clause1,
			typename Hooks::clause_type clause2) {
//		if(p_hooks.clause_length(clause1) > p_hooks.clause_length(clause2))
//			return true;
/*		if(p_hooks.clause_head(clause1)->get_lbd() == 0)
			return false;
		if(p_hooks.clause_head(clause2)->get_lbd() == 0)
			return true;
		
		if(p_hooks.clause_head(clause1)->get_lbd() < p_hooks.clause_head(clause2)->get_lbd())
			return true;
		return false;*/
//		return p_hooks.clause_length(clause1) > p_hooks.clause_length(clause2);
		return weight(clause1) > weight(clause2);
	}

private:
	Hooks &p_hooks;
};

template<typename Hooks>
void dist_visit(Hooks &hooks,
		typename Hooks::literal_type literal,
		std::vector<bool> &marked,
		std::vector<typename Hooks::literal_type> &visited,
		std::vector<typename Hooks::literal_type> &reasons) {
	SYS_ASSERT(SYS_ASRT_GENERAL, !marked[literal]);
	SYS_ASSERT(SYS_ASRT_GENERAL, hooks.lit_true(literal));
	marked[literal] = true;
	visited.push_back(literal);
	
	auto var = hooks.lit_getvar(literal);
	if(hooks.var_declevel(var) == 1)
		return;

	auto antecedent = hooks.var_antecedent(var);
	if(antecedent == Hooks::antecedent_type::make_decision()) {
		reasons.push_back(literal);
	}else if(antecedent != Hooks::antecedent_type::make_decision()) {
		for(auto i = hooks.causes_begin(antecedent);
				i != hooks.causes_end(antecedent); ++i) {
			if(marked[*i])
				continue;
			dist_visit(hooks, *i, marked, visited, reasons);
		}
	}
}

template<typename Hooks>
void dist_cleanup(Hooks &hooks,
		std::vector<bool> &marked,
		std::vector<typename Hooks::literal_type> &visited,
		std::vector<typename Hooks::literal_type> &reasons) {
	for(auto i = visited.begin(); i != visited.end(); ++i)
		marked[*i] = false;
	visited.clear();
	reasons.clear();
}

template<typename Hooks>
void dist_conflict(Hooks &hooks,
		typename Hooks::clause_type clause,
		bool &remove_clause,
		std::vector<bool> &marked,
		std::vector<typename Hooks::literal_type> &visited,
		std::vector<typename Hooks::literal_type> &reasons,
		uint64_t &stat_removed_lits) {
	for(auto i = Hooks::conflict_iterator::begin(hooks, hooks.conflict_desc);
			i != Hooks::conflict_iterator::end(hooks, hooks.conflict_desc); ++i) {
		if(marked[*i])
			continue;
		dist_visit(hooks, *i, marked, visited, reasons);
	}

	if(reasons.size() < hooks.clause_length(clause)) {
		std::vector<typename Hooks::literal_type> new_literals;
		for(auto j = reasons.begin(); j != reasons.end(); ++j)
			new_literals.push_back(hooks.lit_inverse(*j));
		
		if(new_literals.size() == 1) {
			hooks.fact_queue_push(new_literals.front());
		}else if(new_literals.size() == 2) {
			hooks.binary_create(new_literals.front(), new_literals.back());
		}else{
			auto new_clause = hooks.clause_alloc(new_literals.size(),
					new_literals.begin(), new_literals.end());
			if(hooks.clause_head(clause)->get_essential())
				hooks.clause_head(new_clause)->set_essential(true);
			hooks.clause_set_lbd(new_clause, hooks.clause_get_lbd(clause));
			hooks.clause_set_activity(new_clause, hooks.clause_activity(clause));
			hooks.install_queue_push(new_clause);
			hooks.clause_head(new_clause)->flags |= Hooks::clause_head_type::CHECKED_DIST;
		}
		remove_clause = true;
		hooks.stat.simp.dist_conflicts++;
		unsigned int removed_lits = hooks.clause_length(clause)
				- new_literals.size();
		hooks.stat.simp.dist_conflicts_removed += removed_lits;
		stat_removed_lits += removed_lits;
	}
	dist_cleanup(hooks, marked, visited, reasons);
}

template<typename Hooks>
void dist_assert(Hooks &hooks,
		typename Hooks::clause_type clause,
		typename Hooks::literal_type asserted,
		bool &remove_clause,
		std::vector<bool> &marked,
		std::vector<typename Hooks::literal_type> &visited,
		std::vector<typename Hooks::literal_type> &reasons,
		uint64_t &stat_removed_lits) {
	dist_visit(hooks, asserted, marked, visited, reasons);

	if(hooks.var_declevel(hooks.lit_getvar(asserted)) != 1
			&& reasons.size() + 1 < hooks.clause_length(clause)) {
		std::vector<typename Hooks::literal_type> new_literals;
		for(auto j = reasons.begin(); j != reasons.end(); ++j)
			new_literals.push_back(hooks.lit_inverse(*j));
		new_literals.push_back(asserted);
		
		SYS_ASSERT(SYS_ASRT_GENERAL, new_literals.size() > 1);
		if(new_literals.size() == 2) {
			hooks.binary_create(new_literals.front(), new_literals.back());
		}else{
			auto new_clause = hooks.clause_alloc(new_literals.size(),
					new_literals.begin(), new_literals.end());
			if(hooks.clause_head(clause)->get_essential())
				hooks.clause_head(new_clause)->set_essential(true);
			hooks.clause_set_lbd(new_clause, hooks.clause_get_lbd(clause));
			hooks.clause_set_activity(new_clause, hooks.clause_activity(clause));
			hooks.install_queue_push(new_clause);
			hooks.clause_head(new_clause)->flags |= Hooks::clause_head_type::CHECKED_DIST;
		}
		remove_clause = true;
		hooks.stat.simp.dist_asserts++;
		unsigned int removed_lits = hooks.clause_length(clause)
				- new_literals.size();
		hooks.stat.simp.dist_asserts_removed += removed_lits;
		stat_removed_lits += removed_lits;
	}

	dist_cleanup(hooks, marked, visited, reasons);
}

template<typename Hooks>
void dist_single(Hooks &hooks, typename Hooks::clause_type clause,
		typename Hooks::literal_type to_assert,
		std::vector<bool> &marked,
		std::vector<typename Hooks::literal_type> &visited,
		std::vector<typename Hooks::literal_type> &reasons,
		uint64_t &stat_removed_lits) {
	SYS_ASSERT(SYS_ASRT_GENERAL, hooks.cur_declevel() == 1);
	SYS_ASSERT(SYS_ASRT_GENERAL, !hooks.at_conflict());

//FIXME:	unsigned int lbd = hooks.clause_head(clause)->get_lbd();

	std::vector<typename Hooks::literal_type> literals;
	for(auto i = hooks.clause_begin(clause);
			i != hooks.clause_end(clause); ++i) {
		if(hooks.lit_true(*i))
			return;
		literals.push_back(*i);
	}

	dist_literals_lt_struct<Hooks> order(hooks);
	std::sort(literals.begin(), literals.end(), order);

	bool remove_clause = false;
	for(auto i = literals.begin(); i != literals.end(); ++i) {
		auto var = hooks.lit_getvar(*i);
		if(hooks.lit_false(*i))
			continue;
		if(hooks.lit_true(*i)) {
			if(hooks.var_antecedent(var)
					!= Hooks::antecedent_type::make_clause(clause))
				dist_assert(hooks, clause, *i, remove_clause, marked,
						visited, reasons, stat_removed_lits);
			break;
		}
			
		/* assign the i-th literal of the clause */
		hooks.watch_compact_fast();
		hooks.push_declevel();
		hooks.push_assign(hooks.lit_inverse(*i),
				Hooks::antecedent_type::make_decision());
		hooks.propagate();
		if(hooks.at_conflict()) {
			break;
		}
	}
	if(hooks.at_conflict()) {
		dist_conflict(hooks, clause, remove_clause, marked, visited,
				reasons, stat_removed_lits);
	}
	while(hooks.at_conflict()) {
		if(hooks.is_unsatisfiable())
			return;
		hooks.resolve();
		hooks.propagate();
	}
	hooks.backjump(1);
	
	hooks.install_queue_process();
	hooks.fact_queue_process();
	if(hooks.is_unsatisfiable())
		return;
	if(remove_clause && !hooks.clause_locked(clause))
		hooks.clause_delete(clause);
	hooks.stat.simp.dist_checks++;
/*	if((hooks.stat.simp.dist_checks % 100) == 0)
		std::cout << "c [DIST  ]    checked: " << hooks.stat.simp.dist_checks
				<< ", up to lbd: " << lbd
				<< ", conflicts: " << hooks.stat.simp.dist_conflicts
				<< ", asserts: " << hooks.stat.simp.dist_asserts
				<< std::endl;*/
}

template<typename Hooks, typename Heuristics>
void dist_eliminate_all(Hooks &hooks, Heuristics &heuristics) {
	std::vector<bool> marked;
	std::vector<typename Hooks::literal_type> visited;
	std::vector<typename Hooks::literal_type> reasons;
	marked.resize(hooks.p_var_config.count() * 2, false);

	std::vector<typename Hooks::clause_type> queue;
	for(auto i = hooks.clauses_begin(); i != hooks.clauses_end(); ++i) {
		if(!hooks.clause_present(*i))
			continue;
		if(hooks.clause_head(*i)->flags & Hooks::clause_head_type::CHECKED_DIST)
			continue;
//		if(!(hooks.clause_head(*i)->flags & Hooks::clause_head_type::CREATED_VECD))
//			continue;
		if(hooks.clause_length(*i) < 5)
			continue;
		//if(hooks.clause_length(*i) < hooks.opts.simp.dist_min_length)
		//	continue;
		queue.push_back(*i);
	}
	dist_clauses_lt_struct<Hooks> order(hooks);
	std::sort(queue.begin(), queue.end(), order);
	
	std::cout << "c [DIST  ]    pre-selected clauses: " << queue.size() << std::endl;
	
	util::performance::counter total_elapsed = 0;

	unsigned int total_runs = 0;
	uint64_t total_removed_lits = 0;

	auto i = queue.begin();
	while(true) {
		auto run_start = util::performance::current();

		uint64_t run_removed_lits = 0;

		for(unsigned int k = 0; k < 300 && i != queue.end(); ++i, ++k) {
			if(!hooks.clause_present(*i))
				continue;
			dist_single(hooks, *i, hooks.clause_get_first(*i),
					marked, visited, reasons, run_removed_lits);
			hooks.clause_head(*i)->flags |= Hooks::clause_head_type::CHECKED_DIST;
			if(hooks.is_unsatisfiable())
				return;
		}
		auto run_elapsed = util::performance::elapsed(run_start);
		heuristics.run_stats(run_removed_lits, run_elapsed);
		
		total_elapsed += run_elapsed;
		total_runs++;
		total_removed_lits += run_removed_lits;

		if(i == queue.end()) {
			std::cout << "c [DIST  ] processed whole queue" << std::endl;
			break;
		}
		if(!heuristics.another_run(run_removed_lits, run_elapsed,
				total_runs, total_removed_lits, total_elapsed))
			break;
	}

	hooks.eliminate_facts();
	hooks.install_queue_process();
	hooks.check_garbage();
}

template<typename Hooks>
void dist_eliminate_active(Hooks &hooks, unsigned int num_runs) {
	std::vector<bool> marked;
	std::vector<typename Hooks::literal_type> visited;
	std::vector<typename Hooks::literal_type> reasons;
	marked.resize(hooks.p_var_config.count() * 2, false);

	std::vector<typename Hooks::clause_type> queue;
	for(auto i = hooks.clauses_begin(); i != hooks.clauses_end(); ++i) {
		if(!hooks.clause_present(*i))
			continue;
		if(hooks.clause_length(*i) < 5)
			continue;
		//if(hooks.clause_length(*i) < hooks.opts.simp.dist_min_length)
		//	continue;
		queue.push_back(*i);
	}
	dist_clause_activity_order<Hooks> order(hooks);
	std::sort(queue.begin(), queue.end(), order);
	
	if(hooks.opts.general.verbose > 1)
		std::cout << "c [DIST  ]    pre-selected clauses: " << queue.size() << std::endl;
	
	uint64_t run_removed_lits = 0;

	auto i = queue.begin();
	for(unsigned int k = 0; k < num_runs && i != queue.end(); ++i, ++k) {
		if(!hooks.clause_present(*i)) {
			k--;
			continue;
		}
		dist_single(hooks, *i, hooks.clause_get_first(*i),
				marked, visited, reasons, run_removed_lits);
		hooks.clause_head(*i)->flags |= Hooks::clause_head_type::CHECKED_DIST;
		if(hooks.is_unsatisfiable())
			return;
	}
//	if(i == queue.end())
//		std::cout << "c [DIST  ] processed whole queue" << std::endl;
		
	hooks.eliminate_facts();
	hooks.install_queue_process();
	hooks.check_garbage();
}

