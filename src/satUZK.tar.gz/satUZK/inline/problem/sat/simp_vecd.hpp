
template<typename Hooks>
bool resolvent_length(Hooks &hooks,
		typename Hooks::clause_type clause,
		typename Hooks::literal_type literal,
		typename Hooks::literal_type implied,
		unsigned int &length) {
	length = hooks.clause_length(clause);
	for(auto i = hooks.clause_begin(clause);
			i != hooks.clause_end(clause); ++i) {
		if(*i == implied)
			length--;
		if(*i == hooks.lit_inverse(implied))
			return true;
	}
	return false;
}

template<typename Hooks>
bool resolvent_build(Hooks &hooks,
		typename Hooks::clause_type clause,
		typename Hooks::literal_type literal,
		typename Hooks::literal_type implied,
		std::vector<typename Hooks::literal_type> &resolvent) {
	bool okay = false;
	for(auto i = hooks.clause_begin(clause);
			i != hooks.clause_end(clause); ++i) {
		if(*i == literal) {
			okay = true;
			continue;
		}
		if(*i == implied)
			continue;
		if(*i == hooks.lit_inverse(implied))
			return true;
		resolvent.push_back(*i);
	}
	SYS_ASSERT(SYS_ASRT_GENERAL, okay); /*FIXME*/
	resolvent.push_back(implied);
	return false;
}

template<typename Hooks>
bool vecd_reasonable(Hooks &hooks,
		typename Hooks::variable_type variable) {
	unsigned int resolvents = 0;
	typename Hooks::literal_type zero_lit = hooks.zero_literal(variable);
	typename Hooks::literal_type one_lit = hooks.one_literal(variable);
	unsigned int zero_count = 0;
	unsigned int one_count = 0;

	/* count original clauses */
	for(auto i = hooks.occur_begin(zero_lit); i != hooks.occur_end(zero_lit); ++i) {
		if(!hooks.clause_present(*i))
			continue;
		zero_count++;
	}
	for(auto i = hooks.occur_begin(one_lit); i != hooks.occur_end(one_lit); ++i) {
		if(!hooks.clause_present(*i))
			continue;
		one_count++;
	}
	zero_count += hooks.big_size(one_lit);
	one_count += hooks.big_size(zero_lit);
	
	/* count binary-binary resolvents */
	for(auto i = hooks.big_begin(zero_lit); i != hooks.big_end(zero_lit); ++i) {
		auto zero_implied = (*i).literal;
		for(auto j = hooks.big_begin(one_lit); j != hooks.big_end(one_lit); ++j) {
			auto one_implied = (*j).literal;
			if(zero_implied == one_implied) /* TODO: a unit can be derived in this case */
				continue;
			if(zero_implied == hooks.lit_inverse(one_implied))
				continue;
			resolvents++;
		}
	}

	/* count binary-long resolvents */
	for(auto i = hooks.big_begin(zero_lit); i != hooks.big_end(zero_lit); ++i) {
		auto implied = (*i).literal;
		for(auto j = hooks.occur_begin(zero_lit); j != hooks.occur_end(zero_lit); ++j) {
			if(!hooks.clause_present(*j))
				continue;

			unsigned int length;
			if(resolvent_length(hooks, *j, zero_lit, implied, length))
				continue;
			resolvents++;
			if(resolvents > zero_count + one_count)
				return false;
			if(length > 10)
				return false;
		}
	}
	for(auto i = hooks.big_begin(one_lit); i != hooks.big_end(one_lit); ++i) {
		auto implied = (*i).literal;
		for(auto j = hooks.occur_begin(one_lit); j != hooks.occur_end(one_lit); ++j) {
			if(!hooks.clause_present(*j))
				continue;

			unsigned int length;
			if(resolvent_length(hooks, *j, one_lit, implied, length))
				continue;
			resolvents++;
			if(resolvents > zero_count + one_count)
				return false;
			if(length > 10)
				return false;
		}
	}

	/* count long-long resolvents */
	for(auto i = hooks.occur_begin(zero_lit); i != hooks.occur_end(zero_lit); ++i) {
		if(!hooks.clause_present(*i))
			continue;
		for(auto j = hooks.occur_begin(one_lit); j != hooks.occur_end(one_lit); ++j) {
			if(!hooks.clause_present(*j))
				continue;
			unsigned int length;
			if(hooks.resolvent_length(*i, *j, variable, length))
				continue;
			resolvents++;
			if(resolvents > zero_count + one_count)
				return false;
			if(length > 10)
				return false;
		}
	}
	return true;
}

template<typename Hooks>
void vecd_eliminate_single(Hooks &hooks,
		typename Hooks::variable_type variable) {
	SYS_ASSERT(SYS_ASRT_GENERAL, hooks.cur_declevel() == 1);
	SYS_ASSERT(SYS_ASRT_GENERAL, hooks.fact_count() == 0);
	SYS_ASSERT(SYS_ASRT_GENERAL, !hooks.at_conflict());
	SYS_ASSERT(SYS_ASRT_GENERAL, hooks.install_queue_length() == 0);
	SYS_ASSERT(SYS_ASRT_GENERAL, hooks.bin_install_queue_length() == 0);

	problem::sat::extmodel::push_distributed(hooks,
			hooks.extmodel_config, hooks.extmodel_alloc, variable);

	std::vector<typename Hooks::clause_type> added;

	typename Hooks::literal_type zero_lit = hooks.zero_literal(variable);
	typename Hooks::literal_type one_lit = hooks.one_literal(variable);
	
	/* build all binary-binary resolvents */
	for(auto i = hooks.big_begin(zero_lit); i != hooks.big_end(zero_lit); ++i) {
		auto zero_implied = (*i).literal;
		for(auto j = hooks.big_begin(one_lit); j != hooks.big_end(one_lit); ++j) {
			auto one_implied = (*j).literal;
			if(zero_implied == one_implied) {
				/* var=0 and var=1 both imply the same literal */
				hooks.fact_queue_push(zero_implied);
			}else if(zero_implied != hooks.lit_inverse(one_implied)) {
				hooks.bin_install_queue_push(zero_implied, one_implied);
			}
		}
	}

	/* build all binary-long resolvents */
	for(auto i = hooks.big_begin(zero_lit); i != hooks.big_end(zero_lit); ++i) {
		auto implied = (*i).literal;
		for(auto j = hooks.occur_begin(zero_lit); j != hooks.occur_end(zero_lit); ++j) {
			if(!hooks.clause_present(*j))
				continue;

			std::vector<typename Hooks::literal_type> res_lits;
			if(resolvent_build(hooks, *j, zero_lit, implied, res_lits))
				continue;
			if(res_lits.size() == 1) {
				hooks.fact_queue_push(res_lits.front());
				hooks.stat.simp.vecd_facts++;
			}else if(res_lits.size() == 2) {
				hooks.bin_install_queue_push(res_lits.front(), res_lits.back());
			}else{
				typename Hooks::clause_type res_clause = hooks.clause_alloc
						(res_lits.size(), res_lits.begin(), res_lits.end());
				if(hooks.clause_head(*j)->get_essential())
					hooks.clause_head(res_clause)->set_essential(true);
				hooks.clause_head(res_clause)->flags |= Hooks::clause_head_type::CREATED_VECD;
				hooks.install_queue_push(res_clause);
				added.push_back(res_clause);
			}
		}
	}
	for(auto i = hooks.big_begin(one_lit); i != hooks.big_end(one_lit); ++i) {
		auto implied = (*i).literal;
		for(auto j = hooks.occur_begin(one_lit); j != hooks.occur_end(one_lit); ++j) {
			if(!hooks.clause_present(*j))
				continue;

			std::vector<typename Hooks::literal_type> res_lits;
			if(resolvent_build(hooks, *j, one_lit, implied, res_lits))
				continue;
			if(res_lits.size() == 1) {
				hooks.fact_queue_push(res_lits.front());
				hooks.stat.simp.vecd_facts++;
			}else if(res_lits.size() == 2) {
				hooks.bin_install_queue_push(res_lits.front(), res_lits.back());
			}else{
				typename Hooks::clause_type res_clause = hooks.clause_alloc
						(res_lits.size(), res_lits.begin(), res_lits.end());
				if(hooks.clause_head(*j)->get_essential())
					hooks.clause_head(res_clause)->set_essential(true);
				hooks.clause_head(res_clause)->flags |= Hooks::clause_head_type::CREATED_VECD;
				hooks.install_queue_push(res_clause);
				added.push_back(res_clause);
			}
		}
	}

	/* build all long-long resolvents */
	for(auto i = hooks.occur_begin(zero_lit); i != hooks.occur_end(zero_lit); ++i) {
		if(!hooks.clause_present(*i))
			continue;
		for(auto j = hooks.occur_begin(one_lit); j != hooks.occur_end(one_lit); ++j) {
			if(!hooks.clause_present(*j))
				continue;
			if(hooks.resolvent_trivial(*i, *j, variable))
				continue;
			
			auto res_lits = hooks.resolvent_build(*i, *j, variable);
			if(res_lits.size() == 1) {
				hooks.fact_queue_push(res_lits.front());
				hooks.stat.simp.vecd_facts++;
			}else if(res_lits.size() == 2) {
				hooks.bin_install_queue_push(res_lits.front(), res_lits.back());
			}else{
				typename Hooks::clause_type res_clause = hooks.clause_alloc
						(res_lits.size(), res_lits.begin(), res_lits.end());
				if(hooks.clause_head(*i)->get_essential()
						|| hooks.clause_head(*j)->get_essential())
					hooks.clause_head(res_clause)->set_essential(true);
				hooks.clause_head(res_clause)->flags |= Hooks::clause_head_type::CREATED_VECD;
				hooks.install_queue_push(res_clause);
				added.push_back(res_clause);
			}
		}
	}
	
	/* delete all clauses containing the variable */
	for(auto i = hooks.occur_begin(zero_lit);
			i != hooks.occur_end(zero_lit); ++i) {
		if(!hooks.clause_present(*i))
			continue;
		hooks.clause_delete(*i);
	}
	for(auto i = hooks.occur_begin(one_lit);
			i != hooks.occur_end(one_lit); ++i) {
		if(!hooks.clause_present(*i))
			continue;
		hooks.clause_delete(*i);
	}

	/* delete all binary implications containing the variable */
	for(auto i = hooks.big_begin(zero_lit); i != hooks.big_end(zero_lit); ++i) {
		auto lit = hooks.lit_inverse((*i).literal);
		hooks.big_remove(lit, one_lit);
	}
	for(auto i = hooks.big_begin(one_lit); i != hooks.big_end(one_lit); ++i) {
		auto lit = hooks.lit_inverse((*i).literal);
		hooks.big_remove(lit, zero_lit);
	}
	hooks.big_clear(zero_lit);
	hooks.big_clear(one_lit);

	/* it is important that we install new clauses before
		processing the next variable as one of the next variables
		might occur in those clauses. */
	hooks.install_queue_process();
	hooks.bin_install_queue_process();
	hooks.fact_queue_process2();
	if(hooks.is_unsatisfiable())
		return;
	hooks.eliminate_facts();
	hooks.install_queue_process();

	for(auto i = added.begin(); i != added.end(); ++i) {
		if(!hooks.clause_present(*i))
			continue;
		if(hooks.clause_length(*i) == 2)
			continue;
		bce_eliminate_single(hooks, *i);
	}

	hooks.stat_vecd_elim++;
}

template<typename Hooks>
void vecd_eliminate_all(Hooks &hooks,
		unsigned int &stat_elim_vars) {
	std::vector<typename Hooks::variable_type> queue;
	for(typename Hooks::variable_type var = 0; var < hooks.p_var_config.count(); ++var) {
		if(hooks.p_var_config.get_varflag_deleted(var))
			continue;
		queue.push_back(var);
	}
	for(auto i = queue.begin(); i != queue.end(); ++i) {
		if(!vecd_reasonable(hooks, *i))
			continue;
		vecd_eliminate_single(hooks, *i);
		
		hooks.p_var_config.var_delete(*i);
		stat_elim_vars++;

		if(hooks.is_unsatisfiable())
			return;
	}
	hooks.check_garbage();
}

