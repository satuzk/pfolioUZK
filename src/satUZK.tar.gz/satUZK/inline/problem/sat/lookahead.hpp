
template<typename Hooks>
void lookahead_analyze(Hooks &hooks,
		typename Hooks::literal_type literal,
		float &branch_score, unsigned int &new_clauses) {
	typename Hooks::literal_type inverse = hooks.lit_inverse(literal);
	for(auto i = hooks.occur_begin(inverse);
			i != hooks.occur_end(inverse); ++i) {
		if(hooks.clause_sat(*i))
			continue;
		branch_score++;
		new_clauses++;
	}
}

template<typename Hooks>
bool lookahead_literal(Hooks &hooks,
		typename Hooks::literal_type literal,
		float &branch_score, unsigned int &new_clauses) {
	typename Hooks::declevel_type declevel = hooks.cur_declevel();

	hooks.push_declevel();
	hooks.push_assign(literal, Hooks::antecedent_type::make_decision());
	hooks.propagate();
	
	if(hooks.at_conflict()) {
		while(hooks.at_conflict()) {
			std::cout << "Conflict" << std::endl;
			if(!hooks.is_resolveable())
				return true;
			hooks.resolve();
			hooks.propagate();
		}
		return true;
	}
	lookahead_analyze(hooks, literal, branch_score, new_clauses);

	hooks.backjump(declevel);

	return false;
}

static int nums = 0;

template<typename Hooks>
typename Hooks::literal_type lookahead_perform(Hooks &hooks,
		std::vector<typename Hooks::literal_type> literals) {
	std::cout << "Lookahead " << nums++ << "  " << hooks.cur_declevel() << std::endl;
	while(true) {
		bool restart = false;
		float best_score = 0;
		typename Hooks::literal_type best_literal = Hooks::ILLEGAL_LIT;
		for(auto i = literals.begin(); i != literals.end(); ++i) {
			if(hooks.var_assigned(hooks.lit_getvar(*i)))
				continue;
			
			float branch_score = 0;
			unsigned int new_clauses = 0;
			
			/* if there was a conflict during the lookahead we
				restart the whole lookahead procedure */
			if(lookahead_literal(hooks, *i, branch_score, new_clauses)) {
				if(hooks.at_conflict()) /* conflict cannot be resolved */
					return Hooks::ILLEGAL_LIT;
				restart = true;
				break;
			}
			
			if(best_literal == Hooks::ILLEGAL_LIT || branch_score > best_score) {
				best_score = branch_score;
				best_literal = *i;
			}
		}
		if(restart)
			continue;
		return best_literal;
	};
}

