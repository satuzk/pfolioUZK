
template<typename Hooks>
typename Hooks::literal_type hla_asymmetric_check(Hooks &hooks,
		typename Hooks::literal_type clause) {
	typename Hooks::literal_type hidden = Hooks::ILLEGAL_LIT;
	for(auto i = hooks.clause_begin(clause);
			i != hooks.clause_end(clause); ++i) {
		if(hooks.lit_getflag_hla(*i))
			continue;
		if(hidden != Hooks::ILLEGAL_LIT)
			return Hooks::ILLEGAL_LIT;
		hidden = *i;
	}
	return hidden;
}

template<typename Hooks>
void hla_asymmetric(Hooks &hooks,
		typename Hooks::literal_type for_literal,
		std::vector<typename Hooks::literal_type> &array) {
	for(auto i = hooks.occur_begin(for_literal);
			i != hooks.occur_end(for_literal); ++i) {
		auto hidden = hla_asymmetric_check(hooks, *i);
		if(hidden == Hooks::ILLEGAL_LIT)
			continue;
		
		auto inverse = hooks.lit_inverse(hidden);
		if(hooks.lit_getflag_hla(inverse))
			continue;
		hooks.lit_setflag_hla(inverse);
		array.push_back(inverse);
	}
}

/* adds all literals reachable from the given one to the array */
template<typename Hooks>
void hla_append(Hooks &hooks,
		typename Hooks::literal_type for_literal,
		std::vector<typename Hooks::literal_type> &array) {
	/* HLA contains exactly the inverses of all literals
		that are reachable from the inverse of the given literal */
	auto for_inverse = hooks.lit_inverse(for_literal);
	for(auto j = hooks.big_begin(for_inverse);
			j != hooks.big_end(for_inverse); ++j) {
		auto literal = hooks.lit_inverse((*j).literal);
		
		/* mark literals so we dont add the same one twice */
		if(hooks.lit_getflag_hla(literal))
			continue;
		hooks.lit_setflag_hla(literal);
		array.push_back(literal);
	}
}

/* build the hidden literal addition of a literal */
template<typename Hooks>
void hla_build(Hooks &hooks,
		typename Hooks::literal_type for_literal,
		std::vector<typename Hooks::literal_type> &array) {
	/* note: array.size() changes during the iteration */
	hla_append(hooks, for_literal, array);
	for(unsigned int i = 0; i != array.size(); ++i)
		hla_append(hooks, array[i], array);
	/* the following assertion holds if BIG has no cycles */
//	SYS_ASSERT(SYS_ASRT_GENERAL, !hooks.lit_getflag_hla(for_literal));
}

/* cleans up the hla flags of all literals in the array */
template<typename Hooks>
void hla_cleanup(Hooks &hooks,
		std::vector<typename Hooks::literal_type> &array) {
	for(auto i = array.begin(); i != array.end(); ++i)
		hooks.lit_clearflag_hla(*i);
}

