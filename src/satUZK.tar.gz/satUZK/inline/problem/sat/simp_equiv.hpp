
template<typename Hooks>
void equiv_replace_clause(Hooks &hooks,
		typename Hooks::clause_type clause) {
	int changes = 0;
	std::vector<typename Hooks::literal_type> new_literals;
	for(auto j = hooks.clause_begin(clause);
			j != hooks.clause_end(clause); ++j) {
		auto equiv = hooks.p_var_config.equiv_root(*j);
		auto inverse = hooks.p_var_config.equiv_root(hooks.lit_inverse(*j));
		SYS_ASSERT(SYS_ASRT_GENERAL, inverse == hooks.lit_inverse(equiv));
		
		if(equiv != *j)
			changes++;		

		/* TODO: unfortunately this has quadratic runtime */
		if(std::find(new_literals.begin(), new_literals.end(), equiv)
				!= new_literals.end())
			continue;
		if(std::find(new_literals.begin(), new_literals.end(), inverse)
				!= new_literals.end()) {
			hooks.clause_delete(clause);
			return;
		}
		new_literals.push_back(equiv);
	}
	if(changes == 0)
		return;
	
	if(new_literals.size() == 1) {
		hooks.fact_queue_push(new_literals.front());
	}else if(new_literals.size() == 2) {
		hooks.binary_create(new_literals.front(), new_literals.back());
	}else{
		auto new_clause = hooks.clause_alloc(new_literals.size(),
				new_literals.begin(), new_literals.end());
		if(hooks.clause_head(clause)->get_essential())
			hooks.clause_head(new_clause)->set_essential(true);
		hooks.install_queue_push(new_clause);
	}
	hooks.clause_delete(clause);
}

template<typename Hooks>
void equiv_replace_all(Hooks &hooks) {
	/* FIXME: inefficient, store the queue globally */
	std::vector<typename Hooks::variable_type> var_queue;
	for(typename Hooks::variable_type var = 0;
			var < hooks.p_var_config.count(); ++var) {
		if(hooks.p_var_config.get_varflag_deleted(var))
			continue;
		
		auto l0 = hooks.zero_literal(var);
		auto l1 = hooks.one_literal(var);
		auto root0 = hooks.p_var_config.equiv_root(l0);
		auto root1 = hooks.p_var_config.equiv_root(l1);

		SYS_ASSERT(SYS_ASRT_GENERAL, root0 != root1);
		SYS_ASSERT(SYS_ASRT_GENERAL, ((root0 != l0) && (root1 != l1))
				|| ((root0 == l0) && (root1 == l1)));
		SYS_ASSERT(SYS_ASRT_GENERAL, root0 == hooks.lit_inverse(root1));

		if(root0 != l0) {
			problem::sat::extmodel::push_equivalent(hooks, hooks.extmodel_config,
					hooks.extmodel_alloc, var, root0);
//			std::cout << "l0: " << (int)hooks.lit_state(l0).value
//				<< ", root0: " << (int)hooks.lit_state(root0).value << std::endl;
//			if(!(hooks.lit_state(root0).value & 2))
//				std::cout << "  declevel: " << hooks.var_declevel(hooks.lit_getvar(root0)) << std::endl;
			SYS_ASSERT(SYS_ASRT_GENERAL, hooks.lit_state(l0) == hooks.lit_state(root0));
			hooks.p_var_config.var_delete(var);

			var_queue.push_back(var);
		}
	}

	for(auto i = var_queue.begin(); i != var_queue.end(); ++i) {
		auto zero_lit = hooks.zero_literal(*i);
		auto one_lit = hooks.one_literal(*i);
		auto zero_root = hooks.p_var_config.equiv_root(zero_lit);
		auto one_root = hooks.p_var_config.equiv_root(one_lit);
		
		/* replace binary clauses */
		for(auto i = hooks.big_begin(zero_lit); i != hooks.big_end(zero_lit); ++i) {
			auto lit = (*i).literal;
			auto root = hooks.p_var_config.equiv_root(lit);
			
			/* root == zero_root the clause would be trivial */
			if(root == one_root) {
				hooks.fact_queue_push(one_root);
			}else if(root != zero_root) {
				hooks.binary_create(one_root, root);
			}
			hooks.big_remove(hooks.lit_inverse(lit), one_lit);
		}
		for(auto i = hooks.big_begin(one_lit); i != hooks.big_end(one_lit); ++i) {
			auto lit = (*i).literal;
			auto root = hooks.p_var_config.equiv_root(lit);
			
			/* root == one_root the clause would be trivial */
			if(root == zero_root) {
				hooks.fact_queue_push(zero_root);
			}else if(root != one_root) {
				hooks.binary_create(zero_root, root);
			}
			hooks.big_remove(hooks.lit_inverse(lit), zero_lit);
		}
		hooks.big_clear(zero_lit);
		hooks.big_clear(one_lit);
	}

	std::vector<typename Hooks::clause_type> queue;
	for(auto i = hooks.clauses_begin(); i != hooks.clauses_end(); ++i) {
		if(!hooks.clause_present(*i))
			continue;
		queue.push_back(*i);
	}
	while(queue.size() > 0) {
		equiv_replace_clause(hooks, queue.back());
		queue.pop_back();
	}
	hooks.install_queue_process();
	hooks.fact_queue_process2();
	if(hooks.is_unsatisfiable())
		return;
	hooks.eliminate_facts();
	hooks.install_queue_process();
	hooks.check_garbage();
}

