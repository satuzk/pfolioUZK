
enum solve_state2 {
	unknown,
	conflict,
	satisfied,
	unsatisfiable
};

namespace prog {
namespace sat_core {

template<typename Config>
class var_heap_hooks_struct {
public:
	typedef uint32_t index_type;
	typedef typename Config::variable_type heap_item;
	
	static const uint32_t ILLEGAL_INDEX = (index_type)(-1);

	var_heap_hooks_struct(Config &config) : p_config(config) { }

	bool is_less(heap_item left, heap_item right) {
		/* NOTE: we want a maximum heap so we are comparing for ">" */
		return p_config.var_activity(left) > p_config.var_activity(right);
	}

	void on_init(heap_item variable, index_type index) {
//		std::cout << "Inserting " << variable << " into heap" << std::endl;
		SYS_ASSERT(SYS_ASRT_GENERAL, p_config.var_get_heap_index(variable)
				== ILLEGAL_INDEX);
		p_config.var_set_heap_index(variable, index);
	}
	void on_remove(heap_item variable) {
//		std::cout << "Removing " << variable << " from heap" << std::endl;
		SYS_ASSERT(SYS_ASRT_GENERAL, p_config.var_get_heap_index(variable)
				!= ILLEGAL_INDEX);
		p_config.var_set_heap_index(variable, ILLEGAL_INDEX);
	}
	void on_update(heap_item variable, index_type index) {
		SYS_ASSERT(SYS_ASRT_GENERAL, p_config.var_get_heap_index(variable)
				!= ILLEGAL_INDEX);
		p_config.var_set_heap_index(variable, index);
	}

	index_type get_index(heap_item variable) {
		return p_config.var_get_heap_index(variable);
	}

	uint32_t get_heap_size() {
		return p_config.heap_size;
	}
	void inc_heap_size() {
		p_config.heap_size++;
	}
	void dec_heap_size() {
		p_config.heap_size--;
	}

	heap_item read(index_type index) {
		return p_config.heap_get(index);
	}
	void write(index_type index, heap_item variable) {
		p_config.heap_put(index, variable);
	}

private:
	Config &p_config;
};

template<typename Config>
class del_clause_callback_struct {
public:
	del_clause_callback_struct(Config &config) : p_config(config) { }

	void on_move(typename Config::clause_alloc_type &from_alloc,
			typename Config::clause_alloc_type &to_alloc,
			typename Config::clause_type from_index,
			typename Config::clause_type to_index) {
		p_config.on_clause_move(to_alloc, from_index, to_index);
		p_config.on_clause_collect(from_index);
	}

private:
	Config &p_config;
};

template<typename Config>
class work_clause_lt_struct {
public:
	work_clause_lt_struct(Config &config) : p_config(config) { }

	bool operator() (typename Config::clause_type left,
			typename Config::clause_type right) {
		if((p_config.clause_get_lbd(left) < 4 || p_config.clause_get_lbd(right) < 4)
				&& (p_config.clause_get_lbd(left) != p_config.clause_get_lbd(right)))
			return p_config.clause_get_lbd(left) < p_config.clause_get_lbd(right);
		
		return p_config.clause_get_activity(left)
				> p_config.clause_get_activity(right);
	}

private:
	Config &p_config;
};

template<typename Config>
class clause_glue_lt_struct {
public:
	clause_glue_lt_struct(Config &config) : p_config(config) { }

	bool operator() (typename Config::clause_type left,
			typename Config::clause_type right) {
		if(p_config.clause_get_lbd(left) != p_config.clause_get_lbd(right))
			return p_config.clause_get_lbd(left) < p_config.clause_get_lbd(right);
		
		return p_config.clause_get_activity(left)
				> p_config.clause_get_activity(right);
	}

private:
	Config &p_config;
};

template<typename Hooks>
class propagate_callback_struct {
public:
	void on_unit(typename Hooks::literal_type literal) { }
};

template<typename Literal, typename LitIndex, typename Clause,
		typename Order, typename Activity, typename DecLevel>
class config_struct {
public:
	typedef Literal literal_type;
	typedef Literal variable_type;
	typedef LitIndex litindex_type;
	typedef Clause clause_type;
	typedef Order order_type;
	typedef Activity activity_type;
	typedef DecLevel declevel_type;
	
	static const variable_type ILLEGAL_VAR = (variable_type)(-1);
	static const literal_type ILLEGAL_LIT = (literal_type)(-1);
	static const clause_type ILLEGAL_CLAUSE = (clause_type)(-1);

	static const int clause_alignment = 8;

	typedef config_struct<Literal, LitIndex, Clause, Order, Activity, DecLevel> config_type;

	typedef antecedent_struct<config_struct> antecedent_type;
	typedef conflict_struct<config_struct> conflict_type;

public:
	typedef problem::sat::vars::config_struct
			<Literal, DecLevel, Clause, antecedent_type, Activity> var_config_type;

	typedef util::memory::bulk_alloc::allocator<Literal> clause_alloc_type;
	typedef problem::sat::packed_clause::config_type
			<Literal, LitIndex, Activity, Clause> clause_config_type;
	typedef typename clause_config_type::head_type clause_head_type;

	typedef uint64_t clause_sig_type;

	typedef problem::sat::prop::config_struct
			<Literal, Order, DecLevel> prop_config_type;

	typedef problem::sat::first_uip::config_struct
			<variable_type, Literal> learn_config_type;

	typedef var_heap_hooks_struct<config_type> var_heap_hooks_type;

public:
	typedef typename var_config_type::occur_iterator occur_iterator;

	typedef typename var_config_type::watchlist_iterator watch_iterator;
	typedef typename var_config_type::watchlist_entry watch_entry_type;
	typedef typename var_config_type::watchlist_entry watchlist_entry;
	
	typedef typename var_config_type::bt_watch_entry_type bt_watch_entry_type;
	
	typedef typename var_config_type::bt_watch_entry_type big_edge_type;
	typedef typename var_config_type::bt_watch_iterator big_iterator;

	typedef typename clause_config_type::index_iterator clause_iterator;
	typedef problem::sat::packed_clause::iterator_struct
			<clause_config_type, clause_alloc_type> clauselit_iterator;

	typedef cause_iterator_struct<config_type> cause_iterator;
	typedef conflict_iterator_struct<config_type> conflict_iterator;

	/* visitor and callback classes */
	typedef del_clause_callback_struct<config_type> del_clause_callback_type;

	typedef problem::sat::extmodel::config_struct extmodel_config_type;
	typedef problem::sat::extmodel::stack_allocator extmodel_alloc_type;

public:
	config_struct() : p_clause_alloc(clause_alignment), assigned_count(0),
			conflict_desc(conflict_type::make_none()),
			unsatisfiable(false), have_occlists(false), heap_size(0) {
		clause_memsize = 4 * 1024 * 1024;
		
//		std::cout << "c [GC    ] Initial clause space: " << (clause_memsize / 1024) << " kb" << std::endl;
	
		/* allocate memory for clauses */
		void *memory = operator new(clause_memsize);
		p_clause_alloc.init_memory(memory, clause_memsize);

		/* push decision level number zero */
		push_declevel();

		rnd_engine.seed(0x12345678);

		var_act_inc = 1.0f;
		var_act_factor = 1.05f;
		clause_act_inc = 1.0f;
		clause_act_factor = 1.05f;

		conflict_num = 0;
		learned_units = 0;
		learned_binary = 0;

		learned_clauses = 0;

		del_clause_limit = 2000;
		del_clause_number = 0;

		restart_num = 0;
		restart_counter = 100;
		restart_scale = 100;
		restart_period = restart_scale * luby_period(restart_num);

		lits_in_learned = 0;
		stat_propagations = 0;
		stat_learned_lits = 0;
		stat_minimized_lits = 0;
		stat_blocked_clauses = 0;
		stat_vecd_elim = 0;
		stat.general.clause_reallocs = 0;
		stat.search.fact_elim_runs = 0;
		stat.search.fact_elim_clauses = 0;
		stat.search.fact_elim_literals = 0;

		stat.search.prop_time = 0;

		stat.simp.vecd_facts = 0;
		stat.simp.scc_variables = 0;
		stat.simp.fle2_literals = 0;
		stat.simp.brm_failed = 0;
		stat.simp.brm_equivalent = 0;
		stat.simp.brm_independent = 0;
		stat.simp.hle_literals = 0;
		stat.simp.hle_facts = 0;
		stat.simp.hte_clauses = 0;
		stat.simp.subsumed_clauses = 0;
		stat.simp.selfsub_facts = 0;
		stat.simp.selfsub_clauses = 0;
		stat.simp.dist_checks = 0;
		stat.simp.dist_conflicts = 0;
		stat.simp.dist_conflicts_removed = 0;
		stat.simp.dist_asserts = 0;
		stat.simp.dist_asserts_removed = 0;
		stat.simp.unhide_transitive = 0;
		stat.simp.unhide_failed = 0;
		stat.simp.unhide_hle = 0;
		stat.simp.unhide_hte = 0;

		stat.simp.scc_time = 0;
		stat.simp.fle2_time = 0;
		stat.simp.hle_time = 0;
		stat.simp.selfsub_time = 0;
		stat.simp.vecd_time = 0;
		stat.simp.bce_time = 0;

		perf.inproc_time = 0;
		perf.fact_elim_time = 0;

		opts.general.verbose = 0;
		opts.general.budget = 0;
		opts.general.timeout = 0;
		opts.general.permutate_input = false;
		
		opts.preproc.model = preproc_model_none;
		opts.preproc.with_scc = true;
		opts.preproc.with_fle2 = false;
		opts.preproc.with_hle = false;
		opts.preproc.with_selfsub = true;
		opts.preproc.with_vecd = true;
		opts.preproc.with_bce = true;
		opts.preproc.with_dist = false;
		opts.preproc.with_unhiding = true;
		opts.preproc.iterations = 1;

		opts.simp.dist_min_length = 8;
		
		opts.learn.bump_glue_twice = false;
		opts.learn.minimize_glucose = false;

		opts.clause_red.model = clause_red_model_geometric;
		opts.clause_red.agile_initial = 5000;
		opts.clause_red.agile_increment = 300;

		opts.restart.strategy = restart_strategy::luby;

		state.general.start_time = util::performance::current();
	}

	config_struct(const config_struct &) = delete;
	config_struct &operator= (const config_struct &) = delete;

	/* ----------------- variable related functions --------------- */
	variable_type var_alloc() {
		return p_var_config.alloc_var();
	}

	literal_type zero_literal(variable_type var) {
		return problem::sat::vars::get_zero<var_config_type>(var);
	}
	literal_type one_literal(variable_type var) {
		return problem::sat::vars::get_one<var_config_type>(var);
	}
	bool lit_is_one(literal_type literal) {
		return (literal & 1) != 0;
	}

	/* NOTE: does NOT handle the whole assignment operation,
			i.e. it is not sufficient to call this function in order
			to assign a value to a variable. */
	bool var_assigned(variable_type var) {
		return p_var_config.get_assign(var).is_assigned();
	}
	bool var_one(variable_type var) {
		return p_var_config.get_assign(var).is_one();
	}
	bool var_zero(variable_type var) {
		return p_var_config.get_assign(var).is_zero();
	}
	lbool_type var_state(variable_type var) {
		if(!var_assigned(var))
			return lundef();
		return (var_one(var) ? ltrue() : lfalse());
	}

	activity_type var_activity(variable_type var) {
		return p_var_config.get_heap_info(var).activity;
	}

	antecedent_type var_antecedent(variable_type var) {
		return p_var_config.get_antecedent(var);
	}
	declevel_type var_declevel(variable_type var) {
		return p_var_config.get_declevel(var);
	}
	uint32_t var_get_heap_index(variable_type var) {
		return p_var_config.get_heap_info(var).heap_index;
	}
	void var_set_heap_index(variable_type var, uint32_t heap_index) {
		p_var_config.get_heap_info(var).heap_index = heap_index;
	}

	/* returns true if the model value of the variable is one */
	bool model_get_variable(variable_type var) {
		return p_var_config.get_varflag_model(var);
	}
	void model_set_variable(variable_type var, bool value) {
		p_var_config.clear_varflag_model(var);
		if(value)
			p_var_config.set_varflag_model(var);
	}
	/* returns true if the model value of the literal is true */
	bool model_get_literal(literal_type lit) {
		if(lit_is_one(lit))
			return model_get_variable(lit_getvar(lit));
		return !model_get_variable(lit_getvar(lit));
	}
	void model_set_literal(literal_type lit) {
		if(lit_is_one(lit))
			return model_set_variable(lit_getvar(lit), true);
		return model_set_variable(lit_getvar(lit), false);
	}
	
	variable_type lit_getvar(literal_type literal) {
		return problem::sat::vars::get_var<var_config_type>(literal);
	}
	literal_type lit_inverse(literal_type literal) {
		return problem::sat::vars::get_inverse<var_config_type>(literal);
	}

	lbool_type lit_state(literal_type lit) {
		return var_state(lit_getvar(lit)) ^ !lit_is_one(lit);
	}

	bool lit_true(literal_type lit) {
		variable_type var = lit >> 1;
		uint8_t assign = p_var_config.get_assign(var).value;
		if(!(assign & 2))
			return false;
		return !((assign ^ lit) & 1);
//		return p_var_config.get_assign(lit >> 1).value == (2 | (lit & 1));
	//	variable_type var = problem::sat::vars::get_var<var_config_type>(lit);
	//	bool is_one = problem::sat::vars::is_one<var_config_type>(lit);
	//	return p_var_config.get_assign(var).lit_true(is_one);
	}
	bool lit_false(literal_type lit) {
		variable_type var = lit >> 1;
		uint8_t assign = p_var_config.get_assign(var).value;
		if(!(assign & 2))
			return false;
		return ((assign ^ lit) & 1);
//		return p_var_config.get_assign(lit >> 1).value == (2 | ((~lit) & 1));
//		variable_type var = problem::sat::vars::get_var<var_config_type>(lit);
//		bool is_one = problem::sat::vars::is_one<var_config_type>(lit);
//		return p_var_config.get_assign(var).lit_false(is_one);
	}

	cause_iterator causes_begin(antecedent_type antecedent) {
		return cause_iterator::begin(*this, antecedent);
	}
	cause_iterator causes_end(antecedent_type antecedent) {
		return cause_iterator::end(*this, antecedent);
	}
	cause_iterator causes_begin(variable_type variable) {
		antecedent_type antecedent = var_antecedent(variable);
		return cause_iterator::begin(*this, antecedent);
	}
	cause_iterator causes_end(variable_type variable) {
		antecedent_type antecedent = var_antecedent(variable);
		return cause_iterator::end(*this, antecedent);
	}

	bool lit_getflag_hla(literal_type lit) {
		return p_var_config.get_litflag_hla(lit);
	}
	void lit_setflag_hla(literal_type lit) {
		p_var_config.set_litflag_hla(lit);
	}
	void lit_clearflag_hla(literal_type lit) {
		p_var_config.clear_litflag_hla(lit);
	}
	
	void watchlist_insert(literal_type literal, watchlist_entry entry) {
		p_var_config.watchlist_insert(literal, entry);
	}
	void watch_insert(literal_type literal, literal_type blocking,
			clause_type clause) {
		watch_entry_type new_entry;
		new_entry.clause = clause;
		new_entry.blocking = blocking;
		p_var_config.watchlist_insert(literal, new_entry);
	}
	void watch_replace_clause(literal_type literal, clause_type clause,
			clause_type replacement) {
		for(auto i = p_var_config.watch_begin(literal);
				i != p_var_config.watch_end(literal); ++i) {
			if((*i).clause != clause)
				continue;
			(*i).clause = replacement;
			return;
		}
		SYS_CRITICAL("Clause not found\n");
	}
	void watch_remove_clause(literal_type literal, clause_type clause) {
		for(auto i = p_var_config.watch_begin(literal);
				i != p_var_config.watch_end(literal); ++i) {
			if((*i).clause != clause)
				continue;
			p_var_config.watch_erase(literal, i);
			return;
		}
		SYS_CRITICAL("Clause not found\n");
	}
	void watch_compact_single(literal_type literal) {
		if(!p_var_config.get_litflag_watch_removed(literal))
			return;
		auto j = p_var_config.watch_begin(literal);
		for(auto i = p_var_config.watch_begin(literal);
				i != p_var_config.watch_end(literal); ++i) {
			if(!clause_present((*i).clause))
				continue;
			*j = *i;
			++j;
		}
		p_var_config.watch_cutoff(literal, j);
		p_var_config.clear_litflag_watch_removed(literal);
	}
	void watch_compact_fast() {
		for(auto i = watch_removed_queue.begin();
				i != watch_removed_queue.end(); ++i)
			watch_compact_single(*i);
		watch_removed_queue.clear();
	}

	/* ----------- binary implication graph handling --------- */
	void big_insert(literal_type literal, literal_type implied) {
		SYS_ASSERT(SYS_ASRT_GENERAL, literal != implied);
		big_edge_type new_edge;
		new_edge.literal = implied;
		new_edge.flags = 0;
		p_var_config.big_insert(literal, new_edge);
	}
	void big_remove(literal_type literal, literal_type implied) {
		for(auto i = big_begin(literal); i != big_end(literal); ++i)
			if((*i).literal == implied) {
				p_var_config.big_erase(literal, i);
				return;
			}
		SYS_CRITICAL("Could not find implication\n");
	}
	void big_clear(literal_type literal) {
		return p_var_config.big_clear(literal);
	}
	big_iterator big_begin(literal_type literal) {
		return p_var_config.big_begin(literal);
	}
	big_iterator big_end(literal_type literal) {
		return p_var_config.big_end(literal);
	}
	unsigned int big_size(literal_type literal) {
		return p_var_config.big_size(literal);
	}
	big_iterator big_find(literal_type literal, literal_type implied) {
		for(auto i = big_begin(literal); i != big_end(literal); ++i)
			if((*i).literal == implied)
				return i;
		return big_end(literal);
	}
	bool big_contains(literal_type literal, literal_type implied) {
		for(auto i = big_begin(literal); i != big_end(literal); ++i)
			if((*i).literal == implied)
				return true;
		return false;
	}
	void big_compact_single(literal_type literal) {
		if(!p_var_config.get_litflag_big_removed(literal))
			return;
		auto j = p_var_config.big_begin(literal);
		for(auto i = p_var_config.big_begin(literal);
				i != p_var_config.big_end(literal); ++i) {
			if((*i).flags == 1)
				continue;
			*j = *i;
			++j;
		}
		p_var_config.big_cutoff(literal, j);
		p_var_config.clear_litflag_big_removed(literal);
	}
	
	void binary_create(literal_type lit1, literal_type lit2) {
		SYS_ASSERT(SYS_ASRT_GENERAL, lit1 != lit2);
		auto inv1 = lit_inverse(lit1);
		auto inv2 = lit_inverse(lit2);
		
		/* FIXME: incredibly expensive */
		//SYS_ASSERT(SYS_ASRT_GENERAL, (big_contains(inv1, lit2) && big_contains(inv2, lit1))
		//			|| (!big_contains(inv1, lit2) && !big_contains(inv2, lit1)));
		if(big_contains(inv1, lit2))
			return;
		big_insert(inv1, lit2);
		big_insert(inv2, lit1);
	}
	void binary_create_unchecked(literal_type lit1, literal_type lit2) {
		SYS_ASSERT(SYS_ASRT_GENERAL, lit1 != lit2);
		auto inv1 = lit_inverse(lit1);
		auto inv2 = lit_inverse(lit2);
		
		/* FIXME: incredibly expensive */
		//SYS_ASSERT(SYS_ASRT_GENERAL, (big_contains(inv1, lit2) && big_contains(inv2, lit1))
		//			|| (!big_contains(inv1, lit2) && !big_contains(inv2, lit1)));
		big_insert(inv1, lit2);
		big_insert(inv2, lit1);
	}
	
	/* ----------------- binary clause install queue --------------- */
	struct bin_install_entry {
		literal_type lit1;
		literal_type lit2;

		bin_install_entry(literal_type lit1, literal_type lit2) {
			this->lit1 = lit1 < lit2 ? lit1 : lit2;
			this->lit2 = lit1 < lit2 ? lit2 : lit1;
		}

		bool operator< (const bin_install_entry &other) const {
			if(lit1 != other.lit1)
				return lit1 < other.lit1;
			if(lit2 != other.lit2)
				return lit2 < other.lit2;
			return false;
		}
		bool operator== (const bin_install_entry &other) const {
			return (lit1 == other.lit1) && (lit2 == other.lit2);
		}
	};
	std::vector<bin_install_entry> bin_install_queue;

	void bin_install_queue_push(literal_type lit1, literal_type lit2) {
		bin_install_entry entry(lit1, lit2);
		bin_install_queue.push_back(entry);
	}
	unsigned int bin_install_queue_length() {
		return bin_install_queue.size();
	}
	void bin_install_queue_process() {
		for(auto i = bin_install_queue.begin();
				i != bin_install_queue.end(); ++i)
			binary_create((*i).lit1, (*i).lit2);
		bin_install_queue.clear();
	}
	void bin_install_queue_process_many() {
		std::sort(bin_install_queue.begin(), bin_install_queue.end());
		auto end = std::unique(bin_install_queue.begin(),
				bin_install_queue.end());
		for(auto i = bin_install_queue.begin(); i != end; ++i)
			binary_create_unchecked((*i).lit1, (*i).lit2);
		bin_install_queue.clear();
	}

	/* ------------------ clause related functions ----------------- */
	clause_head_type *clause_head(clause_type clause) {
		return problem::sat::packed_clause::get_head
				<clause_config_type, clause_alloc_type>(p_clause_alloc, clause);
	}
	typename clause_config_type::tail_type *clause_tail(clause_type clause) {
		return p_clause_config.get_tail(p_clause_alloc, clause);
	}

	/* allocates a clause and fills it with the given literals.
		NOTE: does NOT install watched literal etc. */
	template<typename Iterator>
	clause_type clause_alloc(litindex_type length, Iterator begin, Iterator end) {
		SYS_ASSERT(SYS_ASRT_GENERAL, length > 2);
	//	std::cout << p_clause_alloc.get_free_space() << " " << length << "\n";
		unsigned int mem_estimate = p_clause_config.calc_bytes(length)
				+ clause_alignment;
		/* ensure that there is enough free space for a new clause */
		if(p_clause_alloc.get_free_space() < mem_estimate)
			ensure_space(mem_estimate);
		
		// sanity check
/*		for(auto i = begin; i != end; ++i)
			for(auto j = begin; j != end; ++j) {
				if(i == j)
					continue;
				if(*i == *j || *i == lit_inverse(*j))
					SYS_CRITICAL("Illegal clause for clause_alloc()");
			}*/
		
		clause_type clause = problem::sat::packed_clause::new_clause
				(p_clause_config, p_clause_alloc, length);
		clause_head_type *head = problem::sat::packed_clause::get_head
				<clause_config_type, clause_alloc_type>(p_clause_alloc, clause);

		clause_sig_type signature = 0;
		unsigned int sig_size = sizeof(clause_sig_type) * 8;
		litindex_type k = 0;
		for(Iterator it = begin; it != end && k < length; ++it, ++k) {
			*(head->literal(k)) = *it;
			signature |= (1 << ((*it) % sig_size));
		}
		clause_set_sig(clause, signature);
		SYS_ASSERT(SYS_ASRT_GENERAL, k == length);
		return clause;
	}

	void clause_install(clause_type clause) {
		SYS_ASSERT(SYS_ASRT_GENERAL, !clause_head(clause)->get_installed());
		init_watchlist(clause);
		
		if(have_occlists) {
			/* insert the clause into the occurrence list */
			for(auto i = clause_begin(clause); i != clause_end(clause); ++i)
				p_var_config.occur_insert(*i, clause);
		}
	}
	void clause_uninstall() {

	}

	void clause_delete(clause_type clause) {
		SYS_ASSERT(SYS_ASRT_GENERAL, !clause_locked(clause));
		SYS_ASSERT(SYS_ASRT_GENERAL, !clause_head(clause)->get_delete());
		p_clause_config.set_delete(p_clause_alloc, clause);
		del_clause_number++;
		
		auto watch1 = clause_get_first(clause);
		auto watch2 = clause_get_second(clause);
		auto inv1 = lit_inverse(watch1);
		auto inv2 = lit_inverse(watch2);

		if(!p_var_config.get_litflag_watch_removed(inv1))
			watch_removed_queue.push_back(inv1);
		if(!p_var_config.get_litflag_watch_removed(inv2))
			watch_removed_queue.push_back(inv2);
		p_var_config.set_litflag_watch_removed(inv1);
		p_var_config.set_litflag_watch_removed(inv2);
		
		if(have_occlists)
			for(auto i = clause_begin(clause); i != clause_end(clause); ++i) {
				if(!p_var_config.get_litflag_occur_removed(*i))
					occur_removed_queue.push_back(*i);
				p_var_config.set_litflag_occur_removed(*i);
			}
	}
	bool clause_present(clause_type clause) {
		return !clause_head(clause)->get_delete();
	}

	template<typename Iterator>
	void clause_input(litindex_type length, Iterator begin, Iterator end) {
		if(length == 2) {
			literal_type lit1 = *begin; begin++;
			literal_type lit2 = *begin; begin++;
			SYS_ASSERT(SYS_ASRT_GENERAL, begin == end);
			bin_install_queue_push(lit1, lit2);
		}else{
			clause_type clause = clause_alloc(length, begin, end);
			clause_head(clause)->set_essential(true);
		}
	}
	void input_finish() {
		bin_install_queue_process_many();
	}

	clause_iterator clauses_begin() {
		return p_clause_config.begin();
	}
	clause_iterator clauses_end() {
		return p_clause_config.end();
	}

	unsigned int clause_space() {
		return p_clause_alloc.get_total_space()
			- p_clause_alloc.get_free_space();
	}

	litindex_type clause_length(clause_type clause) {
		clause_head_type *head = problem::sat::packed_clause::get_head
				<clause_config_type, clause_alloc_type>(p_clause_alloc, clause);
		return head->num_literals;
	}

	void clause_set_first(clause_type clause, literal_type literal)
			{ *(clause_head(clause)->literal(0)) = literal; }
	void clause_set_second(clause_type clause, literal_type literal)
			{ *(clause_head(clause)->literal(1)) = literal; }
	void clause_set_third(clause_type clause, literal_type literal)
			{ *(clause_head(clause)->literal(2)) = literal; }

	literal_type clause_get(clause_type clause, litindex_type index) {
		clause_head_type *head = problem::sat::packed_clause::get_head
				<clause_config_type, clause_alloc_type>(p_clause_alloc, clause);
		return *head->literal(index);
	}
	literal_type clause_get_first(clause_type clause)
			{ return clause_head(clause)->literals[0]; }
	literal_type clause_get_second(clause_type clause)
			{ return clause_head(clause)->literals[1]; }
	literal_type clause_get_third(clause_type clause)
			{ return clause_head(clause)->literals[2]; }

	clauselit_iterator clause_begin(clause_type clause) {
		return clauselit_iterator(p_clause_alloc, clause, 0);
	}
	clauselit_iterator clause_begin2(clause_type clause) {
		if(clause_length(clause) < 2)
			return clause_end(clause);
		return clauselit_iterator(p_clause_alloc, clause, 1);
	}
	clauselit_iterator clause_begin3(clause_type clause) {
		if(clause_length(clause) < 3)
			return clause_end(clause);
		return clauselit_iterator(p_clause_alloc, clause, 2);
	}
	clauselit_iterator clause_end(clause_type clause) {
		return clauselit_iterator(p_clause_alloc, clause,
				clause_length(clause));
	}

	activity_type clause_get_activity(clause_type clause) {
		return p_clause_config.get_tail(p_clause_alloc, clause)->activity;
	}
	void clause_inc_activity(clause_type clause, activity_type value) {
		clause_set_activity(clause, clause_get_activity(clause) + value);
	}
	void clause_scale_activity(clause_type clause, activity_type value) {
		clause_set_activity(clause, clause_get_activity(clause) / value);
	}

	clause_sig_type clause_get_sig(clause_type clause) {
		return clause_tail(clause)->signature;
	}
	void clause_set_sig(clause_type clause, clause_sig_type signature) {
		clause_tail(clause)->signature = signature;
	}
	
	activity_type clause_activity(clause_type clause) {
		return clause_tail(clause)->activity;
	}
	void clause_set_activity(clause_type clause, activity_type activity) {
		clause_tail(clause)->activity = activity;
	}
	unsigned int clause_get_lbd(clause_type clause) {
		return clause_tail(clause)->lbd;
	}
	void clause_set_lbd(clause_type clause, unsigned int lbd) {
		if(lbd > UINT16_MAX)
			lbd = UINT16_MAX;
		clause_tail(clause)->lbd = lbd;
	}

	bool clause_sat(clause_type clause) {
		for(auto i = clause_begin(clause); i != clause_end(clause); ++i)
			if(lit_true(*i))
				return true;
		return false;
	}

	/* ----------- management of queued clauses ---------- */
	void install_queue_push(clause_type clause) {
		SYS_ASSERT(SYS_ASRT_GENERAL, !install_queue_contains(clause));
		clause_head(clause)->flags |= clause_head_type::QUEUED_FOR_INSTALL;
		install_queue.push_back(clause);
	}
	bool install_queue_contains(clause_type clause) {
		return (clause_head(clause)->flags
				& clause_head_type::QUEUED_FOR_INSTALL) != 0;
	}
	void install_queue_process() {
		for(auto i = install_queue.begin(); i != install_queue.end(); ++i) {
			clause_head(*i)->flags &= ~clause_head_type::QUEUED_FOR_INSTALL;
			clause_install(*i);
		}
		install_queue.clear();
	}
	unsigned int install_queue_length() {
		return install_queue.size();
	}

	void fact_queue_push(literal_type literal) {
		fact_queue.push_back(literal);
	}
	void fact_queue_process2() {
		for(auto i = fact_queue.begin(); i != fact_queue.end(); ++i) {
			if(lit_true(*i))
				continue;
			if(lit_false(*i)) {
				on_conflict(conflict_type::make_fact(*i));
				return;
			}
			push_assign(*i, antecedent_type::make_decision());
			watch_compact_fast();
			propagate();
			if(at_conflict()) {
				SYS_ASSERT(SYS_ASRT_GENERAL, is_unsatisfiable());
				return;
			}
		}
		fact_queue.clear();
	}
	void fact_queue_process() {
		fact_queue_process2();
		if(is_unsatisfiable())
			SYS_CRITICAL("Fact queue conflict\n");
	}
	unsigned int fact_queue_length() {
		return fact_queue.size();
	}
	
	/* --------------- heap related functions ---------- */
	variable_type heap_get(uint32_t index) {
		return heap_array[index];
	}
	void heap_put(uint32_t index, variable_type variable) {
		heap_array[index] = variable;
	}

	/* --------------- propagation related functions ---------- */
	declevel_type cur_declevel() {
		return p_prop_config.decision_level();
	}
	order_type cur_order() {
		return p_prop_config.current_order();
	}
	literal_type order_get(order_type order) {
		return p_prop_config.get_assign(order);
	}

/*FIXME: position in file ---------------------------------- */
	void on_conflict(conflict_type conflict) {
//		std::cout << "Conflict! Variable: " << variable << std::endl;
		SYS_ASSERT(SYS_ASRT_GENERAL, !at_conflict());
		if(cur_declevel() == 1)
			unsatisfiable = true;
		conflict_desc = conflict;
	}

	void var_act_scale(activity_type divisor) {
		for(variable_type var = 0; var < p_var_config.count(); var++)
			p_var_config.get_heap_info(var).activity /= divisor;
		var_act_inc /= divisor;
	}
	void clause_act_scale(activity_type divisor) {
		for(auto i = clauses_begin(); i != clauses_end(); ++i)
			clause_scale_activity(*i, divisor);
		clause_act_inc /= divisor;
	}
	
	/* --------------- lbd calculation -------------------- */
	std::vector<bool> lbd_buffer;
	int lbd_counter;
	void lbd_init() {
		if(lbd_buffer.size() < cur_declevel() + 1)
			lbd_buffer.resize(cur_declevel() + 1, false);
		lbd_counter = 0;
	}

	void lbd_insert(declevel_type declevel) {
		if(lbd_buffer[declevel])
			return;
		lbd_buffer[declevel] = true;
		lbd_counter++;
	}
	void lbd_cleanup(declevel_type declevel) {
		lbd_buffer[declevel] = false;
	}
	int lbd_result() {
		return lbd_counter;
	}
	
	void on_var_activity(variable_type var) {
		var_heap_hooks_type heap_hooks(*this);
		
		double activity = p_var_config.get_heap_info(var).activity;
		p_var_config.get_heap_info(var).activity += var_act_inc;
		
		if(p_var_config.get_heap_info(var).heap_index
				!= var_heap_hooks_type::ILLEGAL_INDEX)
			util::heaps::binary::became_less(heap_hooks, var);
		
		/* re-scale the activity of all variables if necessary */
		if(activity > 1.0E50)
			var_act_scale(activity);
	}
	void on_antecedent_activity(antecedent_type antecedent) {
		if(antecedent.type == antecedent_type::TYPE_CLAUSE) {
			clause_type clause = antecedent.identifier.clause_ident; 
			double activity = clause_get_activity(clause);
			clause_inc_activity(clause, clause_act_inc);
			
			/* re-scale the activity of all clauses if necessary */
			if(activity > 1.0E50)
				clause_act_scale(activity);
		}
	}

	/* --------------- decision and propagation ------------------ */
	void init_watchlist(clause_type clause) {
//		std::cout << "Init clause " << clause << std::endl;

		literal_type l1 = clause_get_first(clause);
		literal_type l2 = clause_get_second(clause);
		watch_insert(lit_inverse(l1), l2, clause);
		watch_insert(lit_inverse(l2), l1, clause);
		clause_head(clause)->set_installed(true);
	}
	void init_watchlists() {
		for(clause_iterator it = clauses_begin(); it != clauses_end(); ++it)
			init_watchlist(*it);
	}
	void init_variables() {
		activity_type max_act = 1.0f;
		
		var_heap_hooks_type heap_hooks(*this);
		for(variable_type var = 0; var < p_var_config.count(); var++) {
			activity_type zero_activity = 1.0f * p_var_config.watch_size(zero_literal(var))
					+ 1.5f * p_var_config.bt_watch_size(zero_literal(var));
			activity_type one_activity = 1.0f * p_var_config.watch_size(one_literal(var))
					+ 1.5f * p_var_config.bt_watch_size(one_literal(var));
			activity_type activity = 1024 * zero_activity * one_activity
					+ zero_activity + one_activity;
			if(activity > max_act)
				max_act = activity;
			p_var_config.get_heap_info(var).activity = activity;
			
			p_var_config.get_heap_info(var).heap_index
					= var_heap_hooks_type::ILLEGAL_INDEX;
			util::heaps::binary::insert(heap_hooks, var);
		}
		for(variable_type var = 0; var < p_var_config.count(); var++)
			p_var_config.get_heap_info(var).activity /= max_act;
	}

	void initialize() {
		unsigned int num_clauses = p_clause_config.num_clauses();
		unsigned int num_vars = p_var_config.count();
		unsigned int num_literals = 2 * num_vars;
		
		/* allocate memory for the vsids heap */
		heap_array = new variable_type[num_literals];
		
		/* initialize the clause learning configuration */	
		problem::sat::first_uip::initialize(p_learn_config,
				*this, num_literals);

		state.clause_red.geom_inc_counter = 0;
		state.clause_red.geom_inc_limit = 100;
		state.clause_red.geom_size_limit = num_clauses / 3;
		opts.clause_red.geom_inc_factor = 1.5f;
		opts.clause_red.geom_size_factor = 1.1f;

		state.clause_red.agile_counter = 0;
		state.clause_red.agile_interval = opts.clause_red.agile_initial;

		state.restart.glucose_short_buffer = new declevel_type[opts.restart.glucose_short_interval];
		for(unsigned int i = 0; i < opts.restart.glucose_short_interval; ++i)
			state.restart.glucose_short_buffer[i] = 0;
		state.restart.glucose_short_pointer = 0;
		state.restart.glucose_counter = 0;
		state.restart.glucose_short_sum = 0;
		state.restart.glucose_long_sum = 0;

		state.inproc.new_facts = 0;
		state.inproc.new_binary = 0;

		init_variables();
		init_watchlists();
	}

	void decide() {
		/* determine the variable with minimal vsids score */
		var_heap_hooks_type heap_hooks(*this);
		variable_type var = util::heaps::binary::remove_minimum(heap_hooks);
		while(var_assigned(var))
			var = util::heaps::binary::remove_minimum(heap_hooks);
		
		/* create a new decision level; assign the variable */
		push_declevel();
		bool saved_one = p_var_config.get_varflag_saved(var);
		push_assign(saved_one ? one_literal(var) : zero_literal(var),
				antecedent_type::make_decision());
	}

	void push_declevel() {
		p_prop_config.new_decision();
	}
	
	void pop_declevel() {
		/*FIXME*/
	}

	void push_assign(literal_type literal, antecedent_type antecedent) {
		/* variables are never pushed twice! */
		variable_type var = lit_getvar(literal);
		SYS_ASSERT(SYS_ASRT_GENERAL, !var_assigned(var));
		
		/* push the literal on the propagation stack */
		p_prop_config.push_assign(literal);

		/* setup the antecedent and decision level of the variable */
		bool is_one = literal == one_literal(var);
		p_var_config.get_assign(var).assign(is_one);
		p_var_config.set_declevel(var, cur_declevel());
		p_var_config.set_antecedent(var, antecedent);
		assigned_count++;
		if(is_one) {
			p_var_config.set_varflag_saved(var);
		}else p_var_config.clear_varflag_saved(var);
		

//		std::cout << "[PUSH] Literal " << literal << " at order " << cur_order() 
//			<< " and decision " << cur_declevel() << std::endl;
	}
	literal_type peek_assign() {
		return p_prop_config.peek_assign();
	}

	void pop_assign() {
		/* pop a literal from the propagation stack */
		literal_type literal = p_prop_config.pop_assign();

		/* reset the variable's state to unassigned */
		variable_type var = lit_getvar(literal);
		p_var_config.get_assign(var).unassign();
		assigned_count--;

		/* re-insert the variable into the heap */
		var_heap_hooks_type heap_hooks(*this);
		if(p_var_config.get_heap_info(var).heap_index
				== var_heap_hooks_type::ILLEGAL_INDEX)
			util::heaps::binary::insert(heap_hooks, var);
		
//		std::cout << "[POP] Literal " << literal << std::endl;
	}

	/* makes sure enough space is available for clauses */
	void ensure_space(unsigned int free_required) {
		if(free_required < p_clause_alloc.get_free_space())
			return;
		
		unsigned int used_estimate = p_clause_alloc.get_used_space();
		unsigned int final_space = 1.5f * used_estimate + free_required;

//		std::cout << "c [GC    ] Extending clause space to " << (final_space / 1024) << " kb" << std::endl;

		void *old_pointer = p_clause_alloc.get_memory();
		void *new_pointer = operator new(final_space);
		if(new_pointer == NULL)
			SYS_CRITICAL("Out of memory\n");
		p_clause_alloc.move_to(new_pointer, final_space);
		operator delete(old_pointer);

		stat.general.clause_reallocs++;
	}

	/* checks whether a garbage collection is necessary */
	void check_garbage() {
		if(p_clause_config.deleted_clauses
				> 0.5f * p_clause_config.present_clauses)
			collect_clauses();
		
		unsigned int count_estimate = p_clause_config.num_clauses();
		unsigned int used_estimate = p_clause_config.get_clauses_bytes();
		unsigned int space_estimate =  used_estimate + clause_alignment * count_estimate;
		
		if(p_clause_alloc.get_used_space() > 2 * space_estimate)
			collect_clauses();
		
		if(watch_removed_queue.size() > 0)
			watch_compact_fast();
		if(have_occlists && occur_removed_queue.size() > 0)
			occur_compact_fast();
	}

	void propagate() {
		mini_propagate();
	}
	void contra_propagate() {
		SYS_ASSERT(SYS_ASRT_GENERAL, watch_removed_queue.size() == 0);
		if(at_conflict())
			return;
		while(true) {
			if(!p_prop_config.props_left()) {
				if(contra_queue.empty())
					return;
				contra_entry entry = contra_queue.top();
				contra_queue.pop();

				if(lit_true(entry.literal))
					continue;
				if(lit_false(entry.literal)) {
					on_conflict(conflict_type::from_antecedent(*this,
							entry.literal, entry.antecedent));
					while(!contra_queue.empty())
						contra_queue.pop();
					return;
				}
				push_assign(entry.literal, entry.antecedent);
			}
			literal_type literal = p_prop_config.next_prop();
			stat_propagations++;
			
			/* visit the binary/ternary watch list of the literal */
			propagate_callback_struct<config_type> callback;
			if(propagate_big(*this, callback, literal)) {
				while(!contra_queue.empty())
					contra_queue.pop();
				return;
			}
			/* visit the other (non-binary/ternary clauses) */
			if(contra_propagate_watch(*this, callback, literal)) {
				while(!contra_queue.empty())
					contra_queue.pop();
				return;
			}
		}
	}
	void mini_propagate() {
		SYS_ASSERT(SYS_ASRT_GENERAL, watch_removed_queue.size() == 0);
		if(at_conflict())
			return;
		while(p_prop_config.props_left()) {
			literal_type literal = p_prop_config.next_prop();
			stat_propagations++;
			
			/* visit the binary/ternary watch list of the literal */
			propagate_callback_struct<config_type> callback;
			if(propagate_big(*this, callback, literal))
				return;
			/* visit the other (non-binary/ternary clauses) */
			if(propagate_watch(*this, callback, literal))
				return;
		}
	}
	
	/* undos all decisions up to (but not including!) the specified level */
	void backjump(declevel_type to_declevel) {
//		std::cout << "Backjump to level " << to_declevel << std::endl;
//		std::cout << "   Current level was: " << cur_declevel() << std::endl;
		while(to_declevel < cur_declevel()) {
			typename prop_config_type::decision_info decision
					= p_prop_config.peek_decision();
			p_prop_config.props_reset();
			while(p_prop_config.assign_index() > decision.first_index)
				pop_assign();
			p_prop_config.pop_decision();
		}
	}	

	/* ----------------- conflict related functions ----------------- */
	bool at_leaf() {
		return assigned_count == p_var_config.count();
	}
	
	/* returns true while we are at a conflict */
	bool at_conflict() {
		return !conflict_desc.is_none();
	}

	/* returns true if the conflict is resolveable */
	bool is_resolveable() {
		return !unsatisfiable;
	}
	bool is_unsatisfiable() {
		return unsatisfiable;
	}


	/* resolves the conflict */
	void resolve() {
		SYS_ASSERT(SYS_ASRT_GENERAL, is_resolveable());

		state.conflict.last_declevel = cur_declevel();

		/* determine the first uip clause */
		problem::sat::first_uip::cut(p_learn_config, *this,
				conflict_iterator::begin(*this, conflict_desc),
				conflict_iterator::end(*this, conflict_desc));
		problem::sat::first_uip::minimize(p_learn_config, *this);
		problem::sat::first_uip::build(p_learn_config, *this);
		
		/* backjump and reset the conflict state */
		SYS_ASSERT(SYS_ASRT_GENERAL, p_learn_config.min_size() > 0);
		if(p_learn_config.min_size() > 1) {
			literal_type watch_lit = p_learn_config.min_get(1);
			variable_type watch_var = lit_getvar(watch_lit);
			backjump(var_declevel(watch_var));
		}else backjump(1);
		conflict_desc = conflict_type::make_none();

		lits_in_learned += p_learn_config.min_size();
		stat_learned_lits += p_learn_config.cut_size();
		stat_minimized_lits += p_learn_config.min_size();

		literal_type uip_literal = p_learn_config.min_get(0);
		variable_type uip_var = lit_getvar(uip_literal);
		if(var_declevel(uip_var) == 1) {
			on_conflict(conflict_type::make_fact(uip_literal));
			return;
		}

		/* add the learned clause to the clause database */
		if(p_learn_config.min_size() > 2) {
			/* generate a clause for the conflict */
			clause_type learned = clause_alloc(p_learn_config.min_size(),
					p_learn_config.begin_min(), p_learn_config.end_min());
			clause_install(learned);
			push_assign(uip_literal, antecedent_type::make_clause(learned));
			
			/* calculate the literal-block-distance */
			unsigned int lbd = problem::sat::lbd::of_clause
					<config_type, 15>(*this, learned);
			clause_set_lbd(learned, lbd);
			clause_set_activity(learned, clause_act_inc);
	
			/* bump variables asserted by glue clauses as in glucose */
			if(opts.learn.bump_glue_twice)
				for(auto i = p_learn_config.begin_curlevel();
						i != p_learn_config.end_curlevel(); ++i) {
					antecedent_type antecedent = var_antecedent(*i);
					if(antecedent.is_binary() && lbd > 2) {
						/* cannot check if the clause is learned.
							do not bump for now! */
						//on_var_activity(*i);
					}else if(antecedent.is_clause()) {
						clause_type reason = antecedent.identifier.clause_ident;
						if(!clause_head(reason)->get_essential()
								&& clause_get_lbd(reason) < lbd)
							on_var_activity(*i);
					}
				}
		}else if(p_learn_config.min_size() == 2) {
			literal_type reason_inverse = p_learn_config.min_get(1);
			binary_create(uip_literal, reason_inverse);
			
			literal_type reason_literal = lit_inverse(reason_inverse);
			push_assign(uip_literal,
					antecedent_type::make_binary(reason_literal));
			learned_binary++;
			state.inproc.new_binary++;
		}else{
			push_assign(uip_literal, antecedent_type::make_decision());
			learned_units++;
			state.inproc.new_facts++;
		}
		learned_clauses++;

		/* reset the learning configuration */
		problem::sat::first_uip::reset(p_learn_config, *this);
	}
	
	void after_conflict() {
		/* do some post-conflict work */
		conflict_num++;
		var_act_inc *= var_act_factor;
		clause_act_inc *= clause_act_factor;
	
		if(opts.clause_red.model == clause_red_model_agile) {
			state.clause_red.agile_counter++;
			if(state.clause_red.agile_counter
					>= state.clause_red.agile_interval) {
				delete_clauses();

				state.clause_red.agile_counter = 0;
				state.clause_red.agile_interval
						+= opts.clause_red.agile_increment;
			}
		}else if(opts.clause_red.model == clause_red_model_geometric) {
			if(learned_clauses >= state.clause_red.geom_size_limit)
				delete_clauses();

			state.clause_red.geom_inc_counter++;
			if(state.clause_red.geom_inc_counter
					>= state.clause_red.geom_inc_limit) {
				state.clause_red.geom_size_limit
						*= opts.clause_red.geom_size_factor;
				state.clause_red.geom_inc_limit
						*= opts.clause_red.geom_inc_factor;
				state.clause_red.geom_inc_counter = 0;
			}
		}else SYS_CRITICAL("Illegal clause reduction model\n");

		if(opts.restart.strategy == restart_strategy::luby) {
			restart_counter++;
			if(restart_counter >= restart_period) {
				backjump(1);
				restart_num++;
				restart_period = restart_scale * luby_period(restart_num);
				restart_counter = 0;
			}
		}else if(opts.restart.strategy == restart_strategy::glucose) {
			unsigned int glucose_ptr = state.restart.glucose_short_pointer;
			/* update the short average */
			declevel_type last_declevel = state.conflict.last_declevel;
			if(state.restart.glucose_counter >= 100)
				state.restart.glucose_short_sum
						-= state.restart.glucose_short_buffer[glucose_ptr];
			state.restart.glucose_short_buffer[glucose_ptr] = last_declevel;
			state.restart.glucose_short_sum += last_declevel;
			/* update the long average */
			state.restart.glucose_long_sum += last_declevel;
			state.restart.glucose_short_pointer++;
			state.restart.glucose_short_pointer %= opts.restart.glucose_short_interval;
		
			float short_avg = (float)state.restart.glucose_short_sum
					/ opts.restart.glucose_short_interval;
			float long_avg = (float)state.restart.glucose_long_sum / conflict_num;

			state.restart.glucose_counter++;
			if(state.restart.glucose_counter > 100 && 0.7f * short_avg > long_avg) {
				backjump(1);
				restart_num++;
				state.restart.glucose_counter = 0;
				state.restart.glucose_short_sum = 0;
			}
		}else SYS_CRITICAL("Illegal restart strategy\n");
		
		check_garbage();
	}

	bool clause_locked(clause_type clause) {
		literal_type unit_lit = clause_get_first(clause);
		variable_type unit_var = lit_getvar(unit_lit);
		auto antecedent = antecedent_type::make_clause(clause);
		if(var_assigned(unit_var)
				&& antecedent == var_antecedent(unit_var))
			return true;
		return false;
	}

	void delete_clauses() {
		SYS_ASSERT(SYS_ASRT_GENERAL, !at_conflict());
		
		/* go through the clauses; mark those that should be deleted */
		unsigned int good_clauses = 0;
		std::vector<clause_type> work_clauses;
		for(clause_iterator it = p_clause_config.begin();
				it != p_clause_config.end(); ++it) {
			clause_head_type *head = clause_head(*it);
			
			/* never delete essential clauses */
			if(head->get_essential() || !clause_present(*it))
				continue;
			/* do not delete classes that are currently unit */
			if(clause_locked(*it))
				continue;
			/* note we want to remove clauses with length 2 we have
				to clean the binary implication graph */
			if(clause_length(*it) == 2)
				continue;
		
			if(opts.clause_red.model == clause_red_model_agile
					&& (clause_get_lbd(*it) <= 3 || head->get_improved())) {
				head->clear_improved();
				good_clauses++;
				continue;
			}
			
			work_clauses.push_back(*it);
		}
		
		if(opts.clause_red.model == clause_red_model_agile) {
			clause_glue_lt_struct<config_type> compare(*this);
			std::sort(work_clauses.begin(), work_clauses.end(), compare);
		}else{
			work_clause_lt_struct<config_type> compare(*this);
			std::sort(work_clauses.begin(), work_clauses.end(), compare);
		}
		
		/* glucose-like increment of the deletion interval if
			there are many good clauses */
		unsigned int count = work_clauses.size();
		if(opts.clause_red.model == clause_red_model_agile) {
			if(count + good_clauses < good_clauses * 2)
				state.clause_red.agile_interval += 1000;
		}

		/* delete half of the learned clauses */
		unsigned int deleted = 0;
		for(unsigned int i = count / 2; i < count; i++) {
			delete_clause_ext(work_clauses[i]);
			deleted++;
			SYS_ASSERT(SYS_ASRT_GENERAL, learned_clauses > 0);
			learned_clauses--;
		}
//		std::cout << "Delete LBD: " << clause_get_lbd(work_clauses[count/2]) << std::endl;
//		std::cout << "Pre-Prun: " << count << std::endl;
		p_clause_config.prun_deleted(p_clause_alloc);
//		std::cout << "Post-Prun: " << count - deleted << std::endl;
	}
	void delete_clause_ext(clause_type clause) {
		SYS_ASSERT(SYS_ASRT_GENERAL, !clause_locked(clause));
		SYS_ASSERT(SYS_ASRT_GENERAL, !clause_head(clause)->get_delete());
		p_clause_config.set_delete(p_clause_alloc, clause);
		on_clause_delete(clause);
		del_clause_number++;
	}

	void collect_clauses() {
		watch_compact_fast();
		if(have_occlists)
			occur_compact_fast();
		
		/* allocate new space for the clauses */
		unsigned int count_estimate = p_clause_config.present_clauses;
		unsigned int used_estimate = p_clause_config.get_clauses_bytes();
		unsigned int space_estimate =  used_estimate + clause_alignment * count_estimate;
		unsigned int final_space = 1.5f * space_estimate + 4 * 1024 * 1024;
		
//		std::cout << "c [GC    ] Shrinking clause space to " << (final_space / 1024) << " kb" << std::endl;
		
//		std::cout << "Garbage collection\n";
//		std::cout << "   #clauses: " << p_clause_config.num_clauses() << "\n";
//		std::cout << "   size of clauses: " << (p_clause_config.get_clauses_bytes() / 1024) << "\n";
//		std::cout << "   current total memory: " << (p_clause_alloc.get_total_space() / 1024);
//		std::cout << ", used memory: " << ((p_clause_alloc.get_total_space()
//				- p_clause_alloc.get_free_space()) / 1024);
//		std::cout << ", free memory: " << (p_clause_alloc.get_free_space() / 1024) << "\n";
//		std::cout << "   used estimate: " << (space_estimate / 1024) << std::endl;
		
		clause_config_type new_config;
		clause_alloc_type new_alloc(clause_alignment);
		void *memory = operator new(final_space);
		new_alloc.init_memory(memory, final_space);
		
		/* copy them to the new space */
		del_clause_callback_type callback(*this);
		problem::sat::packed_clause::relocate(p_clause_config,
				p_clause_alloc, new_config, new_alloc, callback);
	
//		std::cout << "   new total memory: " << (new_alloc.get_total_space() / 1024);
//		std::cout << ", used memory: " << ((new_alloc.get_total_space()
//				- new_alloc.get_free_space()) / 1024);
//		std::cout << ", free memory: " << (new_alloc.get_free_space() / 1024) << " kb" << std::endl;
		SYS_ASSERT(SYS_ASRT_GENERAL, new_alloc.get_total_space()
				- new_alloc.get_free_space() < space_estimate);

		/* free the memory used by the old configuration */
		operator delete(p_clause_alloc.get_memory());
		p_clause_config = new_config;
		p_clause_alloc = new_alloc;

		/* rebuild occurrence lists*/
		for(variable_type var = 0; var < p_var_config.count(); ++var) {
			p_var_config.occur_clear(one_literal(var));
			p_var_config.occur_clear(zero_literal(var));
		}
		for(auto i = clauses_begin(); i != clauses_end(); ++i) {
			auto lit1 = clause_get_first(*i);
			auto lit2 = clause_get_second(*i);
			
			if(have_occlists) {
				p_var_config.occur_insert(lit1, *i);
				p_var_config.occur_insert(lit2, *i);
			}
			
			for(auto j = clause_begin3(*i); j != clause_end(*i); ++j) {
				if(have_occlists)
					p_var_config.occur_insert(*j, *i);
			}
		}
	}

	void on_clause_move(clause_alloc_type &to_alloc,
			clause_type from_index, clause_type to_index) {
		//std::cout << "Moving " << from_index << " to " << to_index << std::endl;
		/* replace the clause in both watch lists.
			NOTE: we cannot use clause_get_first on to_index!! */
		literal_type lit1 = clause_get_first(from_index);
		literal_type lit2 = clause_get_second(from_index);
		if(clause_head(from_index)->get_installed()) {
			if(clause_length(from_index) != 2) {
				watch_replace_clause(lit_inverse(lit1), from_index, to_index);
				watch_replace_clause(lit_inverse(lit2), from_index, to_index);
			}
		}
		
		/* update the antecedent if the clause was unit */
		variable_type unit_var = lit_getvar(lit1);
		auto from_antecedent = antecedent_type::make_clause(from_index);
		auto to_antecedent = antecedent_type::make_clause(to_index);
		//if(var_assigned(unit_var))
		//	std::cout << "Antecedent: " << var_antecedent(unit_var).type
		//			<< " / " << var_antecedent(unit_var).identifier.padding << std::endl;
		if(from_antecedent == var_antecedent(unit_var))
			p_var_config.set_antecedent(unit_var, to_antecedent);
	}
	void on_clause_delete(clause_type from_index) {
//		std::cout << "Deleting " << from_index << std::endl;
		/* remove the clause from both watch lists */
		if(clause_head(from_index)->get_installed()) {
			literal_type lit1 = clause_get_first(from_index);
			literal_type lit2 = clause_get_second(from_index);
			if(clause_length(from_index) != 2) {
				watch_remove_clause(lit_inverse(lit1), from_index);
				watch_remove_clause(lit_inverse(lit2), from_index);
			}
		}
	}
	void on_clause_collect(clause_type from_index) {
		/* common operation for clause deletion and moving */
	}

	void strengthen_facts(clause_type clause) {
		/* check if the clause contains any facts */
		bool contains_facts = false;
		for(auto j = clause_begin(clause); j != clause_end(clause); ++j) {
			variable_type var = lit_getvar(*j);
			if(!var_assigned(var) || var_declevel(var) != 1)
				continue;
			
			/* check if we can delete the whole clause */
			if(lit_true(*j)) {
				stat.search.fact_elim_clauses++;
				clause_delete(clause);
				return;
			}
			contains_facts = true;
		}
		if(!contains_facts)
			return;
	
		/* strengthen the clause by removing false facts */
		std::vector<literal_type> shortened;
		for(auto j = clause_begin(clause); j != clause_end(clause); ++j) {
			variable_type var = lit_getvar(*j);
			if(var_assigned(var) && var_declevel(var) == 1) {
				stat.search.fact_elim_literals++;
				continue;
			}
			shortened.push_back(*j);
		}

		if(shortened.size() == 2) {
			binary_create(shortened.front(), shortened.back());
		}else{
			clause_type new_clause = clause_alloc(shortened.size(),
					shortened.begin(), shortened.end());
			if(clause_head(clause)->get_essential())
				clause_head(new_clause)->set_essential(true);
			install_queue_push(new_clause);
		}
		clause_delete(clause);
	}

	unsigned int fact_count() {
		return p_prop_config.assigns_at(1);
	}

	void eliminate_facts() {
		SYS_ASSERT(SYS_ASRT_GENERAL, !at_conflict());
		SYS_ASSERT(SYS_ASRT_GENERAL, cur_declevel() == 1);
		SYS_ASSERT(SYS_ASRT_GENERAL, !p_prop_config.props_left());
		if(p_prop_config.assigns_at(1) == 0)
			return;
		
		/* reset the antecedents of all facts so that they do not
			point to clauses that will be removed */
		for(variable_type var = 0; var < p_var_config.count(); ++var) {
			if(!var_assigned(var) || var_declevel(var) != 1)
				continue;
			p_var_config.set_antecedent(var, antecedent_type::make_none());
		}
		
		/* remove the facts from all clauses */
		std::vector<clause_type> queue;
		for(auto i = clauses_begin(); i != clauses_end(); ++i) {
			if(!clause_present(*i))
				continue;
			queue.push_back(*i);
		}
		for(auto i = queue.begin(); i != queue.end(); ++i)
			strengthen_facts(*i);

		/* remove all facts from the propagation queue */
		p_prop_config.props_reset();
		while(p_prop_config.assign_index() > 0) {
			literal_type assigned = peek_assign();
			literal_type inverse = lit_inverse(assigned);
		
			/* delete all binary implications containing the variable */
			for(auto i = big_begin(assigned); i != big_end(assigned); ++i) {
				auto lit = lit_inverse((*i).literal);
				SYS_ASSERT(SYS_ASRT_GENERAL, !lit_true(lit));
				big_remove(lit, inverse);
			}
			for(auto i = big_begin(inverse); i != big_end(inverse); ++i) {
				auto lit = lit_inverse((*i).literal);
				big_remove(lit, assigned);
			}
			big_clear(assigned);
			big_clear(inverse);

			/* mark the variable as deleted */
			variable_type var = lit_getvar(assigned);
			p_var_config.var_delete(var);
			
			problem::sat::extmodel::push_fact(*this, extmodel_config,
					extmodel_alloc, assigned);
			
			pop_assign();
		}
		stat.search.fact_elim_runs++;
	}

	void occlists_build() {
		SYS_ASSERT(SYS_ASRT_GENERAL, !have_occlists);
		for(auto i = clauses_begin(); i != clauses_end(); ++i) {
			for(auto j = clause_begin(*i); j != clause_end(*i); ++j)
				p_var_config.occur_insert(*j, *i);
		}
		have_occlists = true;
	}

	void occlists_clear() {
		SYS_ASSERT(SYS_ASRT_GENERAL, have_occlists);
		for(variable_type i = 0; i < p_var_config.count(); ++i) {
			p_var_config.occur_clear(zero_literal(i));
			p_var_config.occur_clear(one_literal(i));
		}
		have_occlists = false;
	}
	
	void occlists_remove(literal_type literal, clause_type clause) {
		for(occur_iterator i = p_var_config.occur_begin(literal);
				i != p_var_config.occur_end(literal); ++i) {
			if(*i != clause)
				continue;
			p_var_config.occur_erase(literal, i);
			return;
		}
		SYS_CRITICAL("Clause not found\n");
	}

	unsigned int occur_size(literal_type literal) {
		return p_var_config.occur_size(literal);
	}
	occur_iterator occur_begin(literal_type literal) {
		return p_var_config.occur_begin(literal);
	}
	occur_iterator occur_end(literal_type literal) {
		return p_var_config.occur_end(literal);
	}
	void occur_compact_single(literal_type literal) {
		if(!p_var_config.get_litflag_occur_removed(literal))
			return;
		auto j = p_var_config.occur_begin(literal);
		for(auto i = p_var_config.occur_begin(literal);
				i != p_var_config.occur_end(literal); ++i) {
			if(!clause_present(*i))
				continue;
			*j = *i;
			++j;
		}
		p_var_config.occur_cutoff(literal, j);
		p_var_config.clear_litflag_occur_removed(literal);
	}
	void occur_compact_fast() {
		for(auto i = occur_removed_queue.begin();
				i != occur_removed_queue.end(); ++i)
			occur_compact_single(*i);
		occur_removed_queue.clear();
	}

	bool clause_contains(clause_type clause, literal_type literal) {
/*		unsigned int sig_size = sizeof(typename clause_head_type::signature_type) * 8;
		typename clause_head_type::signature_type litsig = (1 << (literal % sig_size));
		if((clause_head(clause)->signature & litsig) == 0)
			return false;*/

		for(auto i = clause_begin(clause); i != clause_end(clause); ++i)
			if(*i == literal)
				return true;
		return false;
	}
	int lit_polarity(literal_type literal) {
		variable_type var = lit_getvar(literal);
		return literal == one_literal(var) ? 1 : -1;
	}
	int clause_polarity(clause_type clause, variable_type variable) {
		for(auto i = clause_begin(clause); i != clause_end(clause); ++i) {
			variable_type var = lit_getvar(*i);
			if(var != variable)
				continue;
			return lit_polarity(*i);
		}
		return 0;
	}
	
	/* returns true if the resolvent of the given clauses with respect to
			the given variable is a tautology */
	bool resolvent_trivial(clause_type clause1, clause_type clause2,
			variable_type variable) {
		for(auto i = clause_begin(clause1); i != clause_end(clause1); ++i) {
			auto var = lit_getvar(*i);
			if(var == variable)
				continue;
			int polarity1 = lit_polarity(*i);
			int polarity2 = clause_polarity(clause2, var);
			if(polarity1 == -polarity2)
				return true;
		}
		return false;
	}
	/* returns true if the resolvent is trivial */
	bool resolvent_length(clause_type clause1, clause_type clause2,
			variable_type variable, unsigned int &length) {
		length = clause_length(clause1) + clause_length(clause2) - 2;
		for(auto i = clause_begin(clause1); i != clause_end(clause1); ++i) {
			auto var = lit_getvar(*i);
			if(var == variable)
				continue;
			int polarity1 = lit_polarity(*i);
			int polarity2 = clause_polarity(clause2, var);
			if(polarity1 == -polarity2)
				return true;
			if(polarity1 == polarity2)
				length--;
		}
		return false;
	}

	/* builds the resolvent of the two given clauses */
	std::vector<literal_type> resolvent_build(clause_type clause1,
			clause_type clause2, variable_type variable) {
		std::vector<literal_type> result;
		for(auto i = clause_begin(clause1); i != clause_end(clause1); ++i) {
			if(lit_getvar(*i) == variable)
				continue;
			result.push_back(*i);
		}
		for(auto i = clause_begin(clause2); i != clause_end(clause2); ++i) {
			if(lit_getvar(*i) == variable)
				continue;
			if(clause_contains(clause1, *i))
				continue;
			result.push_back(*i);
		}
		return result;
	}

	struct contra_entry {
		literal_type literal;
		antecedent_type antecedent;
		unsigned int glue;
		
		bool operator< (const contra_entry &other) const {
			return glue < other.glue;
		}
	};
	std::priority_queue<contra_entry> contra_queue;

	/* luby sequence:
		t(i) = 2^(k-1)					if i = 2^k - 1
		t(i) = t(i - 2^(k-1) + 1)		if 2^(k-1) <= i < 2^k - 1
	*/
	unsigned int luby_period(unsigned int i) {
		while(i != 0) {
			/* calculate k maximal so that i <= 2^k - 1 */
			unsigned int rem = i;
			unsigned int k = 0;
			unsigned int kpow = 1; /* k-th power of 2 */
			while(rem != 0) {
				k++;
				rem /= 2;
				kpow *= 2;
			}
			
			/* first case: t(i) = 2^(k-1) */
			if(i == kpow - 1)
				return kpow / 2;
			/* second case: t(i) = t(i - 2^(k-1) + 1) */ 
			i = i - kpow / 2 + 1;
		}
		return 1;
	}
	
	void cfg_seed(unsigned long seed) {
		std::cout << "c random seed: 0x" << std::hex << seed << std::dec << std::endl;
		rnd_engine.seed(seed);
	}

public:
	clause_alloc_type p_clause_alloc;
	clause_config_type p_clause_config;
	
	var_config_type p_var_config;

	prop_config_type p_prop_config;

	learn_config_type p_learn_config;

	extmodel_config_type extmodel_config;
	extmodel_alloc_type extmodel_alloc;

	std::vector<clause_type> install_queue;
	std::vector<literal_type> fact_queue;

	std::vector<literal_type> watch_removed_queue;
	std::vector<literal_type> occur_removed_queue;
	
	/* random number generator for various tasks */
	std::mt19937 rnd_engine;
	
	/* number of variables currently assigned */
	variable_type assigned_count;

	/* increment that is added to the score on each activity */
	activity_type var_act_inc;
	/* the increment is multiplies by this factor each conflict */
	activity_type var_act_factor;

	/* see the corresponding var_act variables */
	activity_type clause_act_inc;
	activity_type clause_act_factor;

	conflict_type conflict_desc;
	bool unsatisfiable;

	bool have_occlists;

	/* number of conflicts resolved so far */
	uint64_t conflict_num;
	/* number of unit literals that were learned */
	uint32_t learned_units;
	uint32_t learned_binary;

	uint64_t lits_in_learned;

	uint32_t learned_clauses;

	/* number of conflicts until next clause deletion */
	uint64_t del_clause_limit;
	/* number of deleted clauses so far */
	uint64_t del_clause_number;
	
	/* size of the memory reserved for clauses */
	uint32_t clause_memsize;

	uint64_t stat_propagations;
	uint64_t stat_learned_lits;
	uint64_t stat_minimized_lits;
	uint64_t stat_blocked_clauses;
	uint64_t stat_vecd_elim;

	enum preproc_model_type {
		/* do not perform preprocessing at all */
		preproc_model_none,
		/* perform the preprocessing operations iteratively
			in a pre-defined order */
		preproc_model_iterative,
		preproc_model_adaptive
	};
	
	enum clause_red_model_type {
		clause_red_model_agile,
		clause_red_model_geometric
	};
	
	enum restart_strategy {
		luby,
		glucose
	};

	struct {
		struct {
			uint32_t clause_reallocs;
		} general;

		struct {
			uint32_t fact_elim_runs;
			uint64_t fact_elim_clauses;
			uint64_t fact_elim_literals;
			
			util::performance::counter prop_time;
		} search;

		struct {
			uint64_t vecd_facts;
			uint64_t scc_variables;
			uint64_t fle2_literals;
			uint64_t brm_failed;
			uint64_t brm_equivalent;
			uint64_t brm_independent;
			uint64_t hle_literals;
			uint64_t hle_facts;
			uint64_t hte_clauses;
			uint64_t selfsub_facts;
			uint64_t selfsub_clauses;
			uint64_t subsumed_clauses;
			uint64_t dist_checks;
			uint64_t dist_conflicts;
			uint64_t dist_conflicts_removed;
			uint64_t dist_asserts;
			uint64_t dist_asserts_removed;
			uint64_t unhide_transitive;
			uint64_t unhide_failed;
			uint64_t unhide_hle;
			uint64_t unhide_hte;

			util::performance::counter scc_time;
			util::performance::counter fle2_time;
			util::performance::counter hle_time;
			util::performance::counter selfsub_time;
			util::performance::counter vecd_time;
			util::performance::counter bce_time;
		} simp;
	} stat;

	struct {
		util::performance::counter inproc_time;
		util::performance::counter fact_elim_time;
	} perf;

	struct {
		struct {
			int verbose;

			util::performance::counter budget;
			util::performance::counter timeout;
			
			bool permutate_input;
		} general;

		struct {
			preproc_model_type model;
			bool with_scc;
			bool with_fle2;
			bool with_hle;
			bool with_selfsub;
			bool with_vecd;
			bool with_bce;
			bool with_dist;
			bool with_unhiding;
			uint32_t iterations;
		} preproc;

		struct {
			unsigned int dist_min_length;
		} simp;

		struct {
			bool bump_glue_twice;
			bool minimize_glucose;
		} learn;

		struct {
			clause_red_model_type model;

			/* initial learned clauses limit */
			uint32_t agile_initial;
			/* increment of the clauses limit */
			uint32_t agile_increment;
			
			/* growth factor for geom_size_limit */
			double geom_size_factor;
			/* growth factor for geom_inc_limit */
			double geom_inc_factor;
		} clause_red;

		struct {
			restart_strategy strategy;
			static const unsigned int glucose_short_interval = 100;
		} restart;
	} opts;

	struct {
		struct {
			util::performance::counter start_time;
		} general;

		struct {
			/* number of conflicts before the next reduce */
			uint64_t agile_interval;
			/* number of conflicts since the last reduce */
			uint64_t agile_counter;
			
			/* current learned clauses limit */
			uint64_t geom_size_limit;
			/* number of conflicts since last increment */
			uint64_t geom_inc_counter;
			/* number of conflicts before next increment */
			uint64_t geom_inc_limit;
		} clause_red;

		struct {
			declevel_type last_declevel;
		} conflict;

		struct {
			declevel_type *glucose_short_buffer;
			unsigned int glucose_short_pointer;
			unsigned int glucose_counter;
			uint64_t glucose_short_sum;
			uint64_t glucose_long_sum;
		} restart;

		struct {
			/* number of new clauses since last in-processing phase */
			unsigned int new_facts;
			unsigned int new_binary;
		} inproc;
	} state;

	uint32_t restart_counter;
	uint32_t restart_scale;
	uint32_t restart_period;
	uint32_t restart_num;

	uint32_t heap_size;
	variable_type *heap_array;
public:
	print_clause_manipulator<config_type> print_clause(clause_type clause) {
		return print_clause_manipulator<config_type>(*this, clause);
	}
};

}}; /* namespace main::sat_core */

enum solve_state {
	SOLVE_BREAK,
	SOLVE_SOLUTION,
	SOLVE_FINISHED
};

struct search_total_stats_struct {
	util::performance::counter elapsed;

	search_total_stats_struct() : elapsed(0) { }
};

template<typename Hooks>
void search(Hooks &hooks, solve_state2 &cur_state,
		search_total_stats_struct &total_stats) {
	auto start = util::performance::current();
	for(unsigned int i = 0; true; i++) {
		hooks.propagate();

		if(hooks.at_conflict()) {
			if(hooks.is_resolveable()) {
				hooks.resolve();
				hooks.after_conflict();
			}else{
				cur_state = solve_state2::unsatisfiable;
				total_stats.elapsed += util::performance::elapsed(start);
				return;
			};
		}else{
			/* return after a certain conflict limit is reached */
			if(i > 1000 && hooks.cur_declevel() == 1) {
				cur_state = solve_state2::unknown;
				total_stats.elapsed += util::performance::elapsed(start);
				return;
			}
			
			/* if no decision can be made and we are not at a conflict
				the formula is solved */
			if(hooks.at_leaf()) {
				cur_state = solve_state2::satisfied;
				total_stats.elapsed += util::performance::elapsed(start);
				return;
			}
			hooks.decide();
		}
	}
}

template<typename Config>
void progress_message(Config &config,
		util::performance::counter current_time) {
	std::stringstream msg;
	msg << "c [SEARCH]";
	msg << std::right << std::setprecision(2) << std::fixed;
	msg << std::setw(6) << ((current_time - config.state.general.start_time) / (1000 * 1000 * 1000));
	msg << std::setw(14) << config.conflict_num;
	msg << std::setw(9) << config.restart_num;
	msg << std::setw(12) << (config.opts.clause_red.model == Config::clause_red_model_agile
			? config.state.clause_red.agile_interval
			: config.state.clause_red.geom_size_limit);
	msg << std::setw(10) << (config.clause_space() / 1024);
//			msg << std::setw(12) << ((float)config.state.restart.glucose_long_sum / config.conflict_num);
//			msg << std::setw(12) << ((float)config.state.restart.glucose_short_sum
//					/ config.opts.restart.glucose_short_interval);
	std::cout << msg.str() << std::endl;
}

template<typename Config>
solve_state solve_step(Config &config) {
	config.propagate();
	if(config.at_conflict()) /*FIXME: replace with is_unsatisfiable() */
		return solve_state::SOLVE_FINISHED;

	config.eliminate_facts();
	config.install_queue_process();
	config.check_garbage();

	uint64_t t_start, t_end;

	std::cout << "c [      ]  initial:" << std::endl;
	std::cout << "c [      ]     variables: " << config.p_var_config.present_count() << std::endl;	
	std::cout << "c [      ]     big edges: " << config.p_var_config.big_overall_size() << std::endl;	
	std::cout << "c [      ]     long clauses: " << config.p_clause_config.present_clauses << std::endl;	

	std::cout << "c building occurrence lists" << std::endl;
	t_start = sysGetCpuTime();
	config.occlists_build();
	t_end = sysGetCpuTime();
	std::cout << "c finished in " << (t_end - t_start) << " msecs" << std::endl;

	if(config.opts.preproc.model == Config::preproc_model_iterative) {
		preproc_iterative(config);
	}else if(config.opts.preproc.model == Config::preproc_model_adaptive) {
		preproc_adaptive(config);
	}
	
	std::cout << "c [      ]  before search:" << std::endl;
	std::cout << "c [      ]     variables: " << config.p_var_config.present_count() << std::endl;	
	std::cout << "c [      ]     big edges: " << config.p_var_config.big_overall_size() << std::endl;	
	std::cout << "c [      ]     long clauses: " << config.p_clause_config.present_clauses << std::endl;	

	config.occlists_clear();
	config.watch_compact_fast();
	
/*	std::stringstream header;
	header << std::right;
	header << "c [SEARCH]";
	header << std::setw(6) << "";
	header << std::setw(14) << "";
	header << std::setw(9) << "";
	header << std::setw(12) << "";
	header << std::setw(10) << "";
	header << std::setw(12) << "average";
	std::cout << header.str() << std::endl;*/
	std::stringstream header2;
	header2 << std::right;
	header2 << "c [SEARCH]";
	header2 << std::setw(6) << "secs";
	header2 << std::setw(14) << "conflicts";
	header2 << std::setw(9) << "restarts";
	header2 << std::setw(12) << "limit";
	header2 << std::setw(10) << "space(kb)";
//	header2 << std::setw(12) << "declevel";
	std::cout << header2.str() << std::endl;
	std::cout << "c -----------------------------------------------------------------------" << std::endl;

	auto last_message = util::performance::current();

	search_total_stats_struct search_total_stats;

	while(true) {
		/* check for timeout, print progress msg... */
		auto current = util::performance::current();
		if(config.opts.general.timeout != 0 && config.opts.general.timeout
				< current - config.state.general.start_time)
			return SOLVE_BREAK;
		if(current - last_message > 5LL * 1000 * 1000 * 1000) {
			progress_message(config, current);
			last_message = current;
		}

		solve_state2 cur_state = solve_state2::unknown;

		/* perform search */
		search(config, cur_state, search_total_stats);
		if(cur_state == solve_state2::satisfied) {
			return solve_state::SOLVE_SOLUTION;
		}else if(cur_state == solve_state2::unsatisfiable) {
			return solve_state::SOLVE_FINISHED;
		}
	
		/* perform inprocessing */
		SYS_ASSERT(SYS_ASRT_GENERAL, config.cur_declevel() == 1);
		if(config.perf.inproc_time < 0.1f * search_total_stats.elapsed) {
			if(config.opts.general.verbose > 1)
				std::cout << "c [INPROC] started, total inproc time: "
						<< (config.perf.inproc_time / (1000 * 1000)) << " msecs"
						<< ", search time: " << (search_total_stats.elapsed / (1000 * 1000)) << " msescs" << std::endl;
			auto start = util::performance::current();
			inproc_adaptive(config);
			auto elapsed = util::performance::elapsed(start);
			if(config.opts.general.verbose > 1)
				std::cout << "c [INPROC] finished in: "
						<< (elapsed / (1000 * 1000)) << " msecs" << std::endl;
			
			config.perf.inproc_time += elapsed;
		}
	}
}

