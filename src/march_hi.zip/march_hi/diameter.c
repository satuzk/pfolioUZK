
#include <stdio.h>
#include <stdlib.h>
#include "common.h"

int diameter_vars;
int *var_depth;

int **dia_clause_list, *dia_clause_table;
int *clause_stamps, CCS = 0;
int *dstack;


#define DIAMETER_FIX( __a ) \
{\
    if( var_depth[ __a ] == 0 ) \
    {   var_depth[ __a ] = current_depth + 1; \
	*(dstackp++) = __a; } \
}

void print_clause_table();
int  computer_diameter( const int varnr );

void init_diameter( )
{
	int i, j, nrofliterals;
	int *var_occ;
	int max_diameter = 0, nr_max = 0, count_diameter = 0;
	int min_diameter = nrofvars, nr_min = 0;
	double sum_diameter = 0.0;

	dstack  = (int*) malloc( sizeof(int) * nrofvars );

	var_depth = (int*) malloc( sizeof(int) * (nrofvars+1) );

	var_occ = (int*) malloc( sizeof(int) * (nrofvars+1) );
	for( i = 1; i <= nrofvars; i++ )
	    var_occ[i] = 0;

	nrofliterals = 0;

	for( i = 0; i < nrofclauses; i++ )
	    for( j = 0; j < Clength[ i ]; j++ )
	    {
	        nrofliterals++;
		var_occ[ abs( Cv[i][j] ) ]++;
	    }

	clause_stamps = (int*) malloc( sizeof(int) * nrofclauses );
	for( i = 0; i < nrofclauses; i++ ) clause_stamps[ i ] = 0;
	
	dia_clause_table = (int*) malloc( sizeof(int) * (nrofliterals + nrofvars) );
	for( i = 0; i < nrofliterals + nrofvars; i++ )
	    dia_clause_table[ i ] = -1;

	dia_clause_list = (int**) malloc( sizeof(int*) * (nrofvars + 1) );

	nrofliterals = 0;	
	for( i = 1; i <= nrofvars; i++ )
	{
	    dia_clause_list[ i ] = &dia_clause_table[ nrofliterals ];
	    nrofliterals += var_occ[ i ] + 1;
	    var_occ[ i ] = 0;
	}


	for( i = 0; i < nrofclauses; i++ )
	    for( j = 0; j < Clength[ i ]; j++ )
		dia_clause_list[ abs(Cv[i][j]) ][ var_occ[ abs(Cv[i][j]) ]++ ] = i;

	free( var_occ );

	for( i = 1; i <= nrofvars; i++ )
	{
	    int diameter = computer_diameter( i );

	    if( diameter > max_diameter )
	    {	max_diameter = diameter; nr_max = 1; }
	    else if( diameter == max_diameter ) nr_max++;

	    if( diameter > 0 && diameter < min_diameter )
	    {	min_diameter = diameter; nr_min = 1; }
	    else if( diameter == min_diameter ) nr_min++;

	    if( diameter > 0 )
	    {
		sum_diameter += diameter;
		count_diameter++;
	    }
	}

	printf("c diameter():: MIN: %i (#%i) MAX: %i (#%i) AVG: %.3f\n", min_diameter, nr_min, 
		max_diameter, nr_max, sum_diameter / count_diameter ); 


	free(dia_clause_table);
}

int computer_diameter( const int varnr )
{
	int i, _varnr, current_depth = 0;
	int *_dstackp = dstack;
	int * dstackp = dstack;
	int *clauses, _clause;

	if( dia_clause_list[ varnr ][ 0 ] == -1 )
	    return 0;

	for( i = 1; i < nrofvars; i++ ) var_depth[ i ] = 0;

	CCS++;
	
	DIAMETER_FIX( varnr );

	while( _dstackp < dstackp )
	{
	    _varnr = *(_dstackp++);
	    current_depth = var_depth[ _varnr ];

	    clauses = dia_clause_list[ _varnr ];
	    while( *clauses != -1 )
	    {
		_clause = *(clauses++);
		if( clause_stamps[ _clause ] == CCS ) continue;
		clause_stamps[ _clause ] = CCS;
	
		for( i = 0; i < Clength[ _clause ]; i++ )
		{   DIAMETER_FIX( abs(Cv[ _clause ][ i ]) ); }    
	    }
	}
/*
	for( i = 1; i <= current_depth; i++ )
	{
	    int j;
	    printf("\ndepth %i :: ", i);
	    for( j = 1; j <= nrofvars; j++ )
		if( var_depth[j] == i )
		    printf("%i ", j);
	}
*/	
	return current_depth;
}

void print_clause_table()
{
	int i, j;

	for( i = 1; i <= nrofvars; i++ )
	{
	    j = 0;
	    while( dia_clause_list[i][j] != -1 )
		printf("%i ", dia_clause_list[i][j++] );

	    printf("\n");
	}
}
