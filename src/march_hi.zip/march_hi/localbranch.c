/* MARCH Satisfiability Solver

   Copyright (C) 2001-2006 M. Dufour, M.J.H. Heule, J.E. van Zwieten
   [m.dufour@student.tudelft.nl, marijn@heule.nl, zwieten@ch.tudelft.nl]

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
*/

#include <malloc.h>
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

#include "common.h"
#include "localbranch.h"

#define CONTINUE        1
#define FINISHED        0

#define IS_NOT_FREESTAMPED( __a )	(IS_NOT_FIXED( __a) && (freeStamps[NR(__a)] != nodeCount) )

#define CALL_FREESTAMPED_REC( ) \
{ \
	lit = *(bImp++); \
    	if( IS_NOT_FREESTAMPED( lit ) ) \
	    if( stamp_freevars_rec(lit) == FINISHED ) \
		return FINISHED; \
}

int *freeStamps, nroffreestamped;

void init_localbranching( )
{
	int i;

	freeStamps = (int*) malloc( sizeof(int) * (nrofvars + 1) );
	for( i= 0; i <= nrofvars; i++ )
	    freeStamps[ i ] = 0;
}

/*
int autarky_stamp( const int nrval )
{
	int i, *tImp, lit1, lit2, flag = 0;

	tImp = TernaryImp[ -nrval ];
	for( i = tmpTernaryImpSize[ -nrval ]; i--; )
	{
	    lit1 = *(tImp++);
	    lit2 = *(tImp++);
		
	    if( IS_NOT_FIXED(lit1) && IS_NOT_FIXED(lit2) )
	    {
		flag = 1;
		if( VeqDepends[ NR(lit1) ] == DUMMY )
		    autarky_stamp( lit1 );
		else
		    TernaryImpReduction[ lit1 ]++;

		if( VeqDepends[ NR(lit2) ] == DUMMY )
		    autarky_stamp( lit2 );
		else
		TernaryImpReduction[ lit2 ]++;
	    }
	}
	return flag;
}

int analyze_autarky( )
{
#ifdef LOOKAHEAD_ON_DUMMIES
	int *tImp, lit1, lit2;
#endif
	int i, j, nrval, twice;
	int new_bImp_flag, _depth, *_rstackp;

	if( depth == 0 ) return 0;

        for( i = 1; i <= nrofvars; i++ )
        {
            TernaryImpReduction[  i ] = 0;
            TernaryImpReduction[ -i ] = 0;
        }

	new_bImp_flag = 0;
	_rstackp      = rstackp;
	for( _depth = depth; _depth > 0; _depth-- )
	{
//	  if( autarky_level[ _depth ] == TRUE )
//	  {
//		while( *(_rstackp--) == STACK_BLOCK );
//	 	continue;
//	  }

	  for( twice = 1 ; twice <= 2; twice++ )	    
	    while( *(--_rstackp) != STACK_BLOCK )
	    {
		nrval = *(_rstackp);
#ifndef LOOKAHEAD_ON_DUMMIES
		if( autarky_stamp( nrval ) == 1 )
		    new_bImp_flag = 1;
#else
		tImp = TernaryImp[ -nrval ];
		for( i = tmpTernaryImpSize[ -nrval ]; i--; )
		{
		    lit1 = *(tImp++);
		    lit2 = *(tImp++);
		
		    if( IS_NOT_FIXED(lit1) && IS_NOT_FIXED(lit2) )
		    {
			new_bImp_flag = 1;
			TernaryImpReduction[ lit1 ]++;
			TernaryImpReduction[ lit2 ]++;
		    }
		}
#endif
	        for( j = 1; j < tmpEqImpSize[NR(nrval)]; j++ )
	        {
	            int ceqsubst = Veq[NR(nrval)][j];
	    	    for( i = 0; Ceq[ceqsubst][i] != NR(nrval); i++ )
		    {
			new_bImp_flag = 1;
			//printf("%i (%i)", Ceq[ ceqsubst][i], _depth );
	   	        TernaryImpReduction[ Ceq[ceqsubst][i] ]++;
		    }
	        }
	    }
	  if( new_bImp_flag == 1 ) break;
	  autarky_level[ _depth ] = TRUE;
	}
	return _depth;
}
*/

int stamp_freevars_rec( const int nrval )
{
	int i, lit, *bImp;

	freeStamps[ NR(nrval) ] = nodeCount;

	nroffreestamped++;

	if( nroffreestamped == freevars )
	    return FINISHED;

	bImp = TernaryImp[ nrval ];
	for( i = 2*TernaryImpSize[ nrval ]; i--; ) 
	{   CALL_FREESTAMPED_REC( ) }

	bImp = TernaryImp[ -nrval ];
	for( i = 2*TernaryImpSize[ -nrval ]; i--; ) 
	{   CALL_FREESTAMPED_REC( ) }

        bImp = BIMP_START(nrval);
        for( i = BIMP_ELEMENTS; --i; )
	{   CALL_FREESTAMPED_REC( ) }

        bImp = BIMP_START(-nrval);
        for( i = BIMP_ELEMENTS; --i; )
	{   CALL_FREESTAMPED_REC( ) }

	return CONTINUE;
}

void determine_components( )
{
	int i, nrval, nrofcomponents, *_freevarsArray, alreadystamped, componentsize;

	nrofcomponents  = 0;
	nroffreestamped = 0;
	alreadystamped  = 0;
	componentsize	= 0;

	for( _freevarsArray = freevarsArray, i = freevars; i > 0; i-- )
	{
	    nrval = *(_freevarsArray++);

	    if( freeStamps[ nrval ] != nodeCount )
	    {
		nrofcomponents++;
		if( stamp_freevars_rec( nrval ) == FINISHED )
		    break;

		if( (nroffreestamped - alreadystamped) == 1 )
		    nrofcomponents--;
		else
		{
		    if( nrofcomponents > 1 )
	  	        printf("c %i %i ", nrofcomponents - 1, componentsize );

		    componentsize = nroffreestamped - alreadystamped;
		}
		alreadystamped = nroffreestamped;
	    }
	}

	if( (nroffreestamped - alreadystamped) == 1 )
	    nrofcomponents--;
	else if( nrofcomponents > 1 )
	    printf("c %i %i ", nrofcomponents - 1, componentsize );

	if( nrofcomponents != 1 )
	{
	    componentsize = nroffreestamped - alreadystamped;
	    printf("c %i %i ", nrofcomponents, componentsize );
	    printf("components at depth %i (%i)\n", depth, freevars );
	}
}
