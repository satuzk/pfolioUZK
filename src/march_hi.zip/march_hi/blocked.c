#include <stdio.h>
#include <malloc.h>
#include <assert.h>

#include "blocked.h"
#include "common.h"
#include "doublelook.h"
#include "memory.h"
#include "parser.h"
#include "tree.h"

#define	OCCURENCE_GRAPH		1
#define CONFLICT_GRAPH		2
#define	RESOLUTION_GRAPH	3
#define SUBSUMPTION_GRAPH	4

#define INITIAL_ORDER		nrofclauses
#define INITIAL_LOW		nrofclauses
#define INITIAL_PARENT		-1

#define PRINT_COMPONENTS
//#define REMOVE_BLOCKED_BINARIES

#define PRINT_EDGES

int *candidates, nrofcandidates;
int *MarkArray;
int **literal_occ, **literal_lut;
int binary_blocked = 0, nary_blocked = 0; 
int removed_blocked_clauses = 0;	
int *clause_order_stamp, *clause_order_array, *clause_parent, *clause_low;
int current_order;

int *graph_subsume, graph_subsume_stamp = 0;

void allocate_local_datastructures( );
void free_local_datastructures( );
int depth_first_graph_rec( const int clsidx, const int parent, const int graph_flag );
void determine_clause_low( const int clsidx, const int graph_flag );

int seive_blocked_binaries( )
{
	int i, j, k, lit1, lit2, imp, *bImp, *tImp, _freevar, *_freevarsArray;
	int blocked;
        struct treeNode _treeNode, *_treeArray;

	reset_doublelook_pointers();

	currentTimeStamp = 0;

	for( _freevarsArray = freevarsArray, i = freevars; i > 0; i-- )
	{
	    _freevar = *(_freevarsArray++);
	    UNFIX( _freevar );
	}	

	if( treebased_lookahead() == UNSAT ) return UNSAT;

	_treeArray = treeArray;
        for( i = tree_elements-1; i >= 0; i-- )
        {
	    _treeNode = *(_treeArray++);

            currentTimeStamp += _treeNode.gap;

            if( DL_treelook( _treeNode.literal ) == UNSAT )    return UNSAT;

            bImp = BIMP_START( _treeNode.literal );
            for( j = BIMP_ELEMENTS; --j; )
	    {
		imp = *(bImp++);
		blocked = 1;

		printf("checking blocked %i v %i\n", -_treeNode.literal, imp );

        	tImp = TernaryImp[ -imp ];
		for( k = TernaryImpSize[ -imp ]; k > 0; k-- )
        	{
		    lit1 = *(tImp++);
		    printf("lit %i %i %i\n", lit1, IS_FIXED(lit1), FIXED_ON_COMPLEMENT(lit1) );
		    lit2 = *(tImp++);
		    printf("lit %i %i %i\n", lit2, IS_FIXED(lit2), FIXED_ON_COMPLEMENT(lit2) );

		    printf("imp %i v %i v %i\n", -imp, lit1, lit2 );

		    if( !(IS_FIXED(lit1) && !FIXED_ON_COMPLEMENT(lit1)) &&
		        !(IS_FIXED(lit2) && !FIXED_ON_COMPLEMENT(lit2)) )
			blocked = 0;

		    if( blocked == 0 ) break;
		}
		if( blocked ) printf("found blocked %i v %i\n", -_treeNode.literal, imp );
	    }
            currentTimeStamp -= _treeNode.gap;
        }
	
	return SAT;
}

void print_graph_data( )
{
	int i;

	clause_order_stamp = (int*) malloc( sizeof(int) * nrofclauses );
	clause_order_array = (int*) malloc( sizeof(int) * nrofclauses );
	clause_parent      = (int*) malloc( sizeof(int) * nrofclauses );
	clause_low         = (int*) malloc( sizeof(int) * nrofclauses );

	allocate_local_datastructures();

	graph_subsume = (int*) malloc( sizeof(int) * (2*nrofvars + 1) );
	for( i = 0; i <= 2*nrofvars; i++ ) 
	    graph_subsume[ i ] = 0;
	
	graph_subsume += nrofvars;

//	printf("c occurence graph has %i components and %i edges\n", 
//		count_components( OCCURENCE_GRAPH), count_edges( OCCURENCE_GRAPH ) );
//	printf("c conflict graph has %i components and %i edges\n", 
//		count_components( CONFLICT_GRAPH), count_edges( CONFLICT_GRAPH ) );
//	printf("c resolution graph has %i components and %i edges\n", 
//		count_components( RESOLUTION_GRAPH), count_edges( RESOLUTION_GRAPH ) );
	printf("p edge %i %i \n", nrofclauses, count_edges( SUBSUMPTION_GRAPH ) );

	graph_subsume -= nrofvars;
	free( graph_subsume );

	free_local_datastructures();

	free( clause_order_stamp );
	free( clause_order_array );
	free( clause_parent );
	free( clause_low );
}

int count_edges( const int graph_flag )
{
    int i, j, lit, clsidx, clschk, nrofedges = 0;

    if( graph_flag <= CONFLICT_GRAPH )
	for( i = 0; i < nrofclauses; i++ )
	    clause_parent[ i ] = -1;	

    for( clsidx = 0; clsidx < nrofclauses; clsidx++ )
    {
	assert( Clength[ clsidx ] > 0 );

	if( graph_flag >= RESOLUTION_GRAPH )
	    mark_complement_of_literals( clsidx );
	else if( graph_flag == OCCURENCE_GRAPH )
	    clause_parent[ clsidx ] = clsidx;
	
	for( i = 0; i < Clength[ clsidx ]; i++ )
	{
	    lit = -Cv[ clsidx ][ i ];
	    for( j = 1; j <= literal_occ[ lit ][ 0 ]; j++ )
	    {
		clschk = literal_occ[ lit ][ j ];
		if( graph_flag <= CONFLICT_GRAPH )
		{
		    if( clause_parent[ clschk ] != clsidx )
		    {	clause_parent[ clschk ] = clsidx;
#ifdef PRINT_EDGES
		        if( clschk < clsidx )
			    printf("e %i %i\n", clschk + 1, clsidx + 1 );
#endif
			nrofedges++; 		    	    }
		}
		else if( count_clashing_literals( clschk, clsidx ) == 1 )
		{
		    if( graph_flag == SUBSUMPTION_GRAPH )
			if( is_subsumed( clschk, clsidx ) )
			    continue;
#ifdef PRINT_EDGES
		    if( clschk < clsidx )
			printf("e %i %i\n", clschk + 1, clsidx + 1 );
#endif
		    nrofedges++;
		}
	    }
	    if( graph_flag == OCCURENCE_GRAPH )
	    {
	    	for( j = 1; j <= literal_occ[ -lit ][ 0 ]; j++ )
	    	{
		    clschk = literal_occ[ -lit ][ j ];
		    if( clause_parent[ clschk ] != clsidx )
		    {	clause_parent[ clschk ] = clsidx;
#ifdef PRINT_EDGES
		        if( clschk < clsidx )
			    printf("e %i %i\n", clschk + 1, clsidx + 1 );
#endif
			nrofedges++;				}
		}
	    }
	}
    }
    assert( (nrofedges % 2) == 0);
    return nrofedges / 2;
}

int count_components( const int graph_flag )
{
	int i, tmp, nrofcomponents = 0;	

	current_order = 0;

	for( i = 0; i < nrofclauses; i++ )
	{
	    clause_order_stamp[ i ] = INITIAL_ORDER;
	    clause_low        [ i ] = INITIAL_LOW;
	}

	for( i = 0; i < nrofclauses; i++ )
	{
	    if( clause_order_stamp[ i ] == INITIAL_ORDER )
	    {
		nrofcomponents++;
		if( depth_first_graph_rec( i, INITIAL_PARENT, graph_flag ) >= 2 )
	     	    printf("c found ARTICULATION clause %i\n", i);
	    }
	}

	for( i = nrofclauses - 1; i >= 0; i-- )
	{
	     tmp = clause_order_array[ i ];
	     determine_clause_low( tmp, graph_flag );
	     if( (clause_low[ tmp ] != 0) &&
	         (clause_low[ tmp ] == clause_order_stamp[ clause_parent[ tmp ] ]) && 
		 (clause_parent[ clause_parent[ tmp ] ] != INITIAL_PARENT) )
	     	    printf("c found ARTICULATION clause %i\n", clause_parent[ tmp ] );
	}

	printf("c number of components = %i\n", nrofcomponents );

	print_components( nrofcomponents );

	return nrofcomponents;
}

int depth_first_graph_rec( const int clsidx, const int parent, const int graph_flag )
{
	int i, j, lit, clschk, counter = 0;

	clause_order_array[ current_order ] = clsidx;
	clause_order_stamp[ clsidx ] = current_order;
	clause_parent     [ clsidx ] = parent; 
	clause_low        [ clsidx ] = current_order;
	current_order++;

	mark_complement_of_literals( clsidx );

	for( i = 0; i < Clength[ clsidx ]; i++ )
	{
	    lit = -Cv[ clsidx ][ i ];
	    for( j = 1; j <= literal_occ[ lit ][ 0 ]; j++ )
	    {
		clschk = literal_occ[ lit ][ j ];
		if( clause_order_stamp[ clschk ] == INITIAL_ORDER )
		{
		    if( graph_flag <= CONFLICT_GRAPH )
		    {
			counter++;
			depth_first_graph_rec( clschk, clsidx, graph_flag );
		    }
		    else if( count_clashing_literals( clschk, clsidx ) == 1 )
		    {
			if( graph_flag == SUBSUMPTION_GRAPH )
			    if( is_subsumed( clschk, clsidx ) ) continue;

			counter++;
			depth_first_graph_rec( clschk, clsidx, graph_flag );
			mark_complement_of_literals( clsidx );
		    }
		}
	    }
	}
	return counter;
}

void determine_clause_low( const int clsidx, const int graph_flag )
{
	int i, j, lit, clschk;

	mark_complement_of_literals( clsidx );
	
	for( i = 0; i < Clength[ clsidx ]; i++ )
	{
	    lit = -Cv[ clsidx ][ i ];
	    for( j = 1; j <= literal_occ[ lit ][ 0 ]; j++ )
	    {
		clschk = literal_occ[ lit ][ j ];
		if( clause_low[ clsidx ] > clause_low[ clschk ] )
		{
		    if( graph_flag >= RESOLUTION_GRAPH )
		    {
			if( count_clashing_literals( clschk, clsidx ) > 1 )
			    continue;			

			if( graph_flag == SUBSUMPTION_GRAPH )
			    if( is_subsumed( clschk, clsidx ) )
			        continue;
		    }
		    clause_low[ clsidx ] = clause_low[ clschk ];
		}
	    }
	}
}

void mark_complement_of_literals( int clsidx )
{
	int i;

	for( i = 0; i < Clength[ clsidx ]; i++ )
	    MarkArray[ -Cv[ clsidx ][ i ] ] = clsidx;
}

int count_clashing_literals( int clsidx, int mark )
{
	int i, counter = 0;

	for( i = 0; i < Clength[ clsidx ]; i++ )
	    if( MarkArray[ Cv[ clsidx ][ i ] ] == mark )
		counter++;

	assert( counter > 0 );
	
	return counter;
}

inline int check_subsumed( const int clsidx )
{
	int i, j, h, subsumed, current;

	for( i = 0; i < Clength[ clsidx ]; i++ )
	    for( j = 1; j <= literal_occ[ Cv[ clsidx ][ i ] ][ 0 ]; j++ )
	    {
	    	subsumed = 1;
		current = literal_occ[ Cv[ clsidx ][ i ] ][ j ];
	    	for( h = 0; h < Clength[ current ]; h++ )
		    if( graph_subsume[ Cv[current][h] ] != graph_subsume_stamp )
		    {
		    	subsumed = 0;
		    	break;
		    } 
	    	if( subsumed ) return 1;
	    }
	return 0;
}

int is_subsumed( const int clsidx1, const int clsidx2 )
{
	int i;

	graph_subsume_stamp++;

	for( i = 0; i < Clength[ clsidx1 ]; i++ )
	    graph_subsume[ Cv[ clsidx1 ][ i ] ] = graph_subsume_stamp;

	for( i = 0; i < Clength[ clsidx2 ]; i++ )
	    if( graph_subsume[ -Cv[ clsidx2 ][ i ] ] == graph_subsume_stamp )
	    	graph_subsume[ -Cv[ clsidx2 ][ i ] ] = 0; 
	    else
	    	graph_subsume[ Cv[ clsidx2 ][ i ] ] = graph_subsume_stamp; 

	if( check_subsumed( clsidx1 ) == 1 ) 
	    return 1;
	return check_subsumed( clsidx2 );
}

void add_blocked_binaries( )
{
	int i, j, idx = 0, *resolution_counter, *resolution_index, nrofadditions = 0;

	MALLOC_OFFSET( resolution_counter, int, nrofvars,  0 );
	MALLOC_OFFSET( resolution_index  , int, nrofvars, -1 );

	for( idx = 0; idx < nrofclauses; idx++ )
	    for( j = 0; j < Clength[ idx ] ; j++ )
	    {
		resolution_counter[ Cv[ idx ][ j ] ]++;
		resolution_index  [ Cv[ idx ][ j ] ] = idx;
	    }

	for( i = -nrofvars; i <= nrofvars; i++ )
	{
	    if( resolution_counter[ i ] == 1 )
	    {
		idx = resolution_index[ i ];
		for( j = 0; j < Clength[ idx ]; j++ )
		    if( Cv[ idx ][ j ] != i )
		    {
			resolution_counter[ -Cv[ idx ][ j ] ]++;
			resolution_index  [ -Cv[ idx ][ j ] ] = idx;
			resolution_counter[ -i ]++;
			resolution_index  [ -i ] = idx;
			nrofadditions++;
		    }
	    }
	}

	printf("c nrofadditions = %i\n", nrofadditions ); 

	Cv      = (int**) realloc( Cv,      sizeof(int*) *  ( nrofclauses + nrofadditions ) );
	Clength = (int* ) realloc( Clength, sizeof(int ) *  ( nrofclauses + nrofadditions ) );


	for( i = -nrofvars; i <= nrofvars; i++ )
	{
	    if( resolution_counter[ i ] == 1 )
	    {
		idx = resolution_index[ i ];
		for( j = 0; j < Clength[ idx ]; j++ )
		    if( Cv[ idx ][ j ] != i )
		    {
			Cv     [ nrofclauses ] = (int*)malloc( sizeof(int) * 2);
			Clength[ nrofclauses ] = 2;
			Cv [ nrofclauses][ 0 ] = -i;
			Cv [ nrofclauses][ 1 ] = -Cv[ idx ][ j ];
			nrofclauses++;
		    }
	    }
	}

	FREE_OFFSET( resolution_counter );
	FREE_OFFSET( resolution_index   );
}

void iteratively_remove_blocked_clauses( )
{
	int _removed_blocked_clauses;

	do
	{
	    _removed_blocked_clauses = removed_blocked_clauses;
	    remove_blocked_clauses( );
	    compactCNF( );
	    printf("c found and removed %i (2:%i; n:%i) blocked clauses (+ %i)\n", removed_blocked_clauses, 
		binary_blocked, nary_blocked, removed_blocked_clauses - _removed_blocked_clauses );
	}
	while( removed_blocked_clauses > _removed_blocked_clauses );
}

void remove_blocked_clauses( )
{
	int i;

	candidates = (int*) malloc( sizeof(int) * nrofclauses );
	nrofcandidates = 0;

	allocate_local_datastructures();

	for( i = 1; i <= nrofvars; i++ )
	{
	    check_blocking_literal(  i );
	    check_blocking_literal( -i );
	}

	free_local_datastructures();

	free( candidates );
}

void check_blocking_literal( int nrval )
{
	int i, j;

	nrofcandidates = 0;
	for( i = 1; i <= literal_occ[ nrval ][ 0 ]; i++ )
	    if( Clength[ literal_occ[ nrval ][ i ] ] > 0 )
		candidates[ nrofcandidates++ ] = literal_occ[ nrval ][ i ];

	for( i = 1; i <= literal_occ[ -nrval ][ 0 ]; i++ )
	{
	    if( Clength[ literal_occ[ -nrval ][ i ] ] == 0 ) continue;

	    mark_complement_of_literals( literal_occ[ -nrval ][ i ] );

	    for( j = 0; j < nrofcandidates; j++ )
		if( count_clashing_literals( candidates[j], literal_occ[-nrval][i] ) == 1 )
		    candidates[ j-- ] = candidates[ --nrofcandidates ];

	    if( nrofcandidates == 0 ) break;
	}

	for( j = 0; j < nrofcandidates; j++ )
	{
	    if( Clength[ candidates[ j ] ] == 2 ) 
#ifdef REMOVE_BLOCKED_BINARIES			  
		binary_blocked++;
#else						
		continue;
#endif
	    else	nary_blocked++;

	    removed_blocked_clauses++;
    	    //printf("clause %i is blocked due to literal %i\n", candidates[ j ], nrval);
	    Clength[ candidates[ j ] ] = 0; 
	}
}

void print_components( const int nrofcomponents )
{
	int i, offset = 0, counter;
#ifdef PRINT_COMPONENTS
	int j, current;
#endif
        for( i = 1; i <= nrofcomponents; i++ )
	{
	    counter = 0;
	    do
	    {
#ifdef PRINT_COMPONENTS
		current = clause_order_array[ counter + offset ];
		for( j = 0; j < Clength[ current ]; j++ )
		    printf("%i ", Cv[ current ][ j ] );
		printf("0\n");
#endif
		counter++;
	    }
	    while( (counter + offset < nrofclauses) && (clause_parent[ clause_order_array[ counter + offset ] ] != INITIAL_PARENT) );

	    offset += counter;
	    printf("c component %i has %i clauses\n", i, counter); 
	}
}

void allocate_local_datastructures( )
{
	int i;

	MarkArray = (int*) malloc( sizeof(int) * (2*nrofvars + 1) );
	for( i = 0; i <= (2*nrofvars); i++ )
		MarkArray[ i ] = -1;

	MarkArray += nrofvars;	

	allocateVc( &literal_occ, &literal_lut );
	literal_occ += nrofvars;
}

void free_local_datastructures( )
{
	literal_occ -= nrofvars;
	freeVc( literal_occ, literal_lut );

	MarkArray -= nrofvars;
	free( MarkArray );
}

void compute_sign_balance( )
{
	int i, j, active = 0, *_occurence; 
	double sign_bias = 0, pos, neg;

	_occurence = (int*) malloc( sizeof(int) * (2*nrofvars+1) );
	_occurence += nrofvars;

	for( i = 1; i <= nrofvars; i++ )
	{
	    _occurence[  i ] = 0;
	    _occurence[ -i ] = 0;
	}

	for( i = 0 ; i < nrofclauses; i++ )
	    for( j = 0; j < Clength[ i ]; j++ )
		_occurence[ Cv[i][j] ]++;

	for( i = 0; i <= nrofvars; i++ )
	{
	    pos = (double) _occurence[  i ];
	    neg = (double) _occurence[ -i ];

	    if( (pos > 0) && (neg > 0) )
	    {
		active++;
		sign_bias +=  (pos / neg) + (neg / pos);
	    }
	}

	sign_bias = (sign_bias / active) - 2;

	printf("c stat :: sign balance is biased by %.3f\n", sign_bias );

	_occurence -= nrofvars;	
	free( _occurence );
}
