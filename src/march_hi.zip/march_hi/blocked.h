void print_graph_data( );
int count_edges( const int graph_flag );

int count_components( int graph_flag );
void iteratively_remove_blocked_clauses( );
void remove_blocked_clauses( );
void check_blocking_literal( int nrval );

void add_blocked_binaries( );

void mark_complement_of_literals( int clsidx );
int count_clashing_literals( int clsidx, int mark );
int is_subsumed( const int clsidx1, const int clsidx2 );

void print_components( const int nrofcomponents );

int seive_blocked_binaries( );

void compute_sign_balance( );

