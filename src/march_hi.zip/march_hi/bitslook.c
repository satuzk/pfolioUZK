/* MARCH Satisfiability Solver

   Copyright (C) 2001-2006 M. Dufour, M. Heule, J. van Zwieten
   [m.dufour@student.tudelft.nl, marijn@heule.nl, zwieten@ch.tudelft.nl]

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

*/

#include <assert.h>
#include <malloc.h>
#include <stdlib.h>
#include <stdio.h>

#include "common.h"
#include "bitslook.h"

//#define LONG_DEBUG
#define NEW_POP

unsigned long *long_mask, *update_mask;
unsigned long long_looks[ 6 ], word_stack[ 6 ], *word_stackp;
unsigned long valid_mask;

unsigned long table_mask[ 10 ], bImp_mask_table[ 100 ], *bImp_mask[ 10 ];
int stored_index[ 6 ];

int long_vars;
int *long_fixstack, *long_fixstackp, *long_fixstacki;
int *mask_stack, *mask_stackp;

#define ALL_ONE    			0xFFFFFFFF
#define LNOT(__mask)			(ALL_ONE ^ (__mask))
#define VM(__mask)			(valid_mask & (__mask))
#define IS_LONG_UNFIXED(__a)		(((long_mask[__a] | long_mask[-__a]) & valid_mask) == 0)
#define IS_LONG_ALLFIXED(__a)		(((long_mask[__a] | long_mask[-__a]) & valid_mask) == valid_mask)
#define IS_LONG_RNDFIXED(__a)           (LNOT((long_mask[__a] | long_mask[-__a]) & valid_mask) & round_mask )
#define IS_LONG_CONFLICT(__a)		(long_mask[__a] & long_mask[-__a])
#define IDX_LIT(__a)			(__a<5?stored_index[4 - __a]:-stored_index[__a - 5])


#define LONG_PUSH_(__a) \
{ \
    if( update_mask[ __a ] == 0 )   \
	*(long_fixstackp++) = __a;  \
    update_mask[ __a ] |= tmp_mask; \
    long_mask  [ __a ] |= tmp_mask; \
}

#define LONG_PUSH(__a, __mask) \
{ \
    if( (tmp_mask = LNOT(long_mask[__a]) & __mask) ) { \
        if( tmp_mask & long_mask[ -__a ] ) { \
	    valid_mask &= LNOT( tmp_mask & long_mask[ -__a ] ); \
	    tmp_mask   &= valid_mask; \
	    _mask      &= valid_mask; \
	    if( tmp_mask ) LONG_PUSH_(__a); \
	} \
	else LONG_PUSH_(__a); \
    } \
}

#define LONG_UNFIX(__a) \
{ \
    long_mask[  __a ] = 0; \
    long_mask[ -__a ] = 0; \
}

#define LONG_FIX(__a, __mask) \
{ \
    unsigned long tmp_mask = __mask & valid_mask; \
    LONG_PUSH_(__a); \
}

int long_fix_binary_implications( const int nrval );
int long_fix_ternary_implications( const int nrval );

void bin_prnt_byte(unsigned long mask);
void print_mask(unsigned long mask);
void analyze_valid_mask();

#ifdef LONG_LOOK
void init_long_lookahead()
{
	int i, j;

	ll_conflicts = 0;

	long_looks[ 0 ] = 0xAAAAAAAA;
	long_looks[ 1 ] = 0xCCCCCCCC;
	long_looks[ 2 ] = 0xF0F0F0F0;
	long_looks[ 3 ] = 0xFF00FF00;
	long_looks[ 4 ] = 0xFFFF0000;

	long_mask = (unsigned long *) malloc( sizeof(unsigned long) * (2*nrofvars + 1) );
	long_mask += nrofvars;

	update_mask = (unsigned long *) malloc( sizeof(unsigned long) * (2*nrofvars + 1) );
	update_mask += nrofvars;

	for( i = 1; i <= nrofvars; i++ )
	{
	    update_mask[  i ] = 0;
	    update_mask[ -i ] = 0;
	}

	long_fixstack = (int*) malloc( sizeof(int) * 2 * nrofvars );
	mask_stack    = (int*) malloc( sizeof(int) * 2 * nrofvars );

	if( sizeof(long) == 4 ) long_vars = 5;
	else			long_vars = 6;

	printf("c long_lookahead():: using %i bits\n", 1 << long_vars );

	for( i = 0; i <  5; i++ ) table_mask[ i ] = LNOT( long_looks[ 4 - i ] );
	for( i = 5; i < 10; i++ ) table_mask[ i ] = long_looks[ i - 5 ];

	for( i = 0; i < 10; i++ )    bImp_mask[ i ] = bImp_mask_table + 10 * i;
	
	for( i = 0; i < 10; i++ )
	    for( j = 0; j < 10; j++ )
		bImp_mask[i][j] = table_mask[i] & table_mask[j];
}

void long_lookahead_index( const int index )
{
	int i, _nrval, branch_var;
	unsigned long stamp_mask, round_mask = ALL_ONE;

do
{
	branch_var = 0;
	stored_index[ index ] = 0;

	round_mask &= valid_mask;

	for( i = 0; i < lookaheadArrayLength; i++ )
	{
	    _nrval = lookaheadArray[i];

	    if( IS_LONG_UNFIXED( _nrval ) )
//	    if( IS_LONG_RNDFIXED(_nrval) )
	    {
		    branch_var = _nrval;
		    stored_index[ index ] = _nrval;
		    break;	
	    }
	}

	if( branch_var == 0 )
	    for( i = 0; i < lookaheadArrayLength; i++ )
	    {
	        _nrval = lookaheadArray[i];
	        if( IS_LONG_RNDFIXED(_nrval) )
	        {
		    branch_var = _nrval;
		    break;
	        }
	    }

#ifdef LONG_DEBUG
	printf("branching %i on index %i with rank %i\n", branch_var, index, Rank[ branch_var ] );
#endif
	if (branch_var == 0 ) break;

	stamp_mask  = LNOT(long_mask[ branch_var ] | long_mask [ -branch_var ]) & round_mask;

	LONG_FIX(  branch_var, stamp_mask &      long_looks[ index ]  );
	LONG_FIX( -branch_var, stamp_mask & LNOT(long_looks[ index ]) );

	round_mask ^= stamp_mask;

}
while( branch_var != 0 && round_mask != 0 );

	while( long_fixstackp > long_fixstack )
	{
#ifdef NEW_POP
	    _nrval = *(long_fixstacki);
	    *(long_fixstacki++) = *(--long_fixstackp);
	    if( long_fixstacki >= long_fixstackp ) long_fixstacki = long_fixstack;
#else
	    _nrval = *(--long_fixstackp);
#endif	
	    if( update_mask[ _nrval ] & valid_mask )
	    {
#ifdef LONG_DEBUG
	    	printf("propagating %i (i: %i p: %i) with L_mask ", _nrval, 
		    long_fixstacki - long_fixstack, long_fixstackp - long_fixstack );
	    	print_mask( long_mask[_nrval] );
	    	printf("\n");
	    	printf("propagating %i (i: %i p: %i) with U_mask ", _nrval, 
		    long_fixstacki - long_fixstack, long_fixstackp - long_fixstack );
	    	print_mask( update_mask[_nrval] );
	    	printf("\n");
#endif
	        if( long_fix_binary_implications ( _nrval ) == UNSAT ) goto long_end;
	        if( long_fix_ternary_implications( _nrval ) == UNSAT ) goto long_end;
	    }
#ifdef LONG_DEBUG
	    else printf("valid_mask excludes %i\n", _nrval );
#endif
	    if( long_mask[ _nrval ] == update_mask[ _nrval ] )
		*(mask_stackp++) = _nrval;

	    update_mask[ _nrval ] = 0;
	}

	return;
	
	long_end:;

	update_mask[ _nrval ] = 0;
	long_mask  [ _nrval ] = 0;

	while( long_fixstackp > long_fixstack )
	{
	    _nrval =  *(--long_fixstackp);
	    update_mask[ _nrval ] = 0;
	    long_mask  [ _nrval ] = 0;
	}
}

int long_lookahead( int *_forced_literal_array, int *_forced_literals )
{
	int i, _forced, forced = 0, check_flag = 0, new_bImps = 0;
#ifdef LONG_DEBUG
	printf("\n*************************\n");
#endif
//	if( depth <= jump_depth ) return SAT;
//	if( depth <= 12 ) return SAT;

	long_fixstackp = long_fixstack;
	long_fixstacki = long_fixstack;
	word_stackp    = word_stack;

	begin:;

	mask_stackp    = mask_stack;

	_forced   = forced;
	new_bImps = 0;
	forced    = 0;

	valid_mask = ALL_ONE;	

	for( i = long_vars -1; i >= 0; i-- )
	{
	    stored_index[ i ] = 0;
	    *(word_stackp++)  = i;
	}

	while( word_stackp > word_stack )
	{
	    i = *(--word_stackp);
	    long_lookahead_index( i );

	    if( valid_mask != ALL_ONE ) check_flag = 1;

	    if( valid_mask == 0 ) break;

//	    if( word_stackp == word_stack )
		analyze_valid_mask();
	}

#ifdef LONG_DEBUG
//	if( check_flag )
	{
	    printf("c ll :: %i \t mask :: ", nodeCount );
	    print_mask( valid_mask );
	    printf("  ");
//	    if( valid_mask == 0 ) printf("*******");
//	    else
#endif
	    {
	        long invalid_mask = LNOT(valid_mask);

//	        for( i = nrofvars; i > 0; i-- )
		while( mask_stackp > mask_stack )
	        { 
		    i = *(--mask_stackp); 
		    if(      (long_mask[  i ] | invalid_mask) == ALL_ONE )
		    {   _forced_literal_array[ forced++ ] =  i; 
			long_mask[  i ] = ALL_ONE;
			long_mask[ -i ] = 0;
#ifdef LONG_DEBUG
			printf("%i ",  i); 
#endif
		    }
		    else long_mask[  i ] = 0;
    
//		    else if( (long_mask[ -i ] | invalid_mask) == ALL_ONE ) 
//		    {   _forced_literal_array[ forced++ ] = -i; 
//			long_mask[ -i ] = ALL_ONE;
//			long_mask[  i ] = 0;
#ifdef LONG_DEBUG
			printf("%i ", -i); 
#endif
//		    }
//		    else LONG_UNFIX(i);
	        }
	    }
#ifdef LONG_DEBUG
	    printf("\n");
	}
#endif
/*
        for( i = nrofvars; i > 0; i-- )
	{
	    assert( update_mask[   i  ] == 0 );
	    assert( update_mask[  -i  ] == 0 );
            assert( IS_LONG_CONFLICT(i) == 0 );
	}
*/
	if( valid_mask == 0 )
	{
	    ll_conflicts++;
	    goto end;
	}

	if( valid_mask != ALL_ONE )
	{
	    int j, lit1, lit2;
	    unsigned long invalid_mask = LNOT( valid_mask );
	    
	    for( i = 0; i < 10; i++ )
		for( j = i + 1; j < 10; j++ )
		{
		    if( i + j == 9 ) continue;
		    if( (bImp_mask[ i ][ j ] & invalid_mask) == bImp_mask[i][j] )	
		    {
			lit1 = IDX_LIT(i);
			lit2 = IDX_LIT(j);

			if( (lit1 == 0) || (lit2 == 0) ) continue;

			CHECK_NODE_STAMP(-lit1);
			CHECK_NODE_STAMP(-lit2);

			new_bImps++;

			CHECK_AND_ADD_BINARY_IMPLICATIONS( lit1, lit2 );
#ifdef LONG_DEBUG
			printf("new bImp_mask %i v %i ", IDX_LIT(i), IDX_LIT(j) );
//			print_mask(bImp_mask[i][j]);
			printf("\n");
#endif
		    }
		}
	}

	*_forced_literals = forced;

	_forced -= forced;
	if( new_bImps > 3 ) goto begin;
	if( _forced   > 0 ) goto begin;

	end:;

	for( i = 0; i < forced; i++ ) 
	    long_mask[ _forced_literal_array[ i ] ] = 0;

	return valid_mask;
}

void analyze_valid_mask()
{
	int i, wl_shift = 0;
	unsigned long wl_multiplier = 1;

	for( i = long_vars - 1; i >= 0; i-- )
	{
	    if( (long_looks[ i ] & valid_mask) == 0 )
	    {
		wl_multiplier |= wl_multiplier << (1 << i);
		*(word_stackp++) = i;
	    }
	    else if( (LNOT(long_looks[ i ]) & valid_mask) == 0 )
	    {
		wl_shift |= 1 << i;
		wl_multiplier |= wl_multiplier << (1 << i);
		*(word_stackp++) = i;
	    }
	}

	if( wl_shift > 0 )
	{
	    int *_mask_stackp = mask_stackp;
	    while( _mask_stackp > mask_stack )
	    {
		i = *(--_mask_stackp);
		long_mask[ i ] = (VM(long_mask[ i ]) >> wl_shift) * wl_multiplier;
		if( long_mask[ i ] == 0 ) *(_mask_stackp) = *(--mask_stackp);
	    }

	    valid_mask = (valid_mask >> wl_shift) * wl_multiplier;
	}
	else if( wl_multiplier > 1 )
	{
	    int *_mask_stackp = mask_stackp;
	    while( _mask_stackp > mask_stack )
	    {
		i = *(--_mask_stackp);
		long_mask[ i ] = VM(long_mask[ i ]) * wl_multiplier;
		if( long_mask[ i ] == 0 ) *(_mask_stackp) = *(--mask_stackp);
	    }

	    valid_mask *= wl_multiplier;
	}
}

int long_fix_binary_implications( const int nrval )
{
	int i, lit, *bImp;
	unsigned long tmp_mask, _mask = update_mask[ nrval ] & valid_mask;
	
	bImp = BIMP_START(nrval);
#ifdef LONG_DEBUG
	printf("c now execution bImp %i size %i\n", nrval, BIMP_ELEMENTS - 1);
#endif
	for( i = BIMP_ELEMENTS; --i; )
	{
	    lit = *(bImp++);
	
	    if( IS_FORCED(lit) ) continue;

	    LONG_PUSH( lit, _mask );

#ifdef LONG_DEBUG
	    if( tmp_mask ) printf("bImp %i -> %i\n", nrval, lit );
#endif
	}
	return valid_mask;
}

int long_fix_ternary_implications( const int nrval )
{
	int i, lit1, lit2, *tImp = TernaryImp[ -nrval ];
	unsigned long tmp_mask, _mask = update_mask[ nrval ] & valid_mask;

        for( i = TernaryImpSize[ -nrval ]; i > 0; i-- )
        {
            lit1 = *(tImp++);
            lit2 = *(tImp++);

	    LONG_PUSH( lit1, _mask & long_mask[ -lit2 ] );
#ifdef LONG_DEBUG
	    if( tmp_mask ) printf("tImp %i & %i -> %i\n", nrval, -lit2, lit1 );
#endif
	    LONG_PUSH( lit2, _mask & long_mask[ -lit1 ] );
#ifdef LONG_DEBUG
	    if( tmp_mask ) printf("tImp %i & %i -> %i\n", nrval, -lit1, lit2 );
#endif
	}
	return valid_mask;
}

void decompose_long_lookahead()
{
	long_mask   -= nrofvars;
	update_mask -= nrofvars;

	free(long_mask);
	free(update_mask);
	free(long_fixstack);
}

void bin_prnt_byte( unsigned long mask )
{
   int i;

   mask &= 0xffff;
   for( i = 0; i < 8; i++ )
   {
      if((mask & 0x80) !=0)  	printf("1");
      else			printf("0");
      mask = mask << 1;
   }
}

void print_mask(unsigned long mask)
{
   bin_prnt_byte( mask >> 24 );    printf(" ");
   bin_prnt_byte( mask >> 16 );    printf(" ");
   bin_prnt_byte( mask >> 8  );    printf(" ");
   bin_prnt_byte( mask >> 0  );
}
#endif
