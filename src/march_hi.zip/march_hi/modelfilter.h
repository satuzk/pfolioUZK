void add_model_constraints();

