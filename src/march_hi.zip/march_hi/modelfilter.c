/* model count procedures */

#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include <assert.h>
#include <time.h>

#include "common.h"
#include "modelfilter.h"

#define FILTERS 	10
//#define MIN_EQ_SIZE	10
#define MAX_EQ_SIZE	9

int *model_constraint;
int *constraint_stamp;

void add_model_constraint()
{
	int i, lit, eq_size = 0;

#ifdef MIN_EQ_SIZE
	do
	{
	    eq_size = 0;

	    for( i = 1; i <= original_nrofvars; i++ )
		if( rand() % 2 )
		    model_constraint[ eq_size++ ] = i;
		
	}
	while( eq_size < MIN_EQ_SIZE );
#endif
#ifdef MAX_EQ_SIZE
	for( i = 1; i <= MAX_EQ_SIZE; i++ )
	{
	    do
	    {
		lit = rand() % original_nrofvars + 1;
	    }
	    while( IS_FORCED(lit) || constraint_stamp[ lit ] == nrofceq );
	
	    constraint_stamp[ lit ] = nrofceq;
	    model_constraint[ eq_size++ ] = lit;
	}
#endif

        Ceq      [ nrofceq ] = (int*) malloc( sizeof( int ) * eq_size );
        CeqSizes [ nrofceq ] = eq_size;
        CeqValues[ nrofceq ] = (rand() % 2) * 2  - 1;

	for( i = 0; i < eq_size; i++ )
	{
	    Ceq[ nrofceq ][ i ] = model_constraint[ i ];

//	    printf("%i ", model_constraint[ i ] );

            CHECK_VEQ_BOUND( model_constraint[ i ] );
            Veq[ model_constraint[ i ] ][ Veq[ model_constraint[ i ] ][ 0 ]++ ] = nrofceq;
            VeqLUT[ model_constraint[ i ] ][ VeqLUT[ model_constraint[ i ] ][ 0 ]++ ] = i;
	}

//	printf(" = %i\n", CeqValues[ nrofceq ] );

	eq_found[ eq_size ]++;

	nrofceq++;
}

void add_model_constraints()
{
#ifdef MODEL_FILTER
	int i;

	srand( (unsigned)time( NULL ) );

	model_constraint = (int*) malloc( sizeof(int) * nrofvars + 1 );
	constraint_stamp = (int*) malloc( sizeof(int) * nrofvars + 1 );

	for( i = 1; i <= nrofvars; i++ )
	    constraint_stamp[ i ] = -1;

	for( i = 1; i <= FILTERS; i++ )
	    add_model_constraint();

	free( model_constraint );
	free( constraint_stamp );
#endif
}
