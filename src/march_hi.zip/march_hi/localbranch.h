
void init_localbranching( );
void determine_components( );

