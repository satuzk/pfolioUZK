void init_diameter();
