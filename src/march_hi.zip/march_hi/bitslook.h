

void init_long_lookahead();
int long_lookahead( int *_forced_literal_array, int *_forced_literals );
void decompose_long_lookahead();

