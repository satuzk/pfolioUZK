#!/bin/sh

unzip SatELite_from_Glucose2.0.zip
cd SatELite_from_Glucose2.0
export FM=$PWD/ForMani
cd SatELite
make realclean
make r
cp SatELite_release ../..
