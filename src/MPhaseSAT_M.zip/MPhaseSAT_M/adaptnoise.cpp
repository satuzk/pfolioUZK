#include "Multiflip.h"

#define invPhi 10
#define invTheta 5

int lastAdaptFlip, lastBest, AdaptLength, NB_BETTER;
extern int MY_CLAUSE_STACK_fill_pointer;
extern int NOISE;
extern int NOISE1;
extern int LNOISE;
extern int numClauses;

void initNoise()
{
  lastAdaptFlip=0;
  lastBest = MY_CLAUSE_STACK_fill_pointer;
  NOISE=LNOISE=NB_BETTER=0;
  AdaptLength=numClauses / invTheta;
}

void adaptNoveltyNoise(int flip) {
  if ((flip - lastAdaptFlip) > AdaptLength) {
    NOISE += (int) ((100 - NOISE) / invPhi);
    LNOISE= (int) NOISE/10;
    lastAdaptFlip = flip;      
    lastBest = MY_CLAUSE_STACK_fill_pointer;
  } 
  else if (MY_CLAUSE_STACK_fill_pointer < lastBest) {
      NOISE -= (int) (NOISE / invPhi / 2);
      LNOISE= (int) NOISE/10;
      lastAdaptFlip = flip;
      lastBest = MY_CLAUSE_STACK_fill_pointer;
  }
}
