/*
 MPhaseSAT_M  Feb 2011
 Copyright (c) 2011, Jingchao Chen, Donghua University,China.  All rights reserved.
*/

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <time.h>
#include "constants.h"
#include <signal.h>
#include "precosatXOR.h"
#include "MersenneTwister.h"

float *size_difA;
float *lengthWeighA;
float *DIFF;

extern int  numatom;          // the number of atoms 
extern int  numClauses;      //number of clauses
int ClsVarRate;
bool on_the_fly;
MTRand mtrand(100);

int originClauses;

extern int **Clit;         //literals for each clause       
extern int **Leq;    //  literals for each active XOR clause
extern int *CNF_index_Mem;  //* memory for clause numbers;
extern int  numXOR;           // the number of active XOR clauses

void freeall_Index();
void verify_output();
extern int * unit;
extern int *outEquAtom;

int *key_lit;
int *StackLit;
int *VarRank;

int RealNumVars;              // the real number of atoms
int *fixedvar;     // atom which occurs in unit clause
char *FileName;

extern int n_inative;
extern int *iLit_set;  // the set of big active XOR clauses
extern int **inaLit;   // literals of XOR clauses for each inactive variable
extern int *Lit_set;
char *Deletedclause;
int delclauses;
bool localfind;

void init_weight();
void check(int sol[],int **CNFcls, int numCls);
void readSATProblem(char *CNFfile, bool readlarge);

int TopSolver();
int OneLaysolve(int *Ranklit);
int Loadsolver_end(intpp & clsLit, int & numCls, int & numXor,int *RankVar);
int Loadsolver(intpp & clsLit, int & numCls, int & numXor, int *rankvar);
int Loadsolver(int decision_limit,int **clsLit, int numCls, int numXor,int unit_sp,int *RankVar,bool loadbin,int * & solution);

void setDoubleDataIndex(int **Cl,int **clauseSet,int *clauseBase,int numCls,int offset);
void setEqDataStruct(int **Veq,int **EqSet,int *EqBase,int numEq);
bool on_the_fly_AMO();

void sortClause(int **Clit1,int *Lit_set1,int & numCls, int numcolumn,int delrepeat);

int IterativeUnitPropagationShort(int lit,float *diff,int *queue);
void SetClausePtr(int **clauseP,int *ClauseStart,int cntClauses);
int sortkey(int *keyvar,int *VarWeight);

int PreProcessCNF();
void restoreSolution( int sol[]);
void inactiveSolution(int *Fsolution);

int *seen; //for binary reasoning 
int **OccurenceA;      // where each literal occurs: indexed as OccurenceA[literal+numatom][n,1...n]
int **XORoccurA; // // where each XOR literal occurs: indexed as XORoccurA[literal+numatom][n,1...n]
/*
 * A signal handling function.
 * For handling user interuption (Ctrl+c).
 * Print out execution stats and exit.
 *
 */
void SIGINT_handler(int signum) 
{
  printf("c \n");
  printf("c \n");
  printf("c INTERRUPTED \n");
  printf("c Time used: %fs\n",get_cpu_time());
  exit(0); 
}

/*
 * A signal handling function. 
 * For handling segmentation fault.
 * 
 * Print out indicator message and exit.
 */
void SIGSEGV_handler(int signum) 
{
  printf("c \n");
  printf("c \n");
  printf("c SEGMENTATION FAULT \n");
  printf("c \ns UNKNOWN\n");
  printf("c \n");
  exit(0); 
}

//time measuring function
double nowtime() 
{
#ifdef _MSC_VER
#include <ctime>
    return (double)clock() / CLOCKS_PER_SEC;
#else
  struct rusage u;
  if (getrusage (RUSAGE_SELF, &u)) return 0;
  double res = u.ru_utime.tv_sec + 1e-6 * u.ru_utime.tv_usec;
  res += u.ru_stime.tv_sec + 1e-6 * u.ru_stime.tv_usec;
  return res;
#endif
}

int main_SAT,main_UNSAT;
extern int local_find_mem_flag;

int main(int  argc, char *argv[])
{
   signal(SIGINT,SIGINT_handler);
   signal(SIGSEGV,SIGSEGV_handler);
   srand(INIT_RANDOM_SEED);
  
   local_find_mem_flag=0;
   main_SAT=SAT;
   main_UNSAT=UNSAT;

   if (argc<2) {
       printf("c Using format: MPhaseSAT_M CNF_file\n");
       exit(0);
//        FileName=filename;
   }
   else FileName=argv[1];
   printf("c MPhaseSAT_M version 401 suited for random catagory by Jingchao Chen,  April 1,2011 \n");
   printf("c input CNF file=%s \n",FileName);
//   getchar();
   unit=fixedvar=outEquAtom=0;
   double starttime=nowtime();
   int result=TopSolver();
   switch(result) 
   {    case SAT:
	   	     verify_output();
			 result=10;
			 break;
       case UNSAT:
 	        printf("c \ns UNSATISFIABLE\n"); 
		    result=20;
            break;
	   default:
            printf("c \ns UNKNOWN\n");
	        result=0;
   }
   if(Clit!=0){
		 free(Clit[0]);
	     free(Clit);
   }
   if(fixedvar){
	   if(fixedvar!=unit) free(fixedvar);
   }
   if(unit) free(unit);
   if(outEquAtom) free(outEquAtom);
   if(n_inative) {
		free(iLit_set);
		free(inaLit);
   }
   freeall_Index();
   printf("c \nc  Running time=%f \n", nowtime()-starttime);
   exit(result);
   return result;
}

int init_simplify();
int doubleSolver();
void readCNFclause();

void SetClausePtr(int **clauseP,int *newPointer,int cntClauses)
{   
    for(int i=1; i<=cntClauses; i++) clauseP[i]=newPointer+(clauseP[i]-clauseP[0]);
	clauseP[0]=newPointer;
}

void IncClauseMemory(int cnum,int clauseMemSize)
{
	int *Clause_start=(int*)realloc(Clit[0], sizeof(int)*clauseMemSize);
    SetClausePtr(Clit, Clause_start,cnum);
}

void appendCNF_to_XOR()
{   
    int i;

 	int CNFsize=Clit[numClauses]-Clit[0];
	int XORsize;
	if(numXOR) XORsize=Leq[numXOR]-Leq[0];
	else XORsize=0;
	if(numXOR>0 || Deletedclause){
		int size=CNFsize+XORsize;
        int *newLit,**newLp;
		int sumItem=numXOR+numClauses+1;
		if(numXOR>0) {
//XOR clauses
			newLit=(int*)realloc(Leq[0],sizeof(int)*size);
			newLp=(int**)realloc(Leq,sizeof(int *)*sumItem);
			for (i=1; i<=numXOR; i++) newLp[i]=newLit+(newLp[i]-newLp[0]);
	        newLp[0]=newLit;
            Leq=0;
		}
		else{
		  newLit=(int *) malloc(sizeof(int)*size);
			newLp=(int **) malloc(sizeof(int*)*sumItem);
			newLp[0]=newLit;
		}
//move CNF to end		
		int newcls=numXOR;
		int litsum=XORsize;
		for(i=0; i<numClauses; i++){
			if(Deletedclause){
				if(Deletedclause[i]) continue;
			}
			for(int *pv=Clit[i]; pv<Clit[i+1]; pv++) newLit[litsum++]=*pv;
			newcls++;
			newLp[newcls]=newLit+litsum;
		}
		delclauses=0;
		if(Deletedclause){
		     for(i=0; i<numClauses; i++){
				if(Deletedclause[i]==0) continue;
			    for(int *pv=Clit[i]; pv<Clit[i+1]; pv++) newLit[litsum++]=*pv;
			    newcls++;
			    newLp[newcls]=newLit+litsum;
				delclauses++;
			 }
	         numClauses-=delclauses;
			 free(Deletedclause);
			 Deletedclause=0;
	  	}
        free(Clit[0]);
        free(Clit);
        Clit=newLp;
	}
//	printf("c numClauses=%d delclauses=%d \n",numClauses,delclauses);
}

/* 
 * Prints the current solution 
 */
void print_solution(int sol[])
{
    printf("v ");
    for(int i=1; i<=numatom; i++) if(sol[i]) printf("%d ", sol[i]);
    printf("\nv 0\n");
}

//look both by an iterative uint propagation
int IterativeUnitPropagation2(int lit0,int * & Queue, int & Qsize)
{   int i,cli,ForcedLit=0;
    int lt,rc,var,sp,sp1,*plit;
    
    Queue[0]=unit[ABS(lit0)]=lit0;
    sp1=0; sp=1;
	while(sp1<sp){
	 	lt=Queue[sp1++];
//longer clause		
		int numocc = OccurenceA[-lt][0];
	    for (i = 1; i < numocc ;i++) {
			  cli=OccurenceA[-lt][i];
              int m=0;
	          for(plit=Clit[cli+1]-1; plit>=Clit[cli]; plit--){
	    		    var=ABS(*plit); 
				    if(unit[var]==*plit) goto nextC;
				    if(unit[var]==0) {m++; ForcedLit=*plit;}
			 }
			 if(m==0) {rc=UNSAT; goto ret;}; //conflict
			 if(m==1) {
				 if(sp>=Qsize){
                     Qsize+=10000;
                     Queue=(int*)realloc(Queue, sizeof(int)*Qsize);
				 }
				 Queue[sp++]=unit[ABS(ForcedLit)]=ForcedLit;
			 }
nextC:          ;
		}
	}
	rc=UNKNOWN;
ret:
    for(i=0; i<sp; i++) unit[ABS(Queue[i])]=0;
	Queue[sp]=0;
	return rc;
}

inline bool simple_UnitProp(int sp1, int &sp, int **clslit, int **CNFocc)
{   int i,ForcedLit[10];
	
	while(sp1<sp){
	   	int lt=StackLit[sp1++];
//longer clause		
		int numocc = CNFocc[-lt][0];
	    for (i = 1; i < numocc ;i++) {
			int cli = CNFocc[-lt][i];
			int m=0,*pv;
			int *endp=clslit[cli+1];
			for(pv=clslit[cli]; pv<endp; pv++){
	     	    int var=ABS(*pv);
				if(unit[var]==*pv) goto nextC;
				if(unit[var]==0) {if(m<2) ForcedLit[m++]=*pv;}
			}
			if(m==0) return true; //conflict
	        if(m==1) {
			 	int var=ABS(ForcedLit[0]);
				StackLit[sp++]=unit[var]=ForcedLit[0];
			}
nextC:     
			;
		}
	}
    return false; // no conflict
}

int deletegarbage(int & change);
int Loadbigsolver(int decision_limit,int ** & clsLit, int numCls,bool map);//bug

bool look2polar(int occlimit)
{   int sz1=10000;
	int *Queue1=(int *)calloc(sz1,sizeof(int));
    int sz2=10000;
	int *Queue2=(int *)calloc(sz2,sizeof(int));
    int numfix=0;
    int lookn=0;

	for(int vv=1; vv<=numatom; vv++){
		 if(numfix==0 && numatom>10000 && lookn>200) break; 
		 if(unit[vv]==0){
        	 if(OccurenceA[vv][0]<=1 && OccurenceA[-vv][0]<=1) continue; // equ A=B
			 if(OccurenceA[vv][0]==1)  { unit[vv]=-vv; continue;}
             if(OccurenceA[-vv][0]==1) { unit[vv]=vv;  continue;}
		     if(OccurenceA[vv][0]<occlimit && OccurenceA[-vv][0]<occlimit) {
				 continue;
			 }
			 if(occlimit>10){
				 if(lookn>500 && (numatom>500000 || numClauses>1000000) && OccurenceA[vv][0]<5000 && OccurenceA[-vv][0]<5000) continue;
				 lookn++;
			     if(numClauses>1000000 && lookn>200) break;
			 }
			 int rc1=IterativeUnitPropagation2(vv, Queue1,sz1);
			 int rc2=IterativeUnitPropagation2(-vv,Queue2,sz2);
			 if(rc1==UNSAT){
				  if(rc2==UNSAT){
					  free(Queue1);
                      free(Queue2);
					  return true;// conflict
				  }
				  int k=0;
				  while(Queue2[k]){
						unit[ABS(Queue2[k])]=Queue2[k];
						k++;
				  }
			  }
			  else{
				   if(rc2==UNSAT){
			          int k=0;
					  while(Queue1[k]){
						  unit[ABS(Queue1[k])]=Queue1[k];
							k++;
						}
				   }
				   else{
                      int k=0;
					  while(Queue1[k]){
						  int lit=Queue1[k];
						  int var=ABS(lit); 
						  if(unit[var]==0){
							  if(lit<0) unit[var]=lit-1;
							  else unit[var]=lit+1;
						  }
						  k++;
					  }
                      k=0;
					  int m=0;
					  while(Queue2[k]){
						  int lit=Queue2[k];
						  int lit1,var=ABS(lit); 
						  if(unit[var]){
							  if(lit<0) lit1=lit-1;
							  else lit1=lit+1;
							  if(unit[var]==lit1) unit[var]=lit,m++;
						  }
						  k++;
					  }
					  if(m) { numfix+=m;}
					  k=0;
					  while(Queue1[k]){//clear
						  int var=ABS(Queue1[k]); 
						  if(ABS(unit[var])!=var) unit[var]=0;
						  k++;
					  }
				   }
			  }
		 }
	}
	free(Queue1);
	free(Queue2);
//	printf("c numfix=%d sum=%d \n",numfix,lookn);
  	return false;
}
extern int CNF_space;

void extendspace(int size)
{
	if(size<2048) size=2048;
	if(size<CNF_space/8) size=CNF_space/8;
	CNF_space+=size;
    Lit_set=(int*)realloc(Clit[0], sizeof(int)*CNF_space);
	SetClausePtr(Clit,Lit_set,numClauses);
}

// x=a^b <=> {x, -a,-b}{-x, a}{-x,b}
//QG6-gensys, hwb-n28, flat200-100
void ANDgate(int vi, int andclsNo[4])
{   int ab;
   // printf("c ANDgate \n");
    int i,j,k;
	int occ=OccurenceA[vi][0];
   	k=0;
	ab=0;
    for(i=1; i<occ; i++){ // x==a^b
   	    int cliA=OccurenceA[vi][i];
	    andclsNo[0]=cliA;
		if(Clit[cliA+1]-Clit[cliA]!=3) continue;
   	   	k=1;
	    for(int *pa=Clit[cliA]; pa<Clit[cliA+1]; pa++){
			  if(*pa==vi) continue;
			  int vb=-(*pa);
	          int occb=OccurenceA[-vi][0];
	          for(j=1; j<occb; j++){
		          int cliB=OccurenceA[-vi][j];
           		   if(Clit[cliB+1]-Clit[cliB]!=2) continue;
                   if(Clit[cliB][0]==vb || Clit[cliB][1]==vb) {
					   if(ab!=vb) {
						   ab=vb; andclsNo[k++]=cliB; 
						   if(k==3) {
							  // printf("c Acls=%d   Bcls=%d Bcls=%d \n",andclsNo[0],andclsNo[1],andclsNo[2]);// Niklas E.en and Armin Biere
							   return;
						   }
					   }
				   }
			  }
		}
	}
	andclsNo[0]=-1;
}
//flat200-100
void subsumptionResolution(int vi, int & deletedVnum,bool & NewUnit, int delta)
{
	int i,j,k,m,pos,neg,*pa,*pb,cliA,cliB,k1;
	int *curCls,nclauses;
    int usedSize;
    int andclsNo[4];

	pos=OccurenceA[vi][0];
    neg=OccurenceA[-vi][0];
	usedSize=Clit[numClauses]-Clit[0];
	nclauses=numClauses;
	int newCNFs=0,end=0;
	if(delta<=1){
		if(pos+neg<8) delta=0;
	    else delta=1;
    }
	else delta=-delta;

	andclsNo[0]=-1;
	if(pos+neg<8){
		ANDgate(vi,andclsNo);
		if(andclsNo[0]==-1) {
			vi=-vi;
			ANDgate(vi,andclsNo);
			pos=OccurenceA[vi][0];
	        neg=OccurenceA[-vi][0];
		}
	}
	for(i=1; i<pos; i++){
   	      cliA=OccurenceA[vi][i];
   		  k1=Clit[cliA+1]-Clit[cliA];
		  if(usedSize+k1>CNF_space-128) extendspace(2*k1);
		  curCls=Clit[numClauses];
		  k1=0;
		  for(pa=Clit[cliA]; pa<Clit[cliA+1]; pa++) {
			  int vv=ABS(*pa);
			  if(unit[vv]){
				  if(unit[vv]==*pa) goto clearSeen;
			  }
			  else if(*pa!=vi) curCls[k1++]=seen[vv]=*pa;
		  }
		  if(k1==0){
              numClauses=nclauses;
			  return;
		  }
		  k=k1;
	      for(j=1; j<neg; j++){
   	           cliB=OccurenceA[-vi][j];
			   /*
			   if(andclsNo[0]>=0){// S=R*G' v R'*G
				   printf("c and gate subsumption \n");// Niklas E.en and Armin Biere
				   if(andclsNo[0]!=cliA) { // R(x)*G(-x)
					   	   if(andclsNo[1]!=cliB && andclsNo[2]!=cliB) continue; //??? bug
				   }
				   else{ // G(x)*R(-x)
	   	              if(andclsNo[1]==cliB || andclsNo[2]==cliB) continue; //??? bug
				   }
			   }
               */
		 	   int Bsize=Clit[cliB+1]-Clit[cliB];
			   if(usedSize+k+Bsize>CNF_space-128) {
					  extendspace(k+2*Bsize);
					  curCls=Clit[numClauses];
			   }
			   for(pb=Clit[cliB]; pb<Clit[cliB+1]; pb++){
				   if(*pb==-vi) continue;
                   int vv=ABS(*pb);
			       if(unit[vv]){
				       if(unit[vv]==*pb) goto nextj;
					   continue;
				   }
				   if(seen[vv]==-(*pb)) goto nextj;
				   if(seen[vv]==0)  curCls[k++]=*pb;
               }
			   if(k==1){
				   NewUnit=true;
				   unit[ABS(curCls[0])]=curCls[0];
//				   printf( " u[%d]=%d ", curCls[0], unit[ABS(curCls[0])]);
				   end=1; 
				   goto clearSeen;
			   }
		       newCNFs++;
			   if(newCNFs>pos+neg-delta){ end=1; goto clearSeen; }
		       Clit[++numClauses]=curCls+k;
               usedSize+=k;
			   if(usedSize+k1>CNF_space-128) extendspace(2*k1);
		  	   curCls=Clit[numClauses];
		       for(m=0; m<k1; m++) curCls[m]=curCls[m-k]; // move A-type CNF to next
nextj:          
			   k=k1;       
		  }
clearSeen:
          for(pa=Clit[cliA]; pa<Clit[cliA+1]; pa++) seen[ABS(*pa)]=0;
		  if(end) {numClauses=nclauses; return;}
	}
	if(newCNFs<=pos+neg-delta){//set delete mark
        int occP=OccurenceA[vi][0];
	    int occN=OccurenceA[-vi][0];
		for(m=0; m<2; m++){
			int vv,occM;
			if(m) {vv=vi;  occM=occP;}
			else  {vv=-vi; occM=occN;}
		    for(i=1; i<occM; i++){
				cliA=OccurenceA[vv][i];
				for(int *pv=Clit[cliA]; pv<Clit[cliA+1]; pv++) OccurenceA[*pv][0]=OccurenceA[-*pv][0]=0;
				Clit[cliA][0]=0;
			}
		}
		deletedVnum++;
	}
	else numClauses=nclauses;
}	

//extend space for subsumption Resolution by clause distribution
void subsumeDelete()
{    int deletedVnum=0;
     int change;
	 bool mOut=true;
	 bool NewUnit;
	 seen=(int *)calloc(numatom+1,sizeof(int));
	 while(mOut){
	      mOut=false;
		  for(int i=0; i<2 || NewUnit; i++){
			  NewUnit=false;
		     int clauseLimit=numClauses/20;
	         if(clauseLimit<1000) clauseLimit=numClauses/2;
			 clauseLimit+=numClauses;
             Clit=(int**)realloc(Clit, sizeof(int *)*(clauseLimit+100));
	         CNF_space=Clit[numClauses]-Clit[0];
             CNF_space=CNF_space+CNF_space/10;
             Lit_set=(int*)realloc(Clit[0], sizeof(int)*CNF_space);
   	         SetClausePtr(Clit,Lit_set,numClauses);
	          int preNum=deletedVnum;
		      for(int vi=1; vi<=numatom; vi++){
		          if(unit[vi]) continue;
				  int numOccur=OccurenceA[vi][0]+OccurenceA[-vi][0]; //2
		          if(numOccur<=2) continue;
			      else{//14
				     if(numClauses+14>=clauseLimit) {mOut=true; goto memOut;}
				     if(numOccur<14 && OccurenceA[vi][0]>1 && OccurenceA[-vi][0]>1) {
				        subsumptionResolution(vi, deletedVnum,NewUnit,0);
					 }
				  }
			  }
memOut:
    		 if(preNum!=deletedVnum) {
				  int rc=deletegarbage(change);
				  if(rc==UNSAT){
					   printf("c \ns UNSATISFIABLE\n");
                       exit(20);
				  }
		      }
		  	 int size=Clit[numClauses]-Clit[0];
		     OccurenceA-=numatom;
	         free(OccurenceA[0]);
	         OccurenceA+=numatom;
	   	     CNF_index_Mem=(int *) malloc(sizeof(int *)*(size+2*numatom+1));
		     setDoubleDataIndex(Clit,OccurenceA,CNF_index_Mem, numClauses,0);
			 if(preNum==deletedVnum || mOut) break;
		  }
	 }
     free(seen);
//	 printf("c deletedVnum=%d \n",deletedVnum);
	 return;
}

int solveLargeCNF(char * CNFfile, int *solution);
int  *mapvar;
int oldnumatom;

void varMap()
{    int vi,Vno=0;
     oldnumatom=numatom;
	 mapvar=(int *)calloc(numatom+1,sizeof(int));
     for(vi=1; vi<=numatom; vi++){
		 if(OccurenceA[vi][0]+OccurenceA[-vi][0]<=2){
			 if(numXOR==0) continue;
			 if(XORoccurA[vi][0]<2) continue;
		 }
	     Vno++;
		 mapvar[vi]=Vno;
	 }
	 for(int i=1; i<=numClauses+numXOR; i++){
		for(int *pv=Clit[i-1]; pv<Clit[i]; pv++){
			int var=ABS(*pv);
			int newv=mapvar[var];
			if(*pv<0) *pv=-newv;
            else *pv=newv;
		}
	 }
	 int j=0;
     for(vi=1; vi<=numatom; vi++)  if(mapvar[vi]) mapvar[j++]=vi; 
	 mapvar=(int*)realloc(mapvar, sizeof(int)*Vno);
     OccurenceA-=numatom;
	 free(OccurenceA[0]);
     free(OccurenceA);
	 OccurenceA=0;
     if(numXOR){
	     free(XORoccurA[0]);
	     free(XORoccurA);
	     XORoccurA=0;
	 }
	 numatom=Vno;
	// printf("c new #var=%d \n", numatom);
}		  	

void rebuildCNFindex(int offset,int old_numatom)
{
     if(OccurenceA==0) OccurenceA=(int **) malloc(sizeof(int *)*(2*numatom+1));
     else {
			 OccurenceA-=old_numatom;
	         free(OccurenceA[0]);
	 }
	 OccurenceA+=numatom;
	 int sum=Clit[numClauses+offset]-Clit[offset];
	 CNF_index_Mem=(int *) malloc(sizeof(int *)*(sum+2*numatom+1));
	 setDoubleDataIndex(Clit,OccurenceA,CNF_index_Mem, numClauses,offset);
}

void buildOccIndex(int old_numatom)
{
    rebuildCNFindex(numXOR,old_numatom);
    if(!numXOR) return;
    if(XORoccurA){
		free(XORoccurA[0]);
		free(XORoccurA);
    }
	XORoccurA=(int **) malloc(sizeof(int *)*(numatom+1));
	int size=Clit[numXOR]-Clit[0];
	int *EQbase=(int *) malloc(sizeof(int)*(size+numatom+1));
	setEqDataStruct(Clit, XORoccurA, EQbase,numXOR);
}

int XOR_Preprocess();
void verify_output()
{
     readSATProblem(FileName,true);
	 check(unit,Clit,numClauses);
     printf("c \ns SATISFIABLE\n");
	 print_solution(unit);
}

int *AMOvar;

void set_AMOvar()
{
    AMOvar=(int *)calloc(numatom+1,sizeof(int)); // At most one
    for(int i=0; i<numClauses; i++){
   		 if(Clit[i+1]-Clit[i]<8) continue;
		 for(int *pv=Clit[i]; pv<Clit[i+1]; pv++){
		     if(AMOvar[ABS(*pv)]){
				   if(AMOvar[ABS(*pv)]!=*pv) AMOvar[ABS(*pv)]=0;
			 }
			 AMOvar[ABS(*pv)]=*pv;
		 }	   
  }
}
  
int preLoadsolver(intpp & clsLit, int & numCls);   
void forwardsubsume(int **Clit1,int & numCli, bool pos_neg);
void BlockClauseElimination();
void XOR_varElimination();
void checkCNFXOR(int sol[],int **CNFcls, int numCls,int numXOR,int var);
int SimpfySATProblem();
void old_varElimination();

int EdgeMatch(int & sgi_AMO_sz);
int sgi_AMO_len;
bool crypto_Gss;

int TopSolver()
{   
    int rc,change;
    int i;
    
	StackLit=0;
	init_weight();
	sgi_AMO_len=0;
	crypto_Gss=false;
	Deletedclause=0;
	delclauses=0;
	localfind=false;
//restart:
    readCNFclause();
    printf("c Clause#=%d  var#=%d  ratio=%d \n",numClauses,numatom,numClauses/numatom);
  
   	numXOR=0;
	outEquAtom=AMOvar=mapvar=0;

	unit=fixedvar=(int *)calloc(numatom+1,sizeof(int));
	ClsVarRate=originClauses/numatom;
    if(originClauses>6000 && numatom>200 && originClauses<2000000 && numatom<100000) {
		int old_numatom=numatom;
       	rc=EdgeMatch(sgi_AMO_len); 
		numatom=old_numatom;
	    if(rc==SAT) return SAT;
	    if(crypto_Gss) goto prep;
	}

	if(numatom<980 && ClsVarRate>145) mtrand.seed(10);//  vmpc_31
	else mtrand.seed(100); 

	if(originClauses>6000 && (numatom>500 || ClsVarRate>100) && originClauses<6800000 && numatom<2500000) { 
		if(originClauses<1500000 && numatom<200000){
	    	if(ClsVarRate<22 || ClsVarRate>27 || numatom<5000 || numatom>20000){
	        	rc=SimpfySATProblem();
	    	    if(rc==UNSAT) return UNSAT;
		        forwardsubsume(Clit,numClauses,true);
			}
		}
		if(originClauses<18000) sgi_AMO_len=0; 
		if(sgi_AMO_len==0 || sgi_AMO_len>=30) rc=preLoadsolver(Clit, numClauses);
  		else rc=UNKNOWN;
        if(rc==UNSAT) return UNSAT;
		if(rc==SAT){
		 	restoreSolution(unit);
	   	    if(AMOvar) free(AMOvar);
			return SAT;
		}
 	}
//	printf("c originClauses=%d numClauses=%d \n",originClauses,numClauses);
   	if(AMOvar){
		free(AMOvar);
		AMOvar=0;
	}
prep:
    rebuildCNFindex(0,numatom);
	rc=PreProcessCNF();
    if(rc==UNSAT) return UNSAT;
	if(crypto_Gss) goto xorprep;
	if(look2polar(30)) return UNSAT; 
	seen=(int *)calloc(numatom+1,sizeof(int));
	rc=deletegarbage(change);
	free(seen);
    if(rc==UNSAT) return UNSAT;
	if(OccurenceA){
		OccurenceA-=numatom;
	    free(OccurenceA[0]);
        free(OccurenceA);
		OccurenceA=0;
	}
	if(originClauses<10000000) forwardsubsume(Clit,numClauses,true);
    rebuildCNFindex(0,numatom);
    XOR_varElimination();
	subsumeDelete();
//	printf("c subsumeDelete end numClauses=%d \n",numClauses);
	if(originClauses<5000000){
		int delrepeat=1;
	    sortClause(Clit,Clit[0],numClauses,4,delrepeat);
	}
//	printf("c Delete repeated  numClauses=%d \n",numClauses);
	
	if(originClauses>=10000000) {
	   varMap();
	   free(outEquAtom);
       outEquAtom=0;
	   int decision_limit=1000000000;
	   rc=Loadbigsolver(decision_limit,Clit, numClauses,true);
       free(mapvar);
       if(rc==UNSAT) return UNSAT;
       if(rc==SAT){
	       readSATProblem(FileName,true);
           seen=(int *)calloc(numatom+1,sizeof(int));
	       deletegarbage(change);
//		   printf("c #clauses=%d \n",numClauses);
		   for(i=0; i<10; i++){
			    rebuildCNFindex(0,numatom);
			    look2polar(2);
 				deletegarbage(change);
                if(!change) break;
		   }
		   free(seen);
	       if(i>=10) rebuildCNFindex(0,numatom);
		   varMap();
	       if(numClauses){
			   rc=Loadbigsolver(decision_limit,Clit, numClauses,true);
               if(rc!=SAT){
				    printf("c \ns UNKNOWN\n");
	                exit(0);
			   }
		   }
		   free(mapvar);
           return SAT;
	   }
	   printf("c \ns UNKNOWN\n");
	   exit(0);    
	}
	if(originClauses>3000000) goto No_prep;
xorprep:
	rc=XOR_Preprocess();
	if(rc==UNSAT) return UNSAT;
  	if(numXOR>1000) crypto_Gss=false;
    if(crypto_Gss) {
		 old_varElimination();
	}
	appendCNF_to_XOR();
No_prep:
	numClauses+=delclauses;
    buildOccIndex(numatom);
   	int map_numatom=numatom;
    varMap();
	numClauses-=delclauses;
    buildOccIndex(map_numatom); //old numatom
    map_numatom=numatom; //new numatom

	fixedvar=(int *)calloc(numatom+1,sizeof(int));
	StackLit=(int *) malloc(sizeof(int)*(numatom+1));
	rc=doubleSolver();
	if(Clit!=0){
		 free(Clit[0]);
	     free(Clit);
		 Clit=0;
	}
	freeall_Index();
	numXOR=0;
	if(rc==SAT){
	      int i,unfixed=0;
		  for (i = 1; i <= map_numatom; i++) {
		   		 int var=mapvar[i-1];
				 if(fixedvar[i]<0) unit[var]=-var;
				 if(fixedvar[i]>0) unit[var]=var;
		  }
       	  free(mapvar);
       	  numatom=oldnumatom;
		  inactiveSolution(unit);
		  restoreSolution(unit);
	   	  free(outEquAtom);
          outEquAtom=0;
		  for(i=1; i<=numatom; i++) if(unit[i]==0) unfixed++;
		  
		  printf("c unfixed var#=%d var#=%d \n",unfixed,numatom);
	
		  if(unfixed==0) goto outSol;
			  
		  readSATProblem(FileName,true);
    	  seen=(int *)calloc(numatom+1,sizeof(int));
		  rc=deletegarbage(change);
          if(numClauses==0) {free(seen); goto outSol;}
		  if(rc==UNSAT){//ERROR 
			    readSATProblem(FileName,true);
    	  	    i=11;
				goto re_solve;		
		  }
		  for(i=0; i<10; i++){
	            rebuildCNFindex(0,numatom);
 			    look2polar(2);
 				deletegarbage(change);
                if(!change || numClauses==0) break;
		   }
re_solve:		
           free(seen);
		   if(numClauses){
	           if(i>=10) rebuildCNFindex(0,numatom);
			   varMap();
			   int decision_limit=0x7fffffff;
			   rc=Loadbigsolver(decision_limit,Clit, numClauses,true);
		       free(mapvar);
			   if(rc!=SAT) return UNKNOWN;
           }
outSol:
		   return SAT;
	}
	return rc;
}

int doubleSolver()
{   int i,j;
    int rc,sz;

    int *VarWeight=(int *) malloc(sizeof(int)*(numatom+1));
    key_lit=(int *) malloc(sizeof(int)*(numatom+1));
	for (i = 0; i <=numatom; i++) VarWeight[i]=0;
	for (i = 0; i < numXOR; i++){ //Eq clauses
        int size=Clit[i+1]-Clit[i];
		if(size>3) sz=8;
        else sz=4;
		for (j=0; j<size; j++) {
			int var=ABS(Clit[i][j]);
			VarWeight[var]+=sz;
		}
	}

    for (i = 1; i <=numatom; i++){
		int numOccurLit=OccurenceA[i][0]+OccurenceA[-i][0]-2;
		VarWeight[i]+=numOccurLit;
  	}
//sort
   	RealNumVars=sortkey(key_lit,VarWeight);
	printf("c free var#=%d  \n",RealNumVars);
    free(VarWeight);
	for(i=1; i<=numatom; i++) fixedvar[i]=0;
	if(RealNumVars==0) return SAT; //bug 3.25 2011 mod2-rand3bip-sat-220-1
	rc=OneLaysolve(key_lit);
	free(key_lit);
  	return rc; 
}

void init_weight()
{
	int i, longest_clause = 100; 
	
	size_difA = (float *) malloc(sizeof(float) * longest_clause );
	size_difA[0]=size_difA[1] = 0.0;
	for( i = 2; i < longest_clause; i++ )  size_difA[ i ] = (float)pow(5.0, 2.0-i);

   	lengthWeighA=(float *) malloc( sizeof( float ) * ( 100 ) );
	lengthWeighA[0] = lengthWeighA[1] = 0.0;
	for( i = 2; i < 100; i++ )
 	        lengthWeighA[ i ] =(float) (QXCONST * 0.5 * pow( 0.6 + QXBASE*0.01, (double)i ));
}

using namespace PrecoSat;

Stack<int> *BinCls; // binary clauses 
struct Cls2 {  
  int lits[2];
  Cls2(int lit1, int lit2) { lits[0]=lit1; lits[1]=lit2;}
};

inline void pushBinCls(int lit1,int lit2)
{
      lit1=lit2posLit(lit1);
	  lit2=lit2posLit(lit2);
	  BinCls[lit1].push(lit2);
	  BinCls[lit2].push(lit1);
}

void connectBin()
{
  int endclsNo=numXOR+numClauses;
  for(int i = numXOR; i <endclsNo ; i++){
   	  if( (Clit[i+1]-Clit[i])==2) { 
  			pushBinCls(Clit[i][0],Clit[i][1]);
			continue;
	  }
  }
}

void connectCls()
{ int i,*pv;
 
  OccurenceA-=numatom;
  int *occLit = OccurenceA[0];
  int numatom2=2*numatom+1;
  for(i=0; i <numatom2;i++) occLit[i]=0;
  occLit+=numatom;
  int endclsNo=numXOR+numClauses;
  connectBin();
 for(i = numXOR; i <endclsNo ; i++){
   	  if( (Clit[i+1]-Clit[i])==2) { 
  	//		pushBinCls(Clit[i][0],Clit[i][1]);
			continue;
	  }
	  for(pv=Clit[i]; pv<Clit[i+1]; pv++){
		   if(*pv==0) break;
		  occLit[*pv]++;
	  }
  }
  int sum=0;
  occLit-=numatom;
  for(i = 0; i < numatom2;i++) {
	     OccurenceA[i] =OccurenceA[0]+sum;
		 sum+=occLit[i]+1;
  }
  for(i = 0; i < numatom2;i++) OccurenceA[i][0]=1;
  OccurenceA+=numatom;
  for(i=numXOR; i<endclsNo; i++) {
		if( (Clit[i+1]-Clit[i])==2 ) continue;
		for(pv=Clit[i]; pv<Clit[i+1]; pv++) {
			if(*pv==0) break;
			int n=OccurenceA[*pv][0];
			OccurenceA[*pv][n]=i;
            OccurenceA[*pv][0]=n+1;
		}
  }
}  

inline bool stackUnit_Prop(int sp1, int &sp, int **clslit, int **CNFocc,int **XORocc)
{   int i,ForcedLit[10];
	
	while(sp1<sp){
	   	int lt=StackLit[sp1++];
	//binary clause
		int blit=lit2posLit(lt);
		blit=blit^1;
	  	int binCnt=BinCls[blit];
		for(i=0; i<binCnt; i++){
             int other=BinCls[blit][i];
		     int var=other/2;
			 int lit=(other & 1) ? -var: var;
			 if(fixedvar[var]){
				 if(fixedvar[var]!=lit) return true; //conflict
			 }
			 else StackLit[sp++]=fixedvar[var]=lit;
        }
//longer clause		
		int numocc = CNFocc[-lt][0];
	    for (i = 1; i < numocc ;i++) {
			int cli = CNFocc[-lt][i];
	//		if(clsLen[cli]==0) continue;
			int m=0,*pv;
			int *endp=clslit[cli+1];
			for(pv=clslit[cli]; pv<endp; pv++){
	     	    int var=ABS(*pv);
				if(fixedvar[var]==*pv) goto nextC;
				if(fixedvar[var]==0) {if(m<2) ForcedLit[m++]=*pv;}
			}
			if(m==0) return true; //conflict
			if(m==1) {
			 	int var=ABS(ForcedLit[0]);
				StackLit[sp++]=fixedvar[var]=ForcedLit[0];
			}
nextC:     
			;
		}
//XOR clause
		if(XORocc==0) continue;
		int vv=ABS(lt);
		numocc=XORocc[vv][0];
	    for (i = 1; i < numocc; i++) {
		    int cli=XORocc[vv][i];
			int *pv, m=0,n=0;
		    for(pv=clslit[cli]; pv<clslit[cli+1]; pv++){
	    		  int var=ABS(*pv);
			      if(fixedvar[var]==*pv) n=n^1;
			      if(fixedvar[var]==0) {if(m<2) ForcedLit[m++]=*pv;}
			}
			if(m==0){
				if(n==0) return true;//conflict;
			}
			else{
				  if(m==1){
				      int var=ABS(ForcedLit[0]);
				      if(n==1) ForcedLit[0]=-ForcedLit[0];
					  StackLit[sp++]=fixedvar[var]=ForcedLit[0];
				}
			}
		}
	}
    return false; // no conflict
}

//computing DIFF by an iterative uint propagation
int IterativeUnitPropagationShort(int lit0,float *diff,int *Queue)
{   int i,cli,ForcedLit=0;
    int lt,rc,var,sp,sp1,*plit;
    
    Queue[0]=fixedvar[ABS(lit0)]=lit0;
//	level[0]=0;
    sp1=0; sp=1;
  	*diff=1;
    int nlit=lit2posLit(lit0);
    nlit=nlit^1;
	while(sp1<sp){
//		int ll=level[sp1]+1;
	 	lt=Queue[sp1++];
		assert(lt);
//binary clause
		int blit=lit2posLit(lt);
		blit=blit^1;
	  	int binCnt=BinCls[blit];
		for(i=0; i<binCnt; i++){
             int other=BinCls[blit][i];
		     var=other/2;
			 int lit=(other & 1) ? -var: var;
			 if(fixedvar[var]){
				  if(fixedvar[var]!=lit) {rc=UNSAT; goto ret;}; //conflict
			 }
			 else {
                 //if(ll<=1) level[sp]=0;
				 //else level[sp]=ll;
				 Queue[sp++]=fixedvar[var]=lit;
			 }
        }
//longer clause		
		int numocc = OccurenceA[-lt][0];
	    for (i = 1; i < numocc ;i++) {
			  cli=OccurenceA[-lt][i];
		      int m=0;
	          for(plit=Clit[cli+1]-1; plit>=Clit[cli]; plit--){
	    		    var=ABS(*plit); 
				    if(fixedvar[var]==*plit) goto nextC;
				    if(fixedvar[var]==0) {m++; ForcedLit=*plit;}
			 }
			 if(m==0) {rc=UNSAT; goto ret;}; //conflict
			 if(m==1) {
			    // level[sp]=ll;
				 Queue[sp++]=fixedvar[ABS(ForcedLit)]=ForcedLit;
			 }
			 else{
				 if(m<100) (*diff)+=size_difA[m];
			 }
	
nextC:          ;
		}
	
		if(numXOR>0){
//XOR clause
		  int vv=ABS(lt);
		  numocc=XORoccurA[vv][0];
		  for (i = 1; i < numocc; i++) {
			 int cli=XORoccurA[vv][i];
			 int m=0,n=0;
			 for(plit=Clit[cli+1]-1; plit>=Clit[cli]; plit--){
	              var=ABS(*plit); 
				  if(fixedvar[var]==*plit) n=n^1;
				  if(fixedvar[var]==0) {m++; ForcedLit=*plit;}
			 }
			 if(m==0){
				if(n==0) {rc=UNSAT; goto ret;} //conflict
			 }
			 else{
				  if(m==1){
				      if(n==1) ForcedLit=-ForcedLit;
				//	  level[sp]=ll;
					  Queue[sp++]=fixedvar[ABS(ForcedLit)]=ForcedLit;
				  }
				  else {
					  if(m<100) (*diff)+=lengthWeighA[m];
				  }
			 }
		  }
		}
	}
	rc=UNKNOWN;
ret:
    for(i=0; i<sp; i++) fixedvar[ABS(Queue[i])]=0;
	Queue[sp]=0;
	return rc;
}
inline void copyFixedVar(int *queue,int & sp)
{
	int k=0;
	while(queue[k]){
		StackLit[sp++]=fixedvar[ABS(queue[k])]=queue[k];
		k++;
	}
}

bool findmaxVar(int *Ranklit,int & sp, int & mlit)
{   	
    int *Queue1=(int *)malloc( sizeof(int)*(2*numatom));
    int *Queue2=Queue1+numatom;
	float max=-1,diff1,diff2;
  	int i,lookn=0;
	i=mlit=0;
	for(; Ranklit[i]; i++){
		 int vv=ABS(Ranklit[i]);
		 if(fixedvar[vv]==0){
			  lookn++;
			  int rc1=IterativeUnitPropagationShort(vv, &diff1,Queue1);
			  int rc2=IterativeUnitPropagationShort(-vv,&diff2,Queue2);
			  if(rc1==UNSAT){
				  if(rc2==UNSAT) {free(Queue1); return true;}// conflict
				  copyFixedVar(Queue2,sp);
			  }
			  else{
				  if(rc2==UNSAT){
					  copyFixedVar(Queue1,sp);
				  }
				  else{ // look both
					   int k=0;
					    while(Queue1[k]){
						    int lit=Queue1[k];
						    int var=ABS(lit); 
						    if(fixedvar[var]==0){
							  if(lit<0) fixedvar[var]=lit-1;
							  else fixedvar[var]=lit+1;
							}
						    k++;
						}
                        k=0;
					    while(Queue2[k]){
						  int lit=Queue2[k];
						  int lit1,var=ABS(lit); 
						  if(fixedvar[var]){
							  if(lit<0) lit1=lit-1;
							  else lit1=lit+1;
							  if(fixedvar[var]==lit1) StackLit[sp++]=fixedvar[var]=lit;
						  }
						  k++;
						}
						k=0;
					    while(Queue1[k]){//clear
						  int var=ABS(Queue1[k]); 
						  if(ABS(fixedvar[var])!=var) fixedvar[var]=0;
						  k++;
						}

						int occN=OccurenceA[-vv][0]+OccurenceA[vv][0];
						if(XORoccurA) occN+=XORoccurA[vv][0];
			            if(lookn>3 && occN<10) continue;
						if(diff1<=diff2/4) diff2=diff1*4+diff2/80;
						else if(diff2<=diff1/4) diff1=diff2*4+diff1/80;
						float diff=diff1*diff2+occN;
						if(diff>max){
							max=diff;
						    if(diff1<diff2)	mlit=-vv;
							else mlit=vv;
						}
					}
			  }
		 }
		 if(numClauses>300000 && (lookn>3000 || (lookn>30 && max>100000))) break;
	}
	free(Queue1);
	return false;
}

int groupvars;
int *candidate;

int varNeighbor(int *Ranklit,int RealNumVars, int **clslit, int **CNFocc,int **XORocc, int *Seen)
{   int groupNo=1;
    int k,j,m=0; 
    for(int i=0; i<RealNumVars; i++){
		 int vv=ABS(Ranklit[i]);
		 if(fixedvar[vv] || Seen[vv]) continue;
		 int n=0;
		 for(j=0;j<2; j++){
    		 //binary clause
			 vv=-vv;
	  		 int blit=lit2posLit(vv);
		     int binCnt=BinCls[blit];
		     for(k=0; k<binCnt; k++){
                    int other=BinCls[blit][k];
		  			if(Seen[other/2]!=groupNo) n++;
          			Seen[other/2]=groupNo;
           	}
		 }
//XOR clause
    	 vv=ABS(vv);
		 if(XORocc){
			 int numocc=XORocc[vv][0];
	         for (k = 1; k < numocc; k++) {
		       int cli=XORocc[vv][k];
			   for(int *pv=clslit[cli]; pv<clslit[cli+1]; pv++){
				   if(Seen[ABS(*pv)]!=groupNo) n++;
				   Seen[ABS(*pv)]=groupNo;
			   }
			 }
		 }

		 if(n<15){//15
//3+ clauses
		    for(j=0;j<2; j++){
			   vv=-vv;
		       int numocc = CNFocc[vv][0];
	           for (k = 1; k < numocc ;k++) {
			       int cli = CNFocc[vv][k];
				   if(clslit[cli+1]-clslit[cli]>3 && n>20) continue;
				   for(int *pv=clslit[cli]; pv<clslit[cli+1]; pv++) Seen[ABS(*pv)]=groupNo,n++;
			   }
			}  		
		 }
		 int mlen=m+30; //30
		 for(k=0; k<RealNumVars; k++){
		     int vv=ABS(Ranklit[k]);
			 if(Seen[vv]!=groupNo) continue;
			 if(m>=groupvars-3){
				 groupvars+=256;
	             candidate=(int*)realloc(candidate, sizeof(int)*groupvars);
			 }
		     candidate[m++]=vv;
	      	 if(m>=mlen) break;
		 }
		 candidate[m]=0;
		 if(m>0 && candidate[m-1]==0) continue;
		 m++;
		 if(groupNo>=10) break; //10 50
		 groupNo++;
	}
	candidate[m]=0;
	return groupNo;
}

void extendEqv(int var) //Equivalent constraint
{ 
    if(numXOR==0) return;
	int i,v1,v2,var2,k=0,n=1;
	int *Queue=(int *)calloc(numatom,sizeof(int));
    Queue[0]=var;
    while(k<n){
		var=Queue[k];
 		int numocc=XORoccurA[var][0];
	    for (i=1; i < numocc; i++) {
			 int cli=XORoccurA[var][i];
			 if(Clit[cli+1]-Clit[cli]!=2) continue;
             if(ABS(Clit[cli][0])==var) v1=0;
			 else v1=1; 
             v2=(v1+1)%2;
			 var2=ABS(Clit[cli][v2]);
			 if(Clit[cli][v1]==fixedvar[var]){
				 if(fixedvar[var2]!=-Clit[cli][v2]) Queue[n++]=var2;
				 fixedvar[var2]=-Clit[cli][v2];
             }
			 else {
                 if(fixedvar[var2]!=Clit[cli][v2]) Queue[n++]=var2;
				 fixedvar[var2]=Clit[cli][v2];
			 }
		}
		k++;
	}
	free(Queue);
}

void outputLit(int lit,intpp & clsLit, int numcls, int & nowPos, int & MemSize)
{
	if(nowPos>=MemSize){
		    if(MemSize/8<2048) MemSize+=2048;
			else MemSize=MemSize+MemSize/8;
			int *Clause_start=(int*)realloc(clsLit[0], sizeof(int)*MemSize);
            SetClausePtr(clsLit,Clause_start,numcls);
	}
    clsLit[0][nowPos++]=lit;
}

void outNewclause(intpp & clsLit, int &numcls, int nowPos, int & maxCls)
{   ++numcls;
	if(numcls>=maxCls){
		 maxCls+=1024;
		 clsLit=(int**)realloc(clsLit, sizeof(int *)*maxCls);
    }
    clsLit[numcls]=clsLit[0]+nowPos;
}

int AMOSolve(int *Ranklit);
bool computeDiff(int *Ranklit,int RealNumVars, int & sp);

int sortweightlit(int *Ranklit)
{   float score[100];
    int i,j,k;

    DIFF=(float *)calloc(2*numatom+2,sizeof(float)); 
    int sp=0;
	bool conflict=computeDiff(Ranklit, RealNumVars, sp);
    if(conflict){
	     free(DIFF);
	     return UNSAT;
	}
    int endClsNo=numXOR+numClauses;	
	for(i=numXOR; i<endClsNo; i++){
	       int sz=Clit[i+1]-Clit[i];
		   if(sz>80 || sz<3) continue;
		   k=0;
		   for(int *pv=Clit[i]; pv<Clit[i+1]; pv++){ 
			     if(*pv>0) score[k]=DIFF[2*(*pv)];
				 else score[k]=DIFF[2*(-(*pv))+1];
				 for(j=k-1; j>=0; j--){
					 if(score[j]>score[j+1]){
					     float tm=score[j]; score[j]=score[j+1]; score[j+1]=tm;
    				     Swap(Clit[i][j],Clit[i][j+1]);
					 }
				 }
				 k++;
		   }
	}
	free(DIFF);
	return UNKNOWN;
}

inline int find(int vv, int lit)
{
	int lit1=outEquAtom[vv];
    while(lit1){
    	lit=(lit<0)?-lit1:lit1;
	    vv=ABS(lit);
		lit1=outEquAtom[vv];
		if(ABS(lit1)==vv){
			outEquAtom[vv]=0;
			break;
		}
	}
	return lit;
}

inline int find_lit(int lit)
{
     return find(lit/2,  posLit2lit(lit));
}

void mergeTwoEqu(int lit1, int lit2)
{
    int v1,v2;
	v1=ABS(lit1); v2=ABS(lit2);
	if(v1>v2){
		Swap(v1,v2);
        Swap(lit1,lit2);
  	}
   	if(lit2<0) lit1=-lit1;
   	outEquAtom[v1]=0;
	outEquAtom[v2]=lit1;
}

void mergeAllEqu()
{
	for(int i=numatom; i>=2; i--){
         if(outEquAtom[i]==0) continue;
		 int other=find(i,i);
    	 mergeTwoEqu(other, i);
    }
}

// scc (strongly connnected Component
int decompose (int *unitVar) 
{
  int i,Itemsize = 2*(numatom + 1); 
  int rc=UNKNOWN;
  BinCls = (Stack<int> *) calloc (Itemsize, sizeof (*BinCls));
  connectBin();
  int *Seen =(int *) calloc (Itemsize, sizeof (int));
  Stack<int> work;
  Stack<int> saved;
  SCC * sccs;
  Mem mem;

  // (A v B)(A v -B) ==> A
  for (i = 2; i <= 2*numatom + 1; i++) {
        Stack<int> & os = BinCls[i]; //occs[i].bins
        unsigned j,cnt = os;
        for(j=0; j<cnt; j++){
			int lit=os[j];
			if(Seen[lit^1]){
	                if(unitVar[i/2]==0){
		               unitVar[i/2]=posLit2lit(i);
					}
			        else{
				        if(unitVar[i/2]!=posLit2lit(i)) {free(Seen); rc= UNSAT; goto end2;}
					}
			}
			Seen[lit]=1;
		}
		for(j=0; j<cnt; j++) Seen[os[j]]=0;
  }
  free(Seen);

  size_t bytes;
  bytes = 2 * (numatom + 1) * sizeof (SCC);
  sccs = (SCC*) mem.callocate (bytes);
  int root,dfsi;
  dfsi = 0;
  for (root = 2; root <= 2*numatom + 1; root++) {
      if (sccs[root].idx) continue;
      work.push (root);
      while (work) {
          int lit = work.top ();
       	  if (sccs[lit^1].idx && !sccs[lit^1].done) {
		 	  int vv=lit/2;
			  if(unitVar[vv]==0){
		             unitVar[vv]=posLit2lit(lit);
			  }
			  else{
				  if(unitVar[vv]!=posLit2lit(lit)) {rc=UNSAT; goto end;}
			  }
		  }
          Stack<int> & os = BinCls[1^lit];
          unsigned i = os;
		  if (!sccs[lit].idx) {
	            sccs[lit].idx = sccs[lit].min = ++dfsi;
	            saved.push(lit);
	       		while (i) {
	                  int other = os[--i];
	       			  if (sccs[other].idx) continue;
	                  work.push(other);
				}
		  } 
	      else {
	          work.pop ();
	          if (!sccs[lit].done) {
	              while (i) {
	                 int other = os[--i];
					 if (sccs[other].done) continue;
	            	 if(sccs[other].min<sccs[lit].min) sccs[lit].min = sccs[other].min;
				  }
	              SCC * scc = sccs + lit;
	              unsigned min = scc->min;
	              if (min != scc->idx) continue; 
	              int prev = 0, other = 0;
	              while (other != lit) {
	                   other = saved.pop ();
					   sccs[other].done = true;
	               	   if (prev) {
	                       int a=find_lit(prev);
						   int b=find_lit(other);
				           if (a == b) continue;
	                       if (a == -b) {
                                 rc=UNSAT;
								 goto end;
						   } 
						   else{ 
						 	   mergeTwoEqu(a,b);
						   }
					   } 
					   else prev = other;
				  }
			  }
		  }
	  }
  }
end:
  mergeAllEqu();
  work.release();
  saved.release();
  mem.deallocate (sccs, bytes);
end2:  
  for (i= 2; i<2*numatom+2; i++) BinCls[i].release();
  free(BinCls);
  return rc;
}

bool checklocal()
{
    if(numClauses>150000) return false;
    if(numatom>28000) return false;

    if((originClauses>2000 || numClauses>2000) && (numatom>600 || ClsVarRate>5)){
		if(originClauses-numClauses>numClauses/10) return false;
        if(originClauses+100<numClauses) {
	     	if(numatom>900 || ClsVarRate>5) return false; 
		}
	}

	int i, max=-1;
	for(i=1; i<=numatom; i++){
        int occ=OccurenceA[i][0]+OccurenceA[-i][0];
		if(occ>max) max=occ;
	}
	if(max>1000) return false;
	int cnt=0;
	for(i=1; i<=numatom; i++){
        int occ=OccurenceA[i][0]+OccurenceA[-i][0];
		if(occ>=max/2) cnt++;
	}
//	printf("c max=%d cnt=%d \n",max,cnt);
	if(cnt<numatom/16) return false;
	int min=numatom;
	max=-1;
	for(i=0; i<numClauses; i++){
         int len=Clit[i+1]-Clit[i];
         if(len>max) max=len;
		 if(len<min) min=len;
	}
//	printf("c max len=%d min len=%d \n",max,min);
	if(max-min>6) return false;
	return true;
}

extern int new_numatom;
int crypto_gss(int *Ranklit);

int OneLaysolve(int *Ranklit)
{
 int i,rc;
 new_numatom=numatom;
 AMOvar=0;
 Ranklit[RealNumVars]=0;
 int Itemsize = 2*(numatom + 1); 
 BinCls = (Stack<int> *) calloc (Itemsize, sizeof (*BinCls));
 seen=(int *)calloc(numatom+1,sizeof(int)); //binary reasoning
 
 groupvars=numatom+100;
 if(groupvars>50*256) groupvars=50*256; 
 candidate=(int *)calloc(groupvars,sizeof(int)); //binary reasoning
 connectCls();

 if(numXOR==0) {
	 localfind=checklocal();
	 if(localfind) mtrand.seed(27);
 }
 if(crypto_Gss) {
 	  rc=crypto_gss(Ranklit);
      if(rc!=UNKNOWN) {free(seen); goto freeMem;}
 }
 varNeighbor(Ranklit, RealNumVars, Clit, OccurenceA, XORoccurA, seen);
 if(crypto_Gss) {
	   int decision_limit=0x7fffffff;
	   numClauses+=delclauses;
       rc=Loadsolver(decision_limit,Clit, numClauses, numXOR, 0, Ranklit,false,fixedvar);
       free(seen);
       goto freeMem; 
 }

 for(i=1; i<=numatom; i++) seen[i]=0;
 if(originClauses>3500000 || localfind) goto No_prep2;
  
  if(originClauses>2000000) goto No_prep2;
  on_the_fly=on_the_fly_AMO();
  if(crypto_Gss) on_the_fly=true;
  if(sgi_AMO_len>0 && sgi_AMO_len<30){
  	   rc=AMOSolve(Ranklit);
       return rc;
   }
No_prep2:
   freeall_Index();
   free(seen);

   if(numClauses<65000 && numatom<10000) goto hybrdload;
   if((!localfind) && numatom>500 && (numClauses>50000 || numXOR>4000 || numatom>50000)) {
     	rc=Loadsolver_end(Clit, numClauses, numXOR, Ranklit);
   }
   else{
hybrdload:
 		rc=Loadsolver(Clit, numClauses, numXOR, Ranklit);
   }
freeMem:
   if(BinCls){
	   for (i= 2; i<2*numatom+2; i++) BinCls[i].release(); //bug (mem);
       free(BinCls);
   }
   free(candidate);
   return rc;
}

bool computeDiff(int *Ranklit,int RealNumVars, int & sp)
{   int *Queue=(int *)malloc( sizeof(int)*(numatom));
    for(int i=0; i<RealNumVars && i<50000; i++){
		 int vv=ABS(Ranklit[i]);
		 if(fixedvar[vv]==0){
			  int rc1=IterativeUnitPropagationShort(vv, DIFF+2*vv,Queue);
           	  int rc2=IterativeUnitPropagationShort(-vv, DIFF+2*vv+1,StackLit+sp);
			  if(rc1==UNSAT){
				  if(rc2==UNSAT)  {free(Queue); return true;}// conflict
				  while(StackLit[sp]){
						fixedvar[ABS(StackLit[sp])]=StackLit[sp];
						sp++;
				  }
			  }
			  else{
				   if(rc2==UNSAT){
				      int k=0;
					  while(Queue[k]){
							StackLit[sp++]=fixedvar[ABS(Queue[k])]=Queue[k];
							k++;
						}
					}
			  }
		 }
	}
	free(Queue); 
	return false;
}

bool on_the_fly_AMO()
{  
   int i,numbig;
  
   if(originClauses>1000000) return false;
   numbig=0;
   int endClsNo=numXOR+numClauses;	
   AMOvar=(int *)calloc(numatom+1,sizeof(int)); // At most one
   for(i=numXOR; i<endClsNo; i++){
   	     int size=Clit[i+1]-Clit[i];
		 if(size<9) continue;
		 if(size<40) numbig++;
		 for(int *pv=Clit[i]; pv<Clit[i+1]; pv++){
		     if(AMOvar[ABS(*pv)]){
				    if(AMOvar[ABS(*pv)]!=*pv) AMOvar[ABS(*pv)]=0;
			 }
			 AMOvar[ABS(*pv)]=*pv;
		 }	   
   }
//   printf("c numXOR=%d numClauses=%d numbig=%d \n",numXOR, numClauses,numbig);
   if(numatom>2000 || endClsNo>100000) return false;
   if(numbig<5 || numbig>40) return false;
   return true;
}

void addbin(int lit1, int lit2)
{   int clsn=numClauses+numXOR;
    Clit[clsn][0]=lit1;
    Clit[clsn][1]=lit2;
    Clit[clsn+1]=Clit[clsn]+2;
    numClauses++;
}

void StardardAMO(int sz, int *lits)
{    int j,k;
	 for(j=0; j<sz-1; j++){
		  for(k=j+1; k<sz; k++)  addbin(-lits[j],-lits[k]);
	 }
}

void add2productAMO(int *ClauseNo,int AMOclauses)
{     int i,j,k,p,q;
      int newcls=0;
	  	  
      for(i=0; i<AMOclauses; i++){
	       int cno=ClauseNo[i];
           int sz=Clit[cno+1]-Clit[cno];
		   for(p=2; p<sz; p++) if(p*p>=sz) break;
		   q=p-1;
		   if(q*p<sz) q=p;
		   newcls+=2*sz+p*(p-1)/2+q*(q-1)/2;
	  }
	  int CNF_space=Clit[numClauses+numXOR]-Clit[0]+2*newcls;
      int *Lit_set=(int*)realloc(Clit[0], sizeof(int)*CNF_space);
   	  SetClausePtr(Clit,Lit_set,numClauses+numXOR);
      Clit=(int**)realloc(Clit, sizeof(int *)*(numXOR+numClauses+1+newcls));
//	  printf("c newcls=%d AMOclauses=%d \n",newcls,AMOclauses);
	  int old_numatom=numatom;
	  int V[200], W[200];
      for(i=0; i<AMOclauses; i++){
	       int cno=ClauseNo[i];
           int sz=Clit[cno+1]-Clit[cno];
           for(p=2; p<sz; p++) if(p*p>=sz) break;
  		   q=p-1;
    	   if(q*p<sz) q=p;
		   for(j=0; j<p; j++) V[j]=++numatom;
		   for(j=0; j<q; j++) W[j]=++numatom;
		   int n=0;
		   for(j=0; j<p; j++){
			   if(n>=sz) break;
			   for(k=0; k<q; k++){
		          int lit=Clit[cno][n];
			      addbin(-lit,V[j]);
                  addbin(-lit,W[k]);
                  n++;
				  if(n>=sz) break;
			   }
		   }
		   StardardAMO(p,V);
		   StardardAMO(q,W);
	  }
	  printf("c clauses#=%d var#=%d #aux var=%d \n",numClauses,numatom,numatom-old_numatom);
}

int EdgeMatch(int & sgi_AMO_sz)
{
   int i,ClauseNo[1601];
   int AMOclauses;
   int *Ranklit=0;
   int old_numClauses=numClauses;
   int old_numatom=numatom;
   int szset[2]={0, 0};
   int cnt1,cnt2;
  
   bool sgi,gss;
   sgi=gss=false;
   if(numClauses>1500000 || numatom>150000) return UNKNOWN;
   if(numClauses/80>numatom && numatom>3000) return UNKNOWN;
   if(numClauses/100>numatom) return UNKNOWN;
   
   if(numClauses/20>numatom){
	      if(numatom>5000) return UNKNOWN;
          sgi=true;
   }
   if(numClauses/5<numatom){
	   if(20000<numatom && numatom<40000) gss=true;
   }
   if(gss || sgi){
	      int size=0,cnt=0,bin=0;
		  for(i=0; i<numClauses; i++){
    	       int sz=Clit[i+1]-Clit[i];
			   if(sz>3) if(gss) return UNKNOWN;
			   if(sz<15) {
				   if(sz<3) bin++;
				   continue;
			   }
			   if(size==0) size=sz;
			   if(size!=sz) if(sgi) return UNKNOWN; 
		  	   cnt++;
		  }
		  if(cnt>=10) sgi_AMO_sz=size;
		  else {
			  if(bin<(numClauses/9)*5) return UNKNOWN;
			  crypto_Gss=true;
  		  }
		  return UNKNOWN;
   }   
   AMOclauses=cnt1=cnt2=0;
   for(i=numXOR; i<numXOR+numClauses; i++){
    	 int sz=Clit[i+1]-Clit[i];
	   	 if(sz<15) continue;
		 if(sz>900) return UNKNOWN;
		 ClauseNo[AMOclauses++]=i;
		 if(AMOclauses>1600) return UNKNOWN;
		 if(szset[0]==0){ szset[0]=sz; cnt1++; continue;}
         if(sz!=szset[0]){
			 if(szset[1]==0){ szset[1]=sz; cnt2++; continue;}
 			 if(sz!=szset[1]) return UNKNOWN;
		     cnt2++;
		 }
		 else cnt1++;
   }
   if(szset[0]!=cnt1/2 || szset[1]!=cnt2/2 || cnt2==0) return UNKNOWN;
  //   printf("c sz1=%d sz2=%d cnt1=%d cnt2=%d \n",szset[0],szset[1],cnt1,cnt2);
   add2productAMO(ClauseNo,AMOclauses);
   int decision_limit=80000000;
   bool loadbin=false;

   unit=fixedvar=(int *)realloc(fixedvar, sizeof(int)*(numatom+1));
   for(i=old_numatom+1; i<=numatom; i++) fixedvar[i]=0;
 
   int rc=Loadsolver(decision_limit,Clit, numClauses, numXOR, 0, Ranklit,loadbin,fixedvar);
   numClauses=old_numClauses;
   return rc; //!!!!note UNSAT is not unsat 
}

int crypto_gss(int *Ranklit)
{  int ClauseNo[300];
   int i,j,rc,sp0=0;
   
   int ClsCnt=0;
   int endclsNo=numXOR+numClauses;
   
   for(i = numXOR; i <endclsNo ; i++){
   	     int cls_size=Clit[i+1]-Clit[i];
	     if(cls_size<15 || cls_size>24) continue;
		 for(j=0; j<ClsCnt; j++){
		     int k=ClauseNo[j];
			 int cnt=0;
			 for(int *pv1=Clit[i],*pv2=Clit[k]; pv1<Clit[i+1] && pv2<Clit[k+1]; pv1++,pv2++) if(*pv1==*pv2) cnt++;
			 if(cnt>10) break; 
         }
		 if(j<ClsCnt) continue;
 		 ClauseNo[ClsCnt++]=i;
		 if(ClsCnt>100) return UNKNOWN;
   }
   if(ClsCnt<15) return UNKNOWN;
   DIFF=(float *)calloc(2*numatom+2,sizeof(float)); //binary reasoning
   bool conflict=computeDiff(Ranklit, RealNumVars, sp0);
   if(conflict) { free(DIFF); return UNSAT;}
  
   float score[100],clsScore[20];
   int m=0;
   for(i=0; i<ClsCnt; i++){
	       int cno=ClauseNo[i];
           int *pv,k=0;
		   for(pv=Clit[cno]; pv<Clit[cno+1]; pv++){ 
			     if(*pv>0) score[k]=DIFF[2*(*pv)];
				 else score[k]=DIFF[2*(-(*pv))+1];
		  		 for(j=k-1; j>=0; j--){
					 if(score[j]>=score[j+1]) break;
					 float tm=score[j];
					 score[j]=score[j+1]; score[j+1]=tm;
    				 Swap(Clit[cno][j],Clit[cno][j+1]);
				 }
				 k++;
           }
		   clsScore[m]=score[k-1];
           ClauseNo[m]=cno;
		   for(k=m-1; k>=0; k--){
			   if(clsScore[k]>=clsScore[k+1]) break;
               float tm=clsScore[k]; clsScore[k]=clsScore[k+1]; clsScore[k+1]=tm;
    		   Swap(ClauseNo[k],ClauseNo[k+1]);
		   }
		   if(m<15) m++;
    }
    free(DIFF);
    ClsCnt=m;
//    printf("c ClsCnt=%d \n",ClsCnt);
    for(i=0; i<9; i++){
		  for(j=i-1; j>=0; j--){
	    	    if(ClauseNo[j]<=ClauseNo[j+1]) break;
	            Swap(ClauseNo[j],ClauseNo[j+1]);
		  }
	}
  
    unsigned int pmu=0;
	int sp=0;
	for(i=0; i<9; i++){
	      int cno=ClauseNo[i];
	      int size=Clit[cno+1]-Clit[cno]-1;
		  if(i==1 || i==8) size--;
		  if(i==7) size=1;
          int lit=Clit[cno][size];
		  if(fixedvar[ABS(lit)]==0) StackLit[sp++]=fixedvar[ABS(lit)]=lit;
          if(i==6){
			  size--;
		      lit=Clit[cno][size];
		      if(fixedvar[ABS(lit)]==0) StackLit[sp++]=fixedvar[ABS(lit)]=lit;
		  }
	}
	for(i=0; i<9; i++){
	      int cno=ClauseNo[i];
		  for(int *pv=Clit[cno]; pv<Clit[cno+1];pv++){
		      if(fixedvar[ABS(*pv)]==0) StackLit[sp++]=fixedvar[ABS(*pv)]=-(*pv);
		  }
	}
	goto solve;	   
	while(1){
	   pmu++;
	   unsigned int bits;
	   int one;
	   one=0;  bits=pmu;
	   for(i=0; i<9; i++){
		   if( bits & 1) one++;
           bits=bits>>1;
	   }
	   if(one!=5){
      		if(pmu>= (1<<9)) break;
		    continue;
	   }
  	   bits=pmu;
	   one=0;
	   for(i=0; i<9; i++){
		   int cno=ClauseNo[i];
	       int size=Clit[cno+1]-Clit[cno]-1;
		   int lit=Clit[cno][size];
		   if((bits & 1)) {
			   if(fixedvar[ABS(lit)]==0) StackLit[sp++]=fixedvar[ABS(lit)]=lit;
			   int len;
			   one++;
			   if(one<=3) len=size;
			   else len=size-2;
			   for(j=0; j<len; j++){
					 lit=Clit[cno][j];
		 	         if(fixedvar[ABS(lit)]==0) StackLit[sp++]=fixedvar[ABS(lit)]=-lit;
			   }
		   }
		   else{
			   if(i<7){
				    lit=Clit[cno][size-1];
		  	        if(fixedvar[ABS(lit)]==0) StackLit[sp++]=fixedvar[ABS(lit)]=lit;
			        for(j=0; j<size-3; j++){
					  lit=Clit[cno][j];
		 	          if(fixedvar[ABS(lit)]==0) StackLit[sp++]=fixedvar[ABS(lit)]=-lit;
					}
					lit=Clit[cno][0];
			   }
		       if(fixedvar[ABS(lit)]==0) StackLit[sp++]=fixedvar[ABS(lit)]=-lit;
		       lit=Clit[cno][size/2];
		       if(fixedvar[ABS(lit)]==0) StackLit[sp++]=fixedvar[ABS(lit)]=-lit;
		       lit=Clit[cno][size/2-1];
		       if(fixedvar[ABS(lit)]==0) StackLit[sp++]=fixedvar[ABS(lit)]=-lit;
		   }	 
		   bits=bits>>1;
	   }
solve:
     	int decision_limit=400000;
	  	rc=Loadsolver(decision_limit,Clit, numClauses+delclauses, numXOR, sp, Ranklit,false,fixedvar);
	  	if(rc==SAT)	return SAT;
		while(sp>0){
		    sp--;
		  	fixedvar[ABS(StackLit[sp])]=0;
		}
	}
	return UNKNOWN;
}

int AMOSolve(int *Ranklit)
{
  int depth,i,mlit,sp1,nlit,rc,saveSp[300];
  char visit[300];
  bool conflict;
  int j,k,sp,numbig,visitClause[300];
  int cno,ClauseNo[450],minsize;
  float maxdiff=0;
  int depthlimit;

  printf("c ALO selection solving \n");
  int decision_limit=5000;
  rc=Loadsolver(decision_limit,Clit, numClauses, numXOR, 0, Ranklit,true,fixedvar); 
  if(rc!=UNKNOWN) return rc;
	
  depthlimit=2;
  numbig=0;
  if(sgi_AMO_len>26) depthlimit=4;
  else if(sgi_AMO_len>20) depthlimit=3;
  int endClsNo=numXOR+numClauses;	
  for(i=numXOR; i<endClsNo; i++){
   	     int size=Clit[i+1]-Clit[i];
		 if(size<9) continue;
		 ClauseNo[numbig++]=i;
		 if(numbig>400) break;
  }
  saveSp[0]=sp=0;
  visit[0]=depth=1;
  DIFF=(float *)calloc(2*numatom+2,sizeof(float)); //binary reasoning
  while(1){
	    if(depth>numbig) goto sel;
	    conflict=computeDiff(Ranklit, RealNumVars, sp);
		if(conflict) { depth--; goto pop;}
		visitClause[depth]=-1;
		minsize=10000000;
	    for(i=0; i<numbig; i++){
		   cno=ClauseNo[i];
		   //for(j=1; j<depth; j++) if(visitClause[j]==i) break;//??? bug 2011
		   for(j=1; j<depth; j++) if(visitClause[j]==cno) break;
		   if(j>=depth) {
		       int realsize=0;
			   float diff=0;
			   bool claV=false;
			   int size=Clit[cno+1]-Clit[cno];
			   for(j=0; j<size; j++){
				   mlit=Clit[cno][j];
				   int vv=ABS(mlit);
				   if (fixedvar[vv]) {
					  if(fixedvar[vv]==mlit) { claV=true; break;}
					  continue;
				   }
	               if(mlit>0) diff+=DIFF[2*mlit];
				   else diff+=DIFF[2*(-mlit)+1];
				   realsize++;
       		   }
			   if(claV) continue;
			   if(realsize>0){
				   if(realsize>2) diff=diff/(realsize+10);
				   if(minsize>realsize || ((minsize==realsize) && (diff>=maxdiff ))){
         			   visitClause[depth]=cno;
					   minsize=realsize;
			   		   maxdiff=diff;
				   }
			   }
		   }
	   }
   	   cno=visitClause[depth];
	   if(cno<0) goto sel;
	   k=(Clit[cno+1]-Clit[cno])-1;	
	   for(j=0; j<=k; ){
		 	  int lit=Clit[cno][j];
			  if(fixedvar[ABS(lit)]==0) j++;
			  else {
				  Swap(Clit[cno][j],Clit[cno][k]);
				  k--;
			  }
	   }
	   if(k<0) goto sel;
	   visit[depth]=k;
	   mlit=Clit[cno][k];
	   saveSp[depth]=sp1=sp;
	   StackLit[sp++]=fixedvar[ABS(mlit)]=mlit;
	   goto loop;
sel:	
		saveSp[depth]=sp1=sp;
		for(i=0; i<RealNumVars; i++){
		      int vv=ABS(Ranklit[i]);
			  if(fixedvar[vv]==0){
					StackLit[sp++]=fixedvar[vv]=vv;
					visitClause[depth]=-1;
                    visit[depth]=1;
					goto loop;
			  }
		}
		printf("c all vars are fixed \n"); //vmpc_27
     	rc=SAT;
		goto solutionA;
i_th:
		nlit=-StackLit[sp];
	    StackLit[sp++]=fixedvar[ABS(nlit)]=nlit;
		i=visitClause[depth];
		if(i<0){
	         saveSp[depth]=sp1=sp-1;
			 goto loop;
		}
		saveSp[depth]=sp1=sp;
	    for(j=visit[depth]; j>=0; j--){
			 nlit=Clit[i][j];
			 if(!fixedvar[ABS(nlit)]) break;
		}
		visit[depth]=j;
		if(j<0) goto pop;
        StackLit[sp++]=fixedvar[ABS(nlit)]=nlit;
		for(j++; j<Clit[i+1]-Clit[i]; j++){
			 nlit=Clit[i][j];
			 if(fixedvar[ABS(nlit)]==0)  StackLit[sp++]=fixedvar[ABS(nlit)]=-nlit;
		}
loop:
        conflict=stackUnit_Prop(sp1, sp, Clit, OccurenceA,XORoccurA);
        if(conflict) {
	  		  goto pop;
		}
	//	printf("c ");
	//    for(i=1; i<=depth; i++) printf("%2d=%d ", i,visit[i]);
    //	printf(" \n");
		if(depth>=depthlimit){
  		  	int decision_limit=100000;
	      	rc=Loadsolver(decision_limit,Clit, numClauses, numXOR, sp, Ranklit,true,fixedvar);
			if(rc==SAT) goto solutionA; 
			if(rc==UNSAT) goto pop;
		}
		depth++;
	    continue;
pop:
		while (visit[depth]<=0) depth--;
		while(sp>saveSp[depth]){
		    sp--;
		  	fixedvar[ABS(StackLit[sp])]=0;
		}
		if(depth<=0) break;
	  	visit[depth]--;
		goto i_th;
    }
	rc=UNSAT;
solutionA:
	free(DIFF);
	free(AMOvar);
	AMOvar=0;
	if(rc==SAT) printf("c a solution found by ALO selectig \n");
	return rc;
}

void readCNFclause()
{
    readSATProblem(FileName,true);
  	originClauses=numClauses;
    XORoccurA=OccurenceA=0;
}

void freeall_Index()
{
	if(OccurenceA){
		OccurenceA-=numatom;
	    if(OccurenceA[0]) free(OccurenceA[0]);
	    free(OccurenceA);
		OccurenceA=0;
	}
    if(numXOR){
		if(XORoccurA){
	    	free(XORoccurA[0]);
            free(XORoccurA);
		    XORoccurA=0;
		}
	}
	OccurenceA=0;
}

void readSATProblem(char *CNFfile, bool readlarge)
{
    int i,lastc,nextc,lit;
    int MemSize;

    FILE *fp=fopen(CNFfile,"r");
    if(fp==NULL) {
	   printf("c Cann't open file %s \n", CNFfile);
	   exit(1);
    }
    while ((lastc = fgetc(fp)) == 'c'){
	    while ((nextc = fgetc(fp)) != EOF && nextc != '\n');
    }
    ungetc(lastc,fp);
    if (fscanf(fp,"p cnf %i %i",&numatom,&numClauses) != 2) {
	     printf("c Bad input file \n");
	     exit(1);
    }
    if(numClauses>=10000000 && !readlarge){
          fclose(fp);
	      return;
    }

    originClauses=numClauses;
// 
    Clit=(int **) malloc( sizeof(int *) * (numClauses+1) );
    if(numClauses<100000) MemSize=6*numClauses;
	else MemSize=3*numClauses;
	int * Clause_start=(int *) malloc( sizeof(int) * MemSize);
  	if(Clause_start==NULL) {
		printf("c no sufficient memory available \n");
		exit(1);
    }
    int sum=0;
    for(i = 0;i < numClauses;i++){
	    Clit[i] = Clause_start+sum;
	    do {
		  if (fscanf(fp,"%i ",&lit) != 1) {
		        printf("\nc wrong CNF proposition \n");
		        exit(0);
		   }
	    	   if(lit != 0) {
				if(sum>=MemSize){
					MemSize+=(numClauses/4)+4000;
					Clause_start=(int*)realloc(Clause_start, sizeof(int)*MemSize);
                    int total=0,j,Clen;
					for(j=0; j<i; j++){
	                    Clen=Clit[j+1]-Clit[j];
						Clit[j]=Clause_start+total;
						total+=Clen;
					}
					Clit[j]=Clause_start+total;
				}
				Clause_start[sum++] = lit; /* clause[i][size[i]] = j; */
				if(ABS(lit)>numatom){
                      printf("c ERROR - incorrect problem format or extraneous characters\n");
	                  exit(0);
				}
			}
		} while(lit != 0);
	}
        Clit[i] = Clause_start+sum;
	fclose(fp);
}	

void check(int sol[],int **CNFcls, int numCls)
{
     int sum,i,vi;
     int *pv;

     for(i=0; i<numCls; i++){
	   sum=0;
	   for (pv=CNFcls[i]; pv<CNFcls[i+1]; pv++){
		   vi=*pv;
       	   int xi= vi < 0 ? -vi : vi; 
           if(sol[xi]==vi) sum+=1;
       }
	   if(sum==0) {
        	  printf ("c ERROR \n");
		      exit(0);
  	   }
   }
   printf("c verified \n");
}

