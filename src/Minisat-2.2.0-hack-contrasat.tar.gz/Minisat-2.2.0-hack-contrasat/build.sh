#!/bin/sh

export MROOT=$PWD

make -C simp rs
cp simp/contrasat_static ./contrasat
 
