#!/bin/sh

export MROOT=$PWD

rm -rf contrasat
make -C core clean 
make -C simp clean 
 
