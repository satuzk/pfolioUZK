
      ##  ##  #####    #####   $$$$$   $$$$   $$$$$$    
      ##  ##  ##  ##  ##      $$      $$  $$    $$      
      ##  ##  #####   ##       $$$$   $$$$$$    $$      
      ##  ##  ##  ##  ##          $$  $$  $$    $$      
       ####   #####    #####  $$$$$   $$  $$    $$      
  ======================================================
  SLS SAT Solver from The University of British Columbia
  ======================================================
  ...Developed by Dave Tompkins (davet [@] cs.ubc.ca)...
  ------------------------------------------------------
  .......consult legal.txt for legal information........
  ......consult revisions.txt for revision history......
  ------------------------------------------------------
  ... project website: http://www.satlib.org/ubcsat ....
  ------------------------------------------------------
  .....e-mail ubcsat-help [@] cs.ubc.ca for support.....
  ------------------------------------------------------

SAT11 Sparrow Build
===================

This is a special build of ubcsat that includes an implementation of the sparrow algorithm
It is based on a preliminary beta version (1.2b10) of ubcsat version 1.2

see sparrow.c for algorithm details (sorry for the lack of comments)

USAGE:

sparrow2011 BENCHNAME RANDOMSEED


The website should be consulted for the latest news on the ubcsat project

http://www.satlib.org/ubcsat  (or, alternatively, http://people.cs.ubc.ca/~davet/ubcsat)

